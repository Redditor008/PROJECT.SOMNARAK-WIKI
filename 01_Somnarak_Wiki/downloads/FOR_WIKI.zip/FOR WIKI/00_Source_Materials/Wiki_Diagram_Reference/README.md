# Somnarak Wiki Diagram Reference

## Purpose

This package is the visual reference library for the next Somnarak project: individual Sorrow Entity wiki pages using a compact diagram and icon presentation inspired by the functional role of Abnormality diagrams on the Lobotomy Corporation wiki.gg pages.

The Somnarak implementation will use these original Somnarak assets, terminology, classifications, colors, and page logic.

## Canonical Asset Folder

```text
00_Source_Materials/Wiki_Diagram_Reference/11_Diagrams/
```

The original uploaded package is preserved as:

```text
00_Source_Materials/Wiki_Diagram_Reference/11_Diagrams.zip
```

SHA-256:

```text
b51e32e9494c76a562b9be877fe9ab285a99f26c5b7e154e18b7aef553fa9b7c
```

## Asset Inventory

- SVG assets: **45**
- PNG reference diagrams: **2**
- Text-layout reference: **1**
- Extracted files: **48**
- Archive entries including the root directory: **49**

## Icon Families

### SECC and Entity Identity

- `origin.svg`
- `city.svg`
- `inner.svg`
- `outside.svg`
- `coherence.svg`
- `potency.svg`
- `number.svg`
- `manifestation.svg`
- `element.svg`
- `subject.svg`
- `object_type.svg`
- `place.svg`
- `tool.svg`
- `hybrid.svg`

### Sorrow Elements

- `lament.svg`
- `grudge.svg`
- `void.svg`
- `weight.svg`
- `mixed.svg`

### Work Types

- `flerehan.svg`
- `pugnahan.svg`
- `viderehan.svg`
- `ferrehan.svg`

### Personnel Attributes

- `resilience.svg`
- `clarity.svg`
- `composure.svg`
- `resolve.svg`

### M.A.W. Equipment

- `weapon.svg`
- `suit.svg`
- `gift.svg`

### Work Results and Gauge

- `good_result.svg`
- `normal_result.svg`
- `bad_result.svg`
- `sorrow_gauge.svg`
- `hbox.svg`

### Hope and Mixed-Expression Symbols

- `hope_icon.svg`
- `hope_gold.svg`
- `light.svg`
- `warmth.svg`
- `spark.svg`
- `flame.svg`
- `shield_hope.svg`

### Somnarak Identity and Large Diagrams

- `somnarak_icon.svg`
- `somnarak_city_layout.svg`
- `somnarak_city_layout_dark.svg`
- `SOMNARAK_CITY_LAYOUT.png`
- `The Hand, D.R. Layout.png`
- `Hand of Change-Text Layout.txt`

## Intended Wiki-Page Use

Each individual entity page can use the library for:

1. A compact SECC identity strip: origin, coherence, potency, number, manifestation, and element.
2. Entity-type display: Subject, Object, Place, Tool, or Hybrid.
3. Work-response rows for Flerehan, Pugnahan, Viderehan, and Ferrehan.
4. Good, Normal, and Bad result indicators.
5. Sorrow Gauge and personnel-attribute pressure display.
6. Weapon, Suit, and Gift M.A.W. cards.
7. Optional Hope-expression icons for Side-Story Canon or post-Dawn entities.
8. Facility and city-location diagrams where spatial context is needed.

## Preservation Rule

Treat `11_Diagrams/` as the canonical extracted reference set. Build future wiki templates and page exports in a separate project folder rather than editing these source assets directly.
