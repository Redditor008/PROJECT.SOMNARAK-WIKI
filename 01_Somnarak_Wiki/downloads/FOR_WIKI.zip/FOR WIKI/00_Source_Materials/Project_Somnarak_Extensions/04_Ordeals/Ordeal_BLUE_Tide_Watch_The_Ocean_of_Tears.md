# BLUE Tide Watch — The Ocean of Tears

> *""The corridor filled with blue light and the sound of an ocean that had never known a shore.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | BLUE |
| **Time** | Tide Watch |
| **Threat Level** | Catastrophic |
| **Han Source** | Lament |
| **Physical Form** | Non-Organic — A moving body of luminous blue liquid Han filling a corridor floor to ceiling, advancing slowly like a tide, with thousands of faint faces surfacing and vanishing within. Salt-cold and vast, it smells of cold rain; it weeps with every voice that has ever grieved. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 1–3 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 38–108 per hit · Lament (Deep Blue) |
| **HP** | 676/676 out of 1000 per entity |
| **Instant Fracture** | Yes — on critical hits / special abilities |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

The Blue Tide Watch Ordeal. Only spawns during the Sorrow Tide when Lament Han reaches Cascading density. The accumulated grief of the entire facility coalesces into a single, massive manifestation.

## Appearance

A single entity — or rather, a moving body of luminous blue liquid Han that fills a corridor from floor to ceiling, advancing slowly like a tide. Within it, thousands of faint faces surface and vanish. It weeps with every voice that has ever grieved in Somnarak.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **The Tide** | The ocean advances through corridors at 1 m/s, filling everything in its path. | All personnel in the path take 20–40 Composure damage per turn. Submersion deals 50+ Composure and may cause temporary Fracture symptoms (grey skin, weeping). |
| **The Drowning** | Personnel caught in the ocean's advance are submerged in grief. | Submerged personnel lose 10 Clarity per turn in addition to Composure. After 3 turns submerged, they begin to dissolve — becoming part of the ocean's faces. |
| **The Faces** | Thousands of faces surface within the ocean, each weeping a different grief. | Personnel looking at the faces must resist (Resolve check) or be paralyzed by grief for 1–2 turns, unable to move or act. |

## Suppression Protocol

Requires coordinated suppression: physical force (M.A.W. weapons) to damage the ocean's core (visible as a brighter concentration of light at its center). The core has very high HP. Simultaneously, Ferrehan workers must anchor trapped personnel and pull them out before they dissolve. Echo-Core oversight required. This is a facility-wide crisis.

## Facility Impact

If unsuppressed: the ocean advances until it reaches the facility's edge, dissolving all personnel and infrastructure in its path. The corridor it passed through remains damp and weeping for months. The faces it absorbed are gone permanently.

## R.D. Response Protocol

Alert Level 5. All available personnel. Echo-Core direct command. Facility-wide evacuation of non-combat staff. This Ordeal alone justifies the Tide Watch suppression team's existence.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary BLUE Tide Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Weeping Leviathan (Monster, Tide-Spawn-grade)

**Physical Form:** Monster — A long serpentine creature fully twenty meters from snout to tail, its body composed of translucent blue-grey skin stretched over visible ribs and a pulsing spine. Through the skin, organs are faintly visible — dark, wet, slowly churning. It has no eyes; its head is a wide, soft mouth that opens to release a keening wail, and from the corners of that mouth, actual tears stream — not water, but condensed sorrow, viscous and faintly luminescent, evaporating into fog as they fall..

| Stat | Value |
|---|---|
| **HP** | 500/500 out of 1000 |
| **Han Pressure [ATK]** | 35–60 per hit · Lament |
| **Spawn Count** | 1–3 |

**Ability:** Deals damage themed to its form and element. **[35-60 Deep Blue DMG [Deep Blue / Lament]]**

### The Tear-Sea (Non-Crystal, Tide-Spawn-grade)

**Physical Form:** Non-Crystal — A vast shallow sheet of living membrane stretched across the floor, studded with thousands of floating weeping faces just beneath the surface, open-eyed and mouthing silently. It advances like a slow saline flood, and where it passes the floor weeps.

| Stat | Value |
|---|---|
| **HP** | 530/530 out of 1000 |
| **Han Pressure [ATK]** | 40–65 per hit · Lament |
| **Spawn Count** | 1–3 |

**Ability:** It floods, and the concentrated sorrow of an ocean of tears dissolves the will of everyone submerged. 

### The Sorrow Fog (Non-Humanoid, Tide-Spawn-grade)

**Physical Form:** Non-Humanoid — A drifting bank of luminous blue mist that fills corridors and rooms — not a creature but a presence, the condensed grief of the Sorrow Tide made airborne. Within the fog, shapes move: half-formed, dissolving — faces, hands, the silhouettes of people who are not there. The mist is cold, damp, and clings to the skin like grief itself, and breathing it fills the lungs with an ache that has no physical source..

| Stat | Value |
|---|---|
| **HP** | 560/560 out of 1000 |
| **Han Pressure [ATK]** | 45–70 per hit · Lament |
| **Spawn Count** | 1–3 |

**Ability:** Deals damage themed to its form and element. **[45-70 Deep Blue DMG [Deep Blue / Lament]]**


### The Sorrow-Singer (Humanoid, Tide-Spawn-grade)

**Physical Form:** Humanoid — A towering humanoid whose every breath is one sustained note of grief, a sound that floods whole halls and bends the will.

| Stat | Value |
|---|---|
| **HP** | 410/410 out of 1000 |
| **Han Pressure [ATK]** | 30-44 per hit · Lament |
| **Spawn Count** | 1 |

**Ability:** The note swells, and a hall worth of minds drowns in the sound at once.. **[[30-44 Deep Blue DMG [Deep Blue / Lament]]]**

### The Tear-Ocean (Amorphous, Tide-Spawn-grade)

**Physical Form:** Amorphous — A vast living sea of saline fluid studded with thousands of floating weeping faces just beneath the surface.

| Stat | Value |
|---|---|
| **HP** | 400/400 out of 1000 |
| **Han Pressure [ATK]** | 28-42 per hit · Lament |
| **Spawn Count** | 1 |

**Ability:** It rises, and the ocean of grief dissolves the will of all it covers.. **[[28-42 Deep Blue DMG [Deep Blue / Lament]]]**

### The Rain (Swarm, Tide-Spawn-grade)

**Physical Form:** Swarm — A dense, ceaseless fall of living tear-drops that saturate the air, each carrying a fragment of someone loss.

| Stat | Value |
|---|---|
| **HP** | 40/40 out of 1000 |
| **Han Pressure [ATK]** | 7-11 per hit · Lament |
| **Spawn Count** | facility-wide |

**Ability:** The rain soaks through, and the accumulated sorrow seeps into everyone exposed.. **[[7-11 Deep Blue DMG [Deep Blue / Lament]]]**

## Trivia

- The ocean's faces are not random. They are every citizen who has ever died of grief in Somnarak. The R.D. has identified six thousand distinct faces. The ocean has been growing.
- Spawn count: 1–3 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-BLUE-Tide-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
