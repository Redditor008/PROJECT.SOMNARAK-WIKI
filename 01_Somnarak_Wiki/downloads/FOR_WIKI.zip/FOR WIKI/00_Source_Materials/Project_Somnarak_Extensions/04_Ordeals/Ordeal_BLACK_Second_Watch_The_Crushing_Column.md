# BLACK Second Watch — The Crushing Column

> *""It walked like a pillar that had learned to hate the floor.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | BLACK |
| **Time** | Second Watch |
| **Threat Level** | Moderate |
| **Han Source** | Weight |
| **Physical Form** | Non-Organic — Three-meter dark columns, roughly humanoid in proportion but featureless, of dense black Weight-crystal. They move with slow deliberate steps that crack the floor; dense, heavy, unstoppable at walking pace. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 5–8 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 8–19 per hit · Weight (Black) |
| **HP** | 155/155 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Forms when Weight Han reaches Second Watch density. The spheres merge into taller, more structured entities.

## Appearance

3-meter-tall dark columns, roughly humanoid in proportion but featureless. They move with slow, deliberate steps that crack the floor with each footfall. Dense, heavy, unstoppable at walking pace.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Crush Stomp** | Each step deals area physical damage. | All personnel within 2 meters of a footfall take 10–15 Resilience damage and are knocked prone. |
| **Body Slam** | The column leans forward and falls on a target. | Deals 20–30 Resilience damage. Targets pinned beneath must be freed by teammates. |

## Suppression Protocol

Physical force. Moderate HP. Target the base — the column topples when its lower section is damaged enough. Speed-based teams can outmaneuver them easily. Do NOT engage in narrow corridors.

## Facility Impact

If unsuppressed: march for 90 seconds, cracking corridors. May trigger secondary breaches by damaging containment walls.

## R.D. Response Protocol

Alert Level 2. Level 3+ team. Structural repair crew on standby. Wide corridors preferred for engagement.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary BLACK Second Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Grinding Maw (Monster, Greater-grade)

**Physical Form:** Monster — A massive low-slung beast the width of a cart, its body formed of interlocking slabs of dense black basalt fused over taut grey muscle and exposed ribs of dark iron. It has no head — only a wide, flat mouth of grinding stone teeth set in raw flesh, the gums wet and black, that rolls over whatever is beneath it. When it moves, the stone plates grind against each other and the muscle beneath ripples visibly, as though the rock is a shell and the thing inside is still alive and hungry..

| Stat | Value |
|---|---|
| **HP** | 220/220 out of 1000 |
| **Han Pressure [ATK]** | 15–30 per hit · Weight |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[15-30 Black DMG [Black / Weight]]**

### The Stacked Spine (Non-Crystal, Greater-grade)

**Physical Form:** Non-Crystal — A vertical pillar of fused human vertebrae lashed together with dried sinew and desiccated muscle, three stories tall. It sways like something balancing a weight it can never set down, and where it tilts, the floor cracks.

| Stat | Value |
|---|---|
| **HP** | 250/250 out of 1000 |
| **Han Pressure [ATK]** | 20–35 per hit · Weight |
| **Spawn Count** | 2–2 |

**Ability:** It leans, and the full dead weight of the stack comes down on whatever stands beneath. 

### The Living Avalanche (Non-Humanoid, Greater-grade)

**Physical Form:** Non-Humanoid — Not a single body but a flowing mass — a cascade of sharp-edged black stone fragments and twisted iron rebar that moves like a landslide, burying and crushing. Scattered through the debris are clumps of compressed organic matter: dark flesh, hair, bone fragments from whatever it has already consumed, ground into the aggregate. It has no shape; it IS the shape of the ground it covers, and the ground is hungry..

| Stat | Value |
|---|---|
| **HP** | 280/280 out of 1000 |
| **Han Pressure [ATK]** | 25–40 per hit · Weight |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[25-40 Black DMG [Black / Weight]]**


### The Ledger-Man (Humanoid, Greater-grade)

**Physical Form:** Humanoid — A humanoid of stacked leaden flesh-plates, each slab engraved like a debt entry, walking stiffly beneath the accumulated weight of every unpaid account.

| Stat | Value |
|---|---|
| **HP** | 240/240 out of 1000 |
| **Han Pressure [ATK]** | 18-30 per hit · Weight |
| **Spawn Count** | 2 |

**Ability:** It bears down on a target, and the stacked weight of old debts pins them.. **[[18-30 Black DMG [Black / Weight]]]**

### The Tar-Pit (Amorphous, Greater-grade)

**Physical Form:** Amorphous — A spreading pool of thick black organic tar that moves like something alive — slow, heavy, and hungry, dragging itself across the floor in a viscous skin.

| Stat | Value |
|---|---|
| **HP** | 220/220 out of 1000 |
| **Han Pressure [ATK]** | 16-26 per hit · Weight |
| **Spawn Count** | 1 |

**Ability:** Whatever steps in is caught; the living tar drags them down by sheer mass.. **[[16-26 Black DMG [Black / Weight]]]**

### The Weight-Leeches (Swarm, Greater-grade)

**Physical Form:** Swarm — Heavy black leeches the length of a forearm that drop from above and cling, each one dense as iron and adding its weight to the host.

| Stat | Value |
|---|---|
| **HP** | 50/50 out of 1000 |
| **Han Pressure [ATK]** | 8-12 per hit · Weight |
| **Spawn Count** | 8–12 |

**Ability:** They latch on, and the accumulated weight drags the bearer to the ground.. **[[8-12 Black DMG [Black / Weight]]]**

## Trivia

- The columns leave footprints that persist for days — deep impressions in solid Han-crystal, as if the floor remembers being stepped on.
- Spawn count: 5–8 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-BLACK-Second-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
