# BLUE Second Watch — The Wailing Choir

> *""They learned to sing together. That is when it became dangerous.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | BLUE |
| **Time** | Second Watch |
| **Threat Level** | Moderate |
| **Han Source** | Lament |
| **Physical Form** | Mixed — Adult-sized translucent blue figures, mouths open in continuous wailing, standing in formation facing inward as if performing. Half-light, half-damp, they smell of cold rain; the sound is unbearably sad. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 5–8 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 8–19 per hit · Lament (Deep Blue) |
| **HP** | 162/162 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Forms when Lament Han reaches Second Watch density. The individual weeping figures of a First Watch Ordeal that were not suppressed harmonize into a coordinated choir.

## Appearance

Taller than First Watch figures — adult-sized, translucent blue, mouths open in continuous wailing. They stand in formation, facing inward, as if performing.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Harmonized Wail** | The choir synchronizes its wailing into a single resonant frequency. | Area Composure drain — all personnel on the floor lose 5–10 Composure per turn. M.A.W. audio shielding partially mitigates. |
| **Resonant Collapse** | Three or more choir members focus their wail on a single target. | Target loses 15–25 Composure in one turn and may freeze, unable to act, for 1 turn. |

## Suppression Protocol

Physical force. Moderate HP per figure. Destroy the choir members one by one to break the harmony — each destroyed member reduces the area effect. Audio-shielded M.A.W. (δ-grade) recommended for the suppression team.

## Facility Impact

If unsuppressed: the choir performs for 90 seconds, then dissolves. Personnel with drained Composure report vivid, unwanted grief-memories for days.

## R.D. Response Protocol

Alert Level 2. Level 3+ team with audio-shielded M.A.W. recommended. Containment Lead notified.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary BLUE Second Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Weeping Leviathan (Monster, Greater-grade)

**Physical Form:** Monster — A long serpentine creature fully twenty meters from snout to tail, its body composed of translucent blue-grey skin stretched over visible ribs and a pulsing spine. Through the skin, organs are faintly visible — dark, wet, slowly churning. It has no eyes; its head is a wide, soft mouth that opens to release a keening wail, and from the corners of that mouth, actual tears stream — not water, but condensed sorrow, viscous and faintly luminescent, evaporating into fog as they fall..

| Stat | Value |
|---|---|
| **HP** | 220/220 out of 1000 |
| **Han Pressure [ATK]** | 15–30 per hit · Lament |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[15-30 Deep Blue DMG [Deep Blue / Lament]]**

### The Throat-Knot (Non-Crystal, Greater-grade)

**Physical Form:** Non-Crystal — A writhing knot of dozens of human throats and tongues bound together by vocal cord and vein, with no bodies attached. Each throat wails a different note of a song no one finished, and the knot contracts with every sound it makes.

| Stat | Value |
|---|---|
| **HP** | 250/250 out of 1000 |
| **Han Pressure [ATK]** | 20–35 per hit · Lament |
| **Spawn Count** | 2–2 |

**Ability:** It keens, and the harmony of unfinished grief frays the composure of all who hear it. 

### The Sorrow Fog (Non-Humanoid, Greater-grade)

**Physical Form:** Non-Humanoid — A drifting bank of luminous blue mist that fills corridors and rooms — not a creature but a presence, the condensed grief of the Sorrow Tide made airborne. Within the fog, shapes move: half-formed, dissolving — faces, hands, the silhouettes of people who are not there. The mist is cold, damp, and clings to the skin like grief itself, and breathing it fills the lungs with an ache that has no physical source..

| Stat | Value |
|---|---|
| **HP** | 280/280 out of 1000 |
| **Han Pressure [ATK]** | 25–40 per hit · Lament |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[25-40 Deep Blue DMG [Deep Blue / Lament]]**


### The Mourner (Humanoid, Greater-grade)

**Physical Form:** Humanoid — A shrouded humanoid whose veils are sodden membrane, face hidden, humming a dirge that frays the sanity of all who hear it.

| Stat | Value |
|---|---|
| **HP** | 230/230 out of 1000 |
| **Han Pressure [ATK]** | 16-26 per hit · Lament |
| **Spawn Count** | 2 |

**Ability:** The dirge deepens, and unfinished mourning grinds the listener down.. **[[16-26 Deep Blue DMG [Deep Blue / Lament]]]**

### The Salt-Bloom (Amorphous, Greater-grade)

**Physical Form:** Amorphous — A spreading bloom of pale, brine-weeping organic tissue that crusts the walls in salt wherever it grows.

| Stat | Value |
|---|---|
| **HP** | 210/210 out of 1000 |
| **Han Pressure [ATK]** | 14-22 per hit · Lament |
| **Spawn Count** | 1 |

**Ability:** Its brine-spray stings the eyes, and the sorrow-burn settles into the mind.. **[[14-22 Deep Blue DMG [Deep Blue / Lament]]]**

### Grief-Leeches (Swarm, Greater-grade)

**Physical Form:** Swarm — Small leeches of thin membrane swollen with blue fluid, attaching to drink sorrow directly from the skin.

| Stat | Value |
|---|---|
| **HP** | 45/45 out of 1000 |
| **Han Pressure [ATK]** | 7-10 per hit · Lament |
| **Spawn Count** | 8–12 |

**Ability:** They latch, and each one drains a little more of the will to keep going.. **[[7-10 Deep Blue DMG [Deep Blue / Lament]]]**

## Trivia

- The choir's 'song' has been transcribed. It matches no known Somnarak melody but resembles a lullaby sung backward.
- Spawn count: 5–8 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-BLUE-Second-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
