# PURPLE First Watch — The Seeping

> *""The wall turned purple and started breathing.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | PURPLE |
| **Time** | First Watch |
| **Threat Level** | Minor |
| **Han Source** | Raw Han / corruption |
| **Physical Form** | Mixed — Two to three purple-tinged amorphous masses of raw Han, about a meter across, clinging to walls, floors, and ceilings. They pulse like breathing organisms and emit a faint dissonant hum; half-flesh, half-corruption. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 8–12 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 2–8 per hit · Raw Han (Purple) |
| **HP** | 50/50 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Spawned when raw, unprocessed Han reaches the First Watch threshold. The Han leaks from the facility's Han-flow channels and forms surface masses.

## Appearance

2–3 purple-tinged amorphous masses of raw Han, approximately 1 meter across, clinging to walls, floors, and ceilings. They pulse like breathing organisms and emit a faint, dissonant hum.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Spread** | Each mass slowly expands, covering surfaces with a film of raw Han. | Personnel who touch the film experience temporary Fracture symptoms: grey skin, dark veins, altered eyes. The effect lasts the rest of the shift. |
| **Pulse** | The mass pulses every 10 seconds, emitting a wave of raw Han. | All within 3 meters take 3–5 damage to ALL stats (Composure, Resilience, Clarity, Resolve simultaneously). |

## Suppression Protocol

Physical force destroys the central mass. The film must be burned away (Ferrehan — sustained presence while another agent destroys the core). Moderate HP on the core. The film itself is a hazard, not an entity.

## Facility Impact

If unsuppressed: expand for 60 seconds, covering up to 5 meters of surface area each. The film dissipates after 2 minutes, but Fracture symptoms persist.

## R.D. Response Protocol

Alert Level 1. Standard team. Ferrehan support for film cleanup. Do NOT touch the film with bare skin.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary PURPLE First Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Parasite Bloom (Monster, Fragment-grade)

**Physical Form:** Monster — A bloated, pulsing mass of wet purple flesh shaped like an enormous flower-head, two meters across. Its petals are thick, veined, and glistening with a viscous fluid that smells of rot and fermentation. At its centre is a gaping maw lined with rows of soft, translucent tendrils that drip spore-laden gas. The whole thing shudders and contracts rhythmically, like a heart, and where it sits, the floor darkens and softens, as though the biomass is slowly digesting the surface beneath it..

| Stat | Value |
|---|---|
| **HP** | 120/120 out of 1000 |
| **Han Pressure [ATK]** | 8–18 per hit · Mixed |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[8-18 Crimson (HP) -> 8 Deep Blue (Sanity) -> 8 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**

### The Spore-Heap (Non-Crystal, Fragment-grade)

**Physical Form:** Non-Crystal — A waist-high mound of fungal mycelium, rotting wet wood, and bracket-gilled growths that pulses faintly and leaks a fine cloud of rust-coloured spores. Threads of fungus spread outward from it into every surface it touches.

| Stat | Value |
|---|---|
| **HP** | 150/150 out of 1000 |
| **Han Pressure [ATK]** | 13–23 per hit · Mixed |
| **Spawn Count** | 2–2 |

**Ability:** It puffs, and a cloud of invasive spores takes root in whatever lungs it reaches. **[13-23 Crimson (HP) -> 13 Deep Blue (Sanity) -> 13 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**

### The Root Network (Non-Humanoid, Fragment-grade)

**Physical Form:** Non-Humanoid — A spreading system of thick, fibrous roots that erupt from the floor, walls, and ceiling — not a single entity but a connected organism, a living infrastructure. The roots are purple, wet, and ridged, covered in fine translucent hairs that wave and seek. Where they meet, they fuse into thick knots that pulse with shared Han-fluid. The network grows visibly — a new root erupts every few seconds, reaching for warmth, for movement, for anything alive that it can wrap around and feed from..

| Stat | Value |
|---|---|
| **HP** | 180/180 out of 1000 |
| **Han Pressure [ATK]** | 18–28 per hit · Mixed |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[18-28 Crimson (HP) -> 18 Deep Blue (Sanity) -> 18 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**


### The Bloom-Bearer (Humanoid, Fragment-grade)

**Physical Form:** Humanoid — A humanoid whose body is riddled with sprouting fungal growths and leaking spore-pustules, moving as if guided by what grows in it.

| Stat | Value |
|---|---|
| **HP** | 170/170 out of 1000 |
| **Han Pressure [ATK]** | 12-20 per hit · Mixed |
| **Spawn Count** | 2 |

**Ability:** It bursts a pustule, and a spray of spores takes root in nearby lungs.. **[[12-20 Crimson (HP) -> 12-20 Deep Blue (Sanity) -> 12-20 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

### The Slime (Amorphous, Fragment-grade)

**Physical Form:** Amorphous — A creeping mat of pinkish organic slime that spreads across surfaces, digesting whatever it covers.

| Stat | Value |
|---|---|
| **HP** | 150/150 out of 1000 |
| **Han Pressure [ATK]** | 10-16 per hit · Mixed |
| **Spawn Count** | 1 |

**Ability:** It washes over, and the digestive slime begins to break down whatever it touches.. **[[10-16 Crimson (HP) -> 10-16 Deep Blue (Sanity) -> 10-16 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

### Spore-Gnats (Swarm, Fragment-grade)

**Physical Form:** Swarm — Tiny gnats trailing clouds of pale spores that land, root, and bloom in whatever they settle on.

| Stat | Value |
|---|---|
| **HP** | 30/30 out of 1000 |
| **Han Pressure [ATK]** | 5-8 per hit · Mixed |
| **Spawn Count** | 8–12 |

**Ability:** They swarm, and a fog of spores seeds everything that breathes.. **[[5-8 Crimson (HP) -> 5-8 Deep Blue (Sanity) -> 5-8 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

## Trivia

- The Seeping is the sound of the Weeping leaking upward. The R.D. Han-flow channels are not perfectly sealed.
- Spawn count: 8–12 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-PURPLE-First-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
