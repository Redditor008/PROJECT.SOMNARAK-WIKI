# BLUE First Watch — The Weeping Cluster

> *""A sound like every funeral at once, leaking from the walls.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | BLUE |
| **Time** | First Watch |
| **Threat Level** | Minor |
| **Han Source** | Lament |
| **Physical Form** | Mixed — Knee-high, child-sized translucent figures, blue-tinged, faces hidden in folded hands. They drift rather than walk, and their weeping is audible across the floor; half-light, half-damp, they smell of cold rain. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 8–12 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 3–9 per hit · Lament (Deep Blue) |
| **HP** | 51/51 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Spawned when accumulated Lament Han in the facility's corridors reaches the First Watch threshold. The Han coalesces into child-sized manifestations of pure grief.

## Appearance

Knee-high, child-sized translucent figures, blue-tinged, faces hidden in folded hands. They drift, they do not walk. Their weeping is audible across the floor.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Drift** | They drift toward personnel, drawn by emotional presence. | Composure drain — sustained wailing reduces Composure by 2–4 per turn per figure in range. |
| **Swarm** | Multiple figures converge on a single target, overlapping their wails. | Stacking Composure drain — 3+ figures in range can incapacitate a team emotionally before they finish clearing the corridor. |

## Suppression Protocol

Physical force (any damage type). Very low HP per figure. Clear the corridor quickly before the swarm stacks. Ear protection reduces but does not eliminate the Composure drain.

## Facility Impact

If unsuppressed: wander for 60 seconds, then burrow into walls and reappear on another floor. Composure-drained personnel may be incapacitated for the rest of the shift.

## R.D. Response Protocol

Alert Level 1. Dispatch a standard suppression team (Level 2+). Ear protection issued. No Containment Lead oversight required.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary BLUE First Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Weeping Leviathan (Monster, Fragment-grade)

**Physical Form:** Monster — A long serpentine creature fully twenty meters from snout to tail, its body composed of translucent blue-grey skin stretched over visible ribs and a pulsing spine. Through the skin, organs are faintly visible — dark, wet, slowly churning. It has no eyes; its head is a wide, soft mouth that opens to release a keening wail, and from the corners of that mouth, actual tears stream — not water, but condensed sorrow, viscous and faintly luminescent, evaporating into fog as they fall..

| Stat | Value |
|---|---|
| **HP** | 120/120 out of 1000 |
| **Han Pressure [ATK]** | 8–18 per hit · Lament |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[8-18 Deep Blue DMG [Deep Blue / Lament]]**

### The Weeping Sac (Non-Crystal, Fragment-grade)

**Physical Form:** Non-Crystal — A cluster of raw pink membrane-sacs, each head-sized and translucent with pooled tears. A single unblinking eye floats in every sac, and the cluster drips a steady salt-burn trickle down whatever wall it clings to.

| Stat | Value |
|---|---|
| **HP** | 150/150 out of 1000 |
| **Han Pressure [ATK]** | 13–23 per hit · Lament |
| **Spawn Count** | 2–2 |

**Ability:** It bursts, and a spray of grief-saturated fluid eats at the minds of all it touches. 

### The Sorrow Fog (Non-Humanoid, Fragment-grade)

**Physical Form:** Non-Humanoid — A drifting bank of luminous blue mist that fills corridors and rooms — not a creature but a presence, the condensed grief of the Sorrow Tide made airborne. Within the fog, shapes move: half-formed, dissolving — faces, hands, the silhouettes of people who are not there. The mist is cold, damp, and clings to the skin like grief itself, and breathing it fills the lungs with an ache that has no physical source..

| Stat | Value |
|---|---|
| **HP** | 180/180 out of 1000 |
| **Han Pressure [ATK]** | 18–28 per hit · Lament |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[18-28 Deep Blue DMG [Deep Blue / Lament]]**


### The Sobbing (Humanoid, Fragment-grade)

**Physical Form:** Humanoid — A slight humanoid of translucent weeping skin, eyes forever overflowing, mouth open in a silent wail that never quite becomes sound.

| Stat | Value |
|---|---|
| **HP** | 170/170 out of 1000 |
| **Han Pressure [ATK]** | 12-20 per hit · Lament |
| **Spawn Count** | 2 |

**Ability:** Its weeping reaches a target, and the grief frays at the edges of the mind.. **[[12-20 Deep Blue DMG [Deep Blue / Lament]]]**

### The Puddle (Amorphous, Fragment-grade)

**Physical Form:** Amorphous — A wide, still puddle of tears that reflects no one, rippling when stepped in and rising to cling.

| Stat | Value |
|---|---|
| **HP** | 150/150 out of 1000 |
| **Han Pressure [ATK]** | 10-16 per hit · Lament |
| **Spawn Count** | 1 |

**Ability:** It swallows a foot, and the cold grief seeps up through the body.. **[[10-16 Deep Blue DMG [Deep Blue / Lament]]]**

### Tear-Mites (Swarm, Fragment-grade)

**Physical Form:** Swarm — Tiny pale mites that weep, leaving salt-trails behind them, swarming in damp corners and pooling wherever they gather.

| Stat | Value |
|---|---|
| **HP** | 30/30 out of 1000 |
| **Han Pressure [ATK]** | 5-8 per hit · Lament |
| **Spawn Count** | 8–12 |

**Ability:** They swarm, and the collective tiny grief of thousands eats at composure.. **[[5-8 Deep Blue DMG [Deep Blue / Lament]]]**

## Trivia

- The weeping sounds like a specific grief each listener has personally experienced. No two personnel hear the same funeral.
- Spawn count: 8–12 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-BLUE-First-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
