# PALE Tide Watch — The Nothing

> *""It was not darkness. Darkness is something. This was the absence of something.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | PALE |
| **Time** | Tide Watch |
| **Threat Level** | Catastrophic |
| **Han Source** | Void |
| **Physical Form** | Non-Organic — A shape difficult to perceive — not invisible but 'not-there': a hole in reality, roughly humanoid and three meters tall. It moves by erasing the space ahead and filling in behind; where it walks, the corridor is permanently, subtly less real. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 1–3 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 37–104 per hit · Void (Pale White) |
| **HP** | 650/650 out of 1000 per entity |
| **Instant Fracture** | Yes — on critical hits / special abilities |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

The Pale Tide Watch Ordeal. Only spawns during the Sorrow Tide. The accumulated Void Han of the facility coalesces into a single point of pure erasure — an entity that is defined by what it is not.

## Appearance

A shape that is difficult to perceive — not invisible, but rather 'not-there.' Personnel looking at it see a hole in reality, a place where the facility simply stops existing. It is roughly humanoid, roughly 3 meters tall, and it moves by erasing the space ahead of it and filling in behind. Where it walks, the corridor is permanently, subtly less real.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Erasure Aura** | All reality within 5 meters of The Nothing begins to fade. | Personnel in range lose 20–30 Clarity per turn. Equipment ceases to function. The corridor itself becomes less defined — walls soften, floors lose texture, sounds dampen. |
| **The Touch of Nothing** | The Nothing reaches for a target and touches them. | The target does not die. They are erased. Their body remains, functional, breathing — but the person inside is gone. An empty shell. This is the Somnarak equivalent of Instant Death: Instant Erasure. |
| **Propagation** | Every 3 turns, The Nothing spawns a Pale First Watch fragment. | The fragments spread the erasure zone, forcing the suppression team to split between The Nothing and its spawn. |

## Suppression Protocol

The Nothing has extremely high HP and is resistant to most damage types. Only Void-aligned M.A.W. (weapons forged from Void-element entities) deal full damage. Physical and emotional attacks are partially erased on contact. The suppression team must include Flerehan support to anchor personnel against erasure, and Viderehan to track The Nothing's position (it is hard to perceive). Instant Erasure victims cannot be recovered — their shells must be evacuated. Echo-Core command required.

## Facility Impact

If unsuppressed: The Nothing walks through the facility for 180 seconds, erasing everything and everyone in its path. The corridor it walked through becomes permanently 'less real' — a faded, dreamlike space where identity is unstable. Any personnel touched by The Nothing are gone. Their shells breathe. No one is home.

## R.D. Response Protocol

Alert Level 5. All available combat personnel with Void-aligned M.A.W. Echo-Core direct command. Full facility evacuation of The Nothing's projected path. This is the most feared Tide Watch Ordeal — the only one that permanently erases rather than damages.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary PALE Tide Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Eyeless Hound (Monster, Tide-Spawn-grade)

**Physical Form:** Monster — A pale beast, lean and silent, its skin like wet parchment stretched too tight over visible bone — every rib, every joint, every ridge of the skull visible through the translucent white membrane. It has no eyes, no mouth, no ears — just the smooth tight skin where features should be, and yet it tracks its prey with perfect precision, drawn not by sight or scent but by the presence of identity, which it seeks to erase. Its paws leave no prints. Where it passes, the floor is faintly faded..

| Stat | Value |
|---|---|
| **HP** | 500/500 out of 1000 |
| **Han Pressure [ATK]** | 35–60 per hit · Void |
| **Spawn Count** | 1–3 |

**Ability:** Deals damage themed to its form and element. **[2 Pale White DMG [Pale White / Void] (5% Max HP)]**

### The Hollow (Non-Crystal, Tide-Spawn-grade)

**Physical Form:** Non-Crystal — A humanoid shell of dried parchment-skin stitched tight over absolutely nothing — no bone, no organ, only a vacuum. It inhales, and the air, the light, and the identity of everything nearby lean toward the nothing inside it.

| Stat | Value |
|---|---|
| **HP** | 530/530 out of 1000 |
| **Han Pressure [ATK]** | 40–65 per hit · Void |
| **Spawn Count** | 1–3 |

**Ability:** It inhales, and the void within un-makes a portion of whoever is drawn in. 

### The Geometric Void (Non-Humanoid, Tide-Spawn-grade)

**Physical Form:** Non-Humanoid — A shifting polyhedron of pure white light — not a creature, not a machine, but a piece of folded space, a gap in reality that rotates slowly through the area. Its edges do not reflect; they erase. Whatever an edge passes through — a wall, a desk, a hand — simply becomes less there, faded, translucent, as if reality were a page and the polyhedron were an eraser dragged slowly across it. It has no centre, no mass, no intent.

| Stat | Value |
|---|---|
| **HP** | 560/560 out of 1000 |
| **Han Pressure [ATK]** | 45–70 per hit · Void |
| **Spawn Count** | 1–3 |

**Ability:** It simply is, and what it touches, isn't.. **[3 Pale White DMG [Pale White / Void] (5% Max HP)]**


### The Erased King (Humanoid, Tide-Spawn-grade)

**Physical Form:** Humanoid — A towering humanoid that is more absence than form — a hole in the world shaped like a crowned king, walking.

| Stat | Value |
|---|---|
| **HP** | 400/400 out of 1000 |
| **Han Pressure [ATK]** | 3 unit per hit · Void |
| **Spawn Count** | 1 |

**Ability:** Its shadow falls, and a portion of whoever it crosses simply stops existing.. **[[3 Pale White DMG [Pale White / Void] (5% Max HP)]]**

### The Null (Amorphous, Tide-Spawn-grade)

**Physical Form:** Amorphous — A moving pocket of total nothing, a hole in the air that deletes whatever matter it overlaps.

| Stat | Value |
|---|---|
| **HP** | 380/380 out of 1000 |
| **Han Pressure [ATK]** | 3 unit per hit · Void |
| **Spawn Count** | 1 |

**Ability:** It drifts through a crowd, and those it touches are gone, wholly, quietly.. **[[3 Pale White DMG [Pale White / Void] (5% Max HP)]]**

### The Undoing (Swarm, Tide-Spawn-grade)

**Physical Form:** Swarm — A swarm of micro-erasures, each one a tiny gap in reality, that unmake matter grain by grain.

| Stat | Value |
|---|---|
| **HP** | 35/35 out of 1000 |
| **Han Pressure [ATK]** | 1 unit per hit · Void |
| **Spawn Count** | facility-wide |

**Ability:** They settle, and whatever they cover is steadily, silently unmade.. **[[1 Pale White DMG [Pale White / Void] (5% Max HP)]]**

## Trivia

- The Nothing is not hostile. It does not attack. It simply continues to exist, and to exist is to erase. It is the most patient entity in the facility. It has nowhere to be. It is already there.
- Spawn count: 1–3 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-PALE-Tide-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
