# PALE Third Watch — The Whiteout

> *""The corridor turned white. Not bright — empty. As if someone had erased the color and forgotten to put anything back.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | PALE |
| **Time** | Third Watch |
| **Threat Level** | Major |
| **Han Source** | Void |
| **Physical Form** | Non-Organic — A zone of pure white — a sphere of erasure about five meters across, expanding slowly — within which everything loses identity: colors fade, sounds vanish, names dissolve. At its center, a dense pale core, the only solid thing in the whiteout. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 3–5 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 18–35 per hit · Void (Pale White) |
| **HP** | 375/375 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Forms when Void Han reaches Third Watch density. The legion's erasure effect coalesces into a spreading zone rather than individual figures.

## Appearance

A zone of pure white — a sphere of erasure approximately 5 meters in radius, expanding slowly through the facility. Within the zone, everything loses identity: colors fade, sounds vanish, names dissolve. At the zone's center is a dense, pale core — the only solid thing in the whiteout.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Expansion** | The zone expands at 0.5 m/s in all directions. | All personnel within the zone lose 15–20 Clarity per turn. Equipment stops functioning. Signs, records, and identifiers within the zone are erased. |
| **The Core** | The pale core at the center is the entity's heart. | The core has high HP. Destroying it collapses the entire zone instantly — but reaching it requires passing through the erasure field, losing Clarity with every step. |
| **Afterimage** | Personnel who exit the zone leave behind 'afterimages' — faint copies that persist for 1 turn. | Afterimages can be mistaken for personnel, causing confusion. They fade on their own but may trigger friendly fire. |

## Suppression Protocol

Ranged M.A.W. to damage the core from outside the zone. If the core is not reachable by ranged weapons, a volunteer must enter the zone (Ferrehan — endure the Clarity drain) to reach and destroy the core. Flerehan support at the zone's edge to restore exiting personnel.

## Facility Impact

If unsuppressed: the zone expands for 120 seconds, then contracts and vanishes. Everything inside the expanded zone is permanently erased — signs, records, identifiers, memories. The facility must re-document the affected area.

## R.D. Response Protocol

Alert Level 3. Level 4+ team. Ranged M.A.W. essential. Volunteer for zone entry must have maximum Clarity baseline. Containment Lead oversight.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary PALE Third Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Eyeless Hound (Monster, Elite-grade)

**Physical Form:** Monster — A pale beast, lean and silent, its skin like wet parchment stretched too tight over visible bone — every rib, every joint, every ridge of the skull visible through the translucent white membrane. It has no eyes, no mouth, no ears — just the smooth tight skin where features should be, and yet it tracks its prey with perfect precision, drawn not by sight or scent but by the presence of identity, which it seeks to erase. Its paws leave no prints. Where it passes, the floor is faintly faded..

| Stat | Value |
|---|---|
| **HP** | 350/350 out of 1000 |
| **Han Pressure [ATK]** | 25–45 per hit · Void |
| **Spawn Count** | 2–3 |

**Ability:** Deals damage themed to its form and element. **[1 Pale White DMG [Pale White / Void] (5% Max HP)]**

### The Skin-Blizzard (Non-Crystal, Elite-grade)

**Physical Form:** Non-Crystal — A swirling low storm of shed skin-flakes, cut hair, and nail-parings that moves as one body across the floor. There is no core — only the blizzard — and anything caught inside is flayed one translucent layer at a time.

| Stat | Value |
|---|---|
| **HP** | 380/380 out of 1000 |
| **Han Pressure [ATK]** | 30–50 per hit · Void |
| **Spawn Count** | 2–3 |

**Ability:** It engulfs, and the erasure-peel strips a piece of the self away with every pass. 

### The Geometric Void (Non-Humanoid, Elite-grade)

**Physical Form:** Non-Humanoid — A shifting polyhedron of pure white light — not a creature, not a machine, but a piece of folded space, a gap in reality that rotates slowly through the area. Its edges do not reflect; they erase. Whatever an edge passes through — a wall, a desk, a hand — simply becomes less there, faded, translucent, as if reality were a page and the polyhedron were an eraser dragged slowly across it. It has no centre, no mass, no intent.

| Stat | Value |
|---|---|
| **HP** | 410/410 out of 1000 |
| **Han Pressure [ATK]** | 35–55 per hit · Void |
| **Spawn Count** | 2–3 |

**Ability:** It simply is, and what it touches, isn't.. **[2 Pale White DMG [Pale White / Void] (5% Max HP)]**


### The Void-Walker (Humanoid, Elite-grade)

**Physical Form:** Humanoid — A humanoid whose outline continuously erases and reforms, leaving a trailing wake of absence where its body should be.

| Stat | Value |
|---|---|
| **HP** | 280/280 out of 1000 |
| **Han Pressure [ATK]** | 2 unit per hit · Void |
| **Spawn Count** | 2 |

**Ability:** It passes through, and the void it carries unmakes a portion of the self.. **[[2 Pale White DMG [Pale White / Void] (5% Max HP)]]**

### The Whiteout (Amorphous, Elite-grade)

**Physical Form:** Amorphous — A wall of featureless white fog that advances in total silence, swallowing all detail into uniform blankness.

| Stat | Value |
|---|---|
| **HP** | 300/300 out of 1000 |
| **Han Pressure [ATK]** | 2 unit per hit · Void |
| **Spawn Count** | 1 |

**Ability:** It envelops, and everything inside loses its edges, its names, its form.. **[[2 Pale White DMG [Pale White / Void] (5% Max HP)]]**

### The Erasure-Motes (Swarm, Elite-grade)

**Physical Form:** Swarm — A blizzard of pale motes that dissolve whatever they touch into faint white powder.

| Stat | Value |
|---|---|
| **HP** | 50/50 out of 1000 |
| **Han Pressure [ATK]** | 1 unit per hit · Void |
| **Spawn Count** | 10–14 |

**Ability:** They swarm, and the touched feel themselves thinning toward transparency.. **[[1 Pale White DMG [Pale White / Void] (5% Max HP)]]**

## Trivia

- Personnel who have been inside the Whiteout report that the white is not empty — it is full of things that have been erased, pressing to get back in.
- Spawn count: 3–5 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-PALE-Third-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
