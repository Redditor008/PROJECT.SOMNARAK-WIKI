# BLACK First Watch — The Rolling Weight

> *""The floor cracked before we saw what was pressing down on it.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | BLACK |
| **Time** | First Watch |
| **Threat Level** | Minor |
| **Han Source** | Weight |
| **Physical Form** | Non-Organic — One-meter black spheres of dense Weight-crystal, featureless and smooth, radiating crushing pressure as they roll slowly along corridors. Lead-cold and impossibly heavy, they crack the floor beneath them. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 8–12 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 2–8 per hit · Weight (Black) |
| **HP** | 50/50 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Spawned when accumulated Weight Han reaches the First Watch threshold. The Han condenses into dense, heavy spheres.

## Appearance

1-meter-diameter black spheres, featureless, radiating crushing pressure. They roll slowly along corridors, leaving cracks in the floor.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Roll** | They roll toward personnel at a steady pace. | Physical damage — contact deals 5–8 Resilience damage. Personnel caught in the path are knocked down and pinned. |
| **Bounce** | On impact with a wall, they reverse direction. | Rebounding spheres are harder to predict and may hit personnel from behind. |

## Suppression Protocol

Physical force. Low HP. Speed is key — they cannot turn quickly, so flanking and hitting from the side is effective. Do NOT stand in their path.

## Facility Impact

If unsuppressed: continue rolling for 60 seconds, cracking corridors and damaging containment infrastructure. Structural damage is repairable but costly.

## R.D. Response Protocol

Alert Level 1. Standard team. Structural repair crew on standby.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary BLACK First Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Grinding Maw (Monster, Fragment-grade)

**Physical Form:** Monster — A massive low-slung beast the width of a cart, its body formed of interlocking slabs of dense black basalt fused over taut grey muscle and exposed ribs of dark iron. It has no head — only a wide, flat mouth of grinding stone teeth set in raw flesh, the gums wet and black, that rolls over whatever is beneath it. When it moves, the stone plates grind against each other and the muscle beneath ripples visibly, as though the rock is a shell and the thing inside is still alive and hungry..

| Stat | Value |
|---|---|
| **HP** | 120/120 out of 1000 |
| **Han Pressure [ATK]** | 8–18 per hit · Weight |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[8-18 Black DMG [Black / Weight]]**

### The Flesh-Boulder (Non-Crystal, Fragment-grade)

**Physical Form:** Non-Crystal — A boulder-sized mass of compressed human fat, matted hair, and calcified tendon rolled tight under a hide of scarred skin. Dense as quarried stone, it leaves a greasy black tallow-trail where it rolls. No face, no limbs — only weight, moving.

| Stat | Value |
|---|---|
| **HP** | 150/150 out of 1000 |
| **Han Pressure [ATK]** | 13–23 per hit · Weight |
| **Spawn Count** | 2–2 |

**Ability:** It rolls over a target, and the sheer tonnage of packed flesh drives the breath from the body. 

### The Living Avalanche (Non-Humanoid, Fragment-grade)

**Physical Form:** Non-Humanoid — Not a single body but a flowing mass — a cascade of sharp-edged black stone fragments and twisted iron rebar that moves like a landslide, burying and crushing. Scattered through the debris are clumps of compressed organic matter: dark flesh, hair, bone fragments from whatever it has already consumed, ground into the aggregate. It has no shape; it IS the shape of the ground it covers, and the ground is hungry..

| Stat | Value |
|---|---|
| **HP** | 180/180 out of 1000 |
| **Han Pressure [ATK]** | 18–28 per hit · Weight |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[18-28 Black DMG [Black / Weight]]**


### The Press (Humanoid, Fragment-grade)

**Physical Form:** Humanoid — A squat humanoid of compacted stone-dense flesh, wider than tall, knuckles dragging the floor. It carries its own immense weight like a thing born only to lower itself onto what it hates.

| Stat | Value |
|---|---|
| **HP** | 180/180 out of 1000 |
| **Han Pressure [ATK]** | 14-22 per hit · Weight |
| **Spawn Count** | 1–2 |

**Ability:** It drops its full weight onto a pinned target, flattening them under dense flesh.. **[[14-22 Black DMG [Black / Weight]]]**

### The Slump (Amorphous, Fragment-grade)

**Physical Form:** Amorphous — A sagging heap of dense tallow-flesh with no fixed shape, oozing forward under its own weight and pooling in low places.

| Stat | Value |
|---|---|
| **HP** | 160/160 out of 1000 |
| **Han Pressure [ATK]** | 12-18 per hit · Weight |
| **Spawn Count** | 1 |

**Ability:** It oozes over the floor, smothering and crushing whatever it settles on.. **[[12-18 Black DMG [Black / Weight]]]**

### Cinder-Beetles (Swarm, Fragment-grade)

**Physical Form:** Swarm — Fist-sized black beetles of hardened chitin that roll in a clicking, tumbling carpet, each one dense as a stone.

| Stat | Value |
|---|---|
| **HP** | 40/40 out of 1000 |
| **Han Pressure [ATK]** | 6-10 per hit · Weight |
| **Spawn Count** | 8–10 |

**Ability:** They pile onto a single target, dozens of heavy bodies adding their weight.. **[[6-10 Black DMG [Black / Weight]]]**

## Trivia

- The spheres are warm to the touch, as if the Weight Han inside is under pressure.
- Spawn count: 8–12 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-BLACK-First-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
