# BLACK Third Watch — The Collapsing Arch

> *""It looked like a doorway. Then it fell, and the corridor came with it.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | BLACK |
| **Time** | Third Watch |
| **Threat Level** | Major |
| **Han Source** | Weight |
| **Physical Form** | Non-Organic — Five-meter entities shaped like fallen architecture — arches, lintels, collapsed doorways of dense black Han-crystal. They do not walk; they topple forward, crash, reform, and topple again, each impact devastating. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 3–5 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 18–34 per hit · Weight (Black) |
| **HP** | 354/354 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Forms when Weight Han reaches Third Watch density. The columns merge further into massive architectural entities.

## Appearance

5-meter-wide entities shaped like fallen architecture — arches, lintels, collapsed doorways made of dense black Han-crystal. They do not walk; they topple forward, crash, reform, and topple again. Each impact is devastating.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Topple** | The arch falls forward across a corridor. | Deals 25–40 Resilience damage to all in the fall zone. The corridor may partially collapse, blocking routes. |
| **Reform** | After falling, the crystal reforms into a new arch shape over 3 seconds. | The reforming period is the only window for safe damage — the arch is immobile and its core is exposed. |
| **Cascade** | If two arches are near each other, they may topple simultaneously. | Combined impact deals 50+ Resilience damage and can destroy containment walls. |

## Suppression Protocol

Physical force during the Reform window (3-second exposure). High HP. Target the keystone (the brightest point in the arch). δ-grade M.A.W. weapons required. Structural teams must repair corridors between engagements.

## Facility Impact

If unsuppressed: topple and reform for 120 seconds, progressively destroying the corridor. Structural damage may require days of repair and can permanently reduce facility capacity.

## R.D. Response Protocol

Alert Level 3. Level 4+ team with δ-grade M.A.W. Structural repair teams deployed immediately. Containment Lead oversight.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary BLACK Third Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Grinding Maw (Monster, Elite-grade)

**Physical Form:** Monster — A massive low-slung beast the width of a cart, its body formed of interlocking slabs of dense black basalt fused over taut grey muscle and exposed ribs of dark iron. It has no head — only a wide, flat mouth of grinding stone teeth set in raw flesh, the gums wet and black, that rolls over whatever is beneath it. When it moves, the stone plates grind against each other and the muscle beneath ripples visibly, as though the rock is a shell and the thing inside is still alive and hungry..

| Stat | Value |
|---|---|
| **HP** | 350/350 out of 1000 |
| **Han Pressure [ATK]** | 25–45 per hit · Weight |
| **Spawn Count** | 2–3 |

**Ability:** Deals damage themed to its form and element. **[25-45 Black DMG [Black / Weight]]**

### The Ribcage Arch (Non-Crystal, Elite-grade)

**Physical Form:** Non-Crystal — An arch wired from hundreds of human ribcages, strung with dried lung-tissue and tendon like rotten bunting. It stands only by tension — and is built to buckle inward, swallowing whatever passes beneath in a cage of bone.

| Stat | Value |
|---|---|
| **HP** | 380/380 out of 1000 |
| **Han Pressure [ATK]** | 30–50 per hit · Weight |
| **Spawn Count** | 2–3 |

**Ability:** It folds, and a closing tunnel of ribs entraps and presses everything within. 

### The Living Avalanche (Non-Humanoid, Elite-grade)

**Physical Form:** Non-Humanoid — Not a single body but a flowing mass — a cascade of sharp-edged black stone fragments and twisted iron rebar that moves like a landslide, burying and crushing. Scattered through the debris are clumps of compressed organic matter: dark flesh, hair, bone fragments from whatever it has already consumed, ground into the aggregate. It has no shape; it IS the shape of the ground it covers, and the ground is hungry..

| Stat | Value |
|---|---|
| **HP** | 410/410 out of 1000 |
| **Han Pressure [ATK]** | 35–55 per hit · Weight |
| **Spawn Count** | 2–3 |

**Ability:** Deals damage themed to its form and element. **[35-55 Black DMG [Black / Weight]]**


### The Anvil-Bearer (Humanoid, Elite-grade)

**Physical Form:** Humanoid — A hulking humanoid carrying a great anvil of fused bone across shoulders bowed permanently into the shape of the load it can never set down.

| Stat | Value |
|---|---|
| **HP** | 300/300 out of 1000 |
| **Han Pressure [ATK]** | 24-36 per hit · Weight |
| **Spawn Count** | 2 |

**Ability:** It brings the anvil down, and the carried weight of years lands at once.. **[[24-36 Black DMG [Black / Weight]]]**

### The Gravid Mass (Amorphous, Elite-grade)

**Physical Form:** Amorphous — A huge pulsating blob of compressed fat, gristle, and embedded bone-shards that rolls and rebounds, too heavy to lift, too dense to cut.

| Stat | Value |
|---|---|
| **HP** | 320/320 out of 1000 |
| **Han Pressure [ATK]** | 22-34 per hit · Weight |
| **Spawn Count** | 1 |

**Ability:** It rolls over a line, and the sheer tonnage flattens everything in its path.. **[[22-34 Black DMG [Black / Weight]]]**

### Maul-Grubs (Swarm, Elite-grade)

**Physical Form:** Swarm — Pale heavy grubs with calcified crushing jaws, each one as thick as a thigh, burrowing in concert through floor and flesh alike.

| Stat | Value |
|---|---|
| **HP** | 60/60 out of 1000 |
| **Han Pressure [ATK]** | 10-16 per hit · Weight |
| **Spawn Count** | 10–14 |

**Ability:** They bore in from below, dozens of heavy jaws grinding in unison.. **[[10-16 Black DMG [Black / Weight]]]**

## Trivia

- The arches resemble specific doorways in Somnarak — the entrances of buildings that collapsed during the Cheongula.
- Spawn count: 3–5 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-BLACK-Third-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
