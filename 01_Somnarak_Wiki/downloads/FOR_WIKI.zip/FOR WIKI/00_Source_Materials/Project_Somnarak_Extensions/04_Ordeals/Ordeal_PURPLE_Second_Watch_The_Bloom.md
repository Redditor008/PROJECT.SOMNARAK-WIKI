# PURPLE Second Watch — The Bloom

> *""It grew like a flower, if flowers were made of rage and bad decisions.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | PURPLE |
| **Time** | Second Watch |
| **Threat Level** | Moderate |
| **Han Source** | Raw Han / corruption |
| **Physical Form** | Mixed — Three to five purple Han-crystal growths resembling twisted thorny flora, each one to two meters tall and rooted to a surface. They pulse with internal light and bud smaller crystal fragments that detach and crawl; a corrupted garden. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 5–8 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 8–19 per hit · Raw Han (Purple) |
| **HP** | 158/158 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Forms when raw Han reaches Second Watch density. The Seeping masses crystallize into structured growths that spawn smaller fragments.

## Appearance

3–5 purple Han-crystal growths resembling twisted, thorny flora — each 1–2 meters tall, rooted to a surface. They pulse with internal light and periodically bud off smaller crystal fragments that detach and crawl.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Bloom** | The growth periodically buds a smaller fragment (every 15 seconds). | Each fragment is a mobile Purple First Watch-level entity that crawls toward personnel. If not destroyed, fragments accumulate rapidly. |
| **Thorn Burst** | When damaged, the growth fires crystal thorns in all directions. | Each thorn deals 8–12 damage to a random stat. Thorn-impacted personnel develop temporary Fracture symptoms at the impact site. |

## Suppression Protocol

Physical force. Destroy the growth (moderate HP) to stop fragment spawning. Clear existing fragments quickly before they overwhelm the team. The growth's core (the root) is the weak point. Area-effect M.A.W. recommended for fragment clearing.

## Facility Impact

If unsuppressed: the growths bloom for 90 seconds, spawning up to 15 fragments each. The fragments persist after the growths dissolve, becoming independent hazards.

## R.D. Response Protocol

Alert Level 2. Level 3+ team. Area-effect M.A.W. for fragments. Target the growth cores first.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary PURPLE Second Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Parasite Bloom (Monster, Greater-grade)

**Physical Form:** Monster — A bloated, pulsing mass of wet purple flesh shaped like an enormous flower-head, two meters across. Its petals are thick, veined, and glistening with a viscous fluid that smells of rot and fermentation. At its centre is a gaping maw lined with rows of soft, translucent tendrils that drip spore-laden gas. The whole thing shudders and contracts rhythmically, like a heart, and where it sits, the floor darkens and softens, as though the biomass is slowly digesting the surface beneath it..

| Stat | Value |
|---|---|
| **HP** | 220/220 out of 1000 |
| **Han Pressure [ATK]** | 15–30 per hit · Mixed |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[15-30 Crimson (HP) -> 15 Deep Blue (Sanity) -> 15 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**

### The Gut-Blossom (Non-Crystal, Greater-grade)

**Physical Form:** Non-Crystal — A blossom the size of a person, its petals stretched folds of stomach-lining, its stamen braided intestines, rooted in a bulb of packed viscera. It sways on a stem of bundled vein and nerve, and its scent is sweet rot.

| Stat | Value |
|---|---|
| **HP** | 250/250 out of 1000 |
| **Han Pressure [ATK]** | 20–35 per hit · Mixed |
| **Spawn Count** | 2–2 |

**Ability:** It exhales, and a mist of digestive pollen begins to break down whatever it settles on. **[20-35 Crimson (HP) -> 20 Deep Blue (Sanity) -> 20 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**

### The Root Network (Non-Humanoid, Greater-grade)

**Physical Form:** Non-Humanoid — A spreading system of thick, fibrous roots that erupt from the floor, walls, and ceiling — not a single entity but a connected organism, a living infrastructure. The roots are purple, wet, and ridged, covered in fine translucent hairs that wave and seek. Where they meet, they fuse into thick knots that pulse with shared Han-fluid. The network grows visibly — a new root erupts every few seconds, reaching for warmth, for movement, for anything alive that it can wrap around and feed from..

| Stat | Value |
|---|---|
| **HP** | 280/280 out of 1000 |
| **Han Pressure [ATK]** | 25–40 per hit · Mixed |
| **Spawn Count** | 2–2 |

**Ability:** Deals damage themed to its form and element. **[25-40 Crimson (HP) -> 25 Deep Blue (Sanity) -> 25 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**


### The Host (Humanoid, Greater-grade)

**Physical Form:** Humanoid — A humanoid colonized by a parasitic bloom, petals opening from its skin, limbs moved puppet-like by the growth within.

| Stat | Value |
|---|---|
| **HP** | 230/230 out of 1000 |
| **Han Pressure [ATK]** | 16-26 per hit · Mixed |
| **Spawn Count** | 2 |

**Ability:** It exhales pollen, and the parasitic spores begin to root in the breathers.. **[[16-26 Crimson (HP) -> 16-26 Deep Blue (Sanity) -> 16-26 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

### The Rot-Bloom (Amorphous, Greater-grade)

**Physical Form:** Amorphous — A vast spreading flower of corrupted tissue that exhales clouds of sweet, digestive pollen.

| Stat | Value |
|---|---|
| **HP** | 210/210 out of 1000 |
| **Han Pressure [ATK]** | 14-22 per hit · Mixed |
| **Spawn Count** | 1 |

**Ability:** Its pollen settles, and organic matter beneath it begins to soften and transform.. **[[14-22 Crimson (HP) -> 14-22 Deep Blue (Sanity) -> 14-22 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

### The Cord-Larvae (Swarm, Greater-grade)

**Physical Form:** Swarm — Small parasitic worms that seek the warmth of a living spine to burrow along.

| Stat | Value |
|---|---|
| **HP** | 45/45 out of 1000 |
| **Han Pressure [ATK]** | 7-10 per hit · Mixed |
| **Spawn Count** | 8–12 |

**Ability:** They burrow, and once inside they turn the host own reflexes against them.. **[[7-10 Crimson (HP) -> 7-10 Deep Blue (Sanity) -> 7-10 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

## Trivia

- The crystal growths resemble the Echo Gardens' grief-flowers, but inverted — beautiful, purple, and parasitic.
- Spawn count: 5–8 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-PURPLE-Second-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
