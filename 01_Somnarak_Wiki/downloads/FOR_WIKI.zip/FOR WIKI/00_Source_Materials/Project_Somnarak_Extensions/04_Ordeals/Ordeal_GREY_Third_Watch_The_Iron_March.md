# GREY Third Watch — The Iron March

> *""Metal on stone, stone on metal, and the sound of grinding teeth.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | GREY |
| **Time** | Third Watch |
| **Threat Level** | Major |
| **Han Source** | Grudge |
| **Physical Form** | Mixed — Three to five heavily armored entities — grey crystal fused into plate-like armor over a body within, weapons integrated (blade-arms, hammer-fists, shield-shoulders). They resemble warped, furious suits of armor; slower but far more durable. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 3–5 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 18–36 per hit · Grudge (Crimson) |
| **HP** | 389/389 out of 1000 per entity |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

Forms when Grudge Han reaches Third Watch density. The battalion's crystal weapons fuse with their bodies, creating mechanized, armored hostility.

## Appearance

3–5 heavily armored entities — grey crystal fused into plate-like armor covering their bodies. They are slower than previous Grey Ordeals but far more durable. Their weapons are integrated: blade-arms, hammer-fists, shield-shoulders. They resemble warped, furious suits of armor.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **Armor Stance** | The entity braces, reducing incoming damage by 50%. | Cannot be damaged effectively while bracing. Personnel must wait for the stance to drop (2 turns) or flank. |
| **Heavy Strike** | A devastating blow from an integrated weapon. | Deals 25–35 Resilience damage. Can shatter M.A.W. armor and breach containment walls. |
| **Grinding Advance** | The entity marches forward, weapons grinding against walls. | Corridor walls take structural damage. Narrow corridors become kill zones. |

## Suppression Protocol

Physical force. Very high HP and heavy armor. Armor Stance must be waited out or flanked. Area-effect M.A.W. weapons (bypassing armor) are effective. Teams must use wide corridors and avoid being cornered. The grind-damage to infrastructure is a secondary threat.

## Facility Impact

If unsuppressed: march and grind for 120 seconds. Corridors in their path are severely damaged. Containment walls may breach from the grinding.

## R.D. Response Protocol

Alert Level 3. Level 4+ team with area-effect M.A.W. Structural teams on standby. Wide-corridor engagement only.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary GREY Third Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Fury Hound (Monster, Elite-grade)

**Physical Form:** Monster — A grey-skinned beast the size of a draft horse, lean and corded with visible muscle beneath hairless, taut flesh the colour of old ash. Dark red Han-veins pulse beneath the skin like exposed arteries. Its jaws are too wide — they unhinge to reveal rows of jagged teeth that are not bone but compressed resentment, dark and jagged. It does not bark.

| Stat | Value |
|---|---|
| **HP** | 350/350 out of 1000 |
| **Han Pressure [ATK]** | 25–45 per hit · Grudge |
| **Spawn Count** | 2–3 |

**Ability:** It snarls, and the sound of the snarl is the voice of every person who was ever wronged and never answered.. **[25-45 Crimson DMG [Crimson / Grudge]]**

### The Bone-Legion (Non-Crystal, Elite-grade)

**Physical Form:** Non-Crystal — A marching rank of soldiers assembled from wired-together human bones — ribcage-shields, femur-blades, skulls under the arm — lashed with dried muscle, moving in perfect grinding lockstep despite having no flesh left to fight for.

| Stat | Value |
|---|---|
| **HP** | 380/380 out of 1000 |
| **Han Pressure [ATK]** | 30–50 per hit · Grudge |
| **Spawn Count** | 2–3 |

**Ability:** They charge, and a wall of bone-and-old-rage breaks whatever line they hit. 

### The Blade Storm (Non-Humanoid, Elite-grade)

**Physical Form:** Non-Humanoid — A swirling vortex of spinning blades — hundreds of forged-iron and resentment-steel shards orbiting a core of compressed fury, three meters across. The blades are not uniform: some are sword-fragments, some are nail-like spikes, some are twisted rebar, some are the ragged edges of broken tools, all spinning in a deafening ring. There is no body at the centre — only the anger that holds the metal in orbit, and the metal does the cutting..

| Stat | Value |
|---|---|
| **HP** | 410/410 out of 1000 |
| **Han Pressure [ATK]** | 35–55 per hit · Grudge |
| **Spawn Count** | 2–3 |

**Ability:** Deals damage themed to its form and element. **[35-55 Crimson DMG [Crimson / Grudge]]**


### The Veteran (Humanoid, Elite-grade)

**Physical Form:** Humanoid — A massive humanoid of layered scar-plate and weapon-fused arms — a walking arsenal of old, unhealed war.

| Stat | Value |
|---|---|
| **HP** | 300/300 out of 1000 |
| **Han Pressure [ATK]** | 24-36 per hit · Grudge |
| **Spawn Count** | 2 |

**Ability:** It wades in, and every fused weapon strikes at once in one sweeping assault.. **[[24-36 Crimson DMG [Crimson / Grudge]]]**

### The War-Smog (Amorphous, Elite-grade)

**Physical Form:** Amorphous — A rolling smog of burnt powder and ground bone that chokes the lungs and abrades the skin.

| Stat | Value |
|---|---|
| **HP** | 320/320 out of 1000 |
| **Han Pressure [ATK]** | 22-34 per hit · Grudge |
| **Spawn Count** | 1 |

**Ability:** It blankets a hall, and the grit of a thousand old battles scourges everyone within.. **[[22-34 Crimson DMG [Crimson / Grudge]]]**

### The Saw-Larvae (Swarm, Elite-grade)

**Physical Form:** Swarm — Armoured grubs with spinning toothed mouths that bore through shield and bone alike.

| Stat | Value |
|---|---|
| **HP** | 60/60 out of 1000 |
| **Han Pressure [ATK]** | 10-16 per hit · Grudge |
| **Spawn Count** | 10–14 |

**Ability:** They bore, and the spinning teeth grind through whatever they reach.. **[[10-16 Crimson DMG [Crimson / Grudge]]]**

## Trivia

- The armor resembles R.D. containment suits, inverted — as if the Grudge Han put on the face of its jailer and made it a weapon.
- Spawn count: 3–5 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-GREY-Third-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
