# PURPLE Tide Watch — The Fracture Wave

> *""The wall between human and sorrow came down. Not in one person. In everyone.""*

## Ordeal Classification

| Field | Value |
|---|---|
| **Color** | PURPLE |
| **Time** | Tide Watch |
| **Threat Level** | Catastrophic |
| **Han Source** | Raw Han / corruption |
| **Physical Form** | Non-Organic — Not an entity but a phenomenon — an expanding sphere of purple-black Han energy from a random point, growing at 2 m/s, within which the boundary between human and sorrow dissolves. At its center, a dense pulsing core — the detonation point. |
| **Dissolution** | Dissolves on suppression → residual Han (no vessel; not a sorrow-cored entity) |
| **Spawn Count** | 1–3 entities |
| **Mortality** | Mortal — permanently suppressible |
| **Han Pressure [ATK]** | 35–96 per hit · Raw Han (Purple) |
| **HP** | 676/676 out of 1000 per entity |
| **Instant Fracture** | Yes — on critical hits / special abilities |
| **Facility Zone** | All floors of the Hand of Change |
| **First Recorded** | Year 4210 |

## Formation

The Purple Tide Watch Ordeal. Only spawns during the Sorrow Tide. The accumulated raw Han of the facility reaches critical mass and detonates outward in a wave of pure Fracture energy — the most catastrophic Ordeal in the system.

## Appearance

Not a single entity but a **phenomenon** — a expanding sphere of purple-black Han energy that originates from a random point in the facility and expands at 2 m/s. Within the sphere, the boundary between human and sorrow dissolves. The air turns purple. Personnel within the sphere begin to Fracture — not from grief or sorrow, but from raw, undifferentiated Han exposure. The sphere's center contains a dense, pulsing core — the detonation point.

## Behavior

| Phase | Action | Effect |
|---|---|---|
| **The Wave** | The sphere expands at 2 m/s in all directions from the core. | All personnel within the sphere take 20–30 damage to ALL stats per turn and begin Stage 1 Fracture (The Crack — emotional sensitivity, mood swings). After 3 turns, Stage 2 (grey hair, dark veins). After 5 turns, Stage 3 (body reshaping). After 8 turns, Stage 4 (full Fracture — irreversible). |
| **The Spores** | The sphere's edge 'blooms' — spawning Purple First Watch and Second Watch fragments continuously. | The suppression team must fight through spawned fragments to reach the core. |
| **The Core Pulse** | The core pulses every 5 turns, expanding the sphere's radius by 5 meters. | Each pulse intensifies the Fracture effect within the sphere. Personnel who were at Stage 2 advance to Stage 3 on a pulse, etc. |
| **The Resonance** | Fully Fractured personnel (Stage 4) within the sphere become Purple Parasite entities. | New Parasites emerge from Fractured staff, adding to the threat count each turn. |

## Suppression Protocol

The ONLY priority is core destruction. Everything else is secondary. The core has extremely high HP but is vulnerable to Mixed-element and Void-element M.A.W. The suppression team must push through the sphere (taking Fracture damage every step), fight through spawned fragments, and destroy the core before the sphere consumes the facility. Ferrehan teams at the sphere's edge extract Fracturing personnel. Flerehan is useless — the Fracture is from raw Han, not sorrow. Echo-Core direct command. This is the worst-case scenario in the Ordeal system.

## Facility Impact

If unsuppressed: the sphere expands until it engulfs the entire Hand of Change (approximately 5 minutes). Every personnel member inside reaches Stage 4 Fracture. The facility is lost. The Director has standing authorization to activate the Absolvohan's emergency Han-flush if a Fracture Wave is not suppressed within 3 minutes — the flush disperses the sphere but permanently damages the facility's Han-flow system.

## R.D. Response Protocol

Alert Level 5. ALL personnel. Echo-Core direct command. Director Majin on standby with Absolvohan authorization. Full facility evacuation is impossible — the sphere expands too fast. The only option is core destruction.



## Spawn Roster (Monster / Non-Crystal / Non-Humanoid)

> In addition to the primary PURPLE Tide Watch entity, the following variants may spawn during the encounter, covering physical form types (Monster, Non-Crystal, Non-Humanoid) with varied material composition — flesh, metal, bone, stone, and organic matter, not just crystal.

### The Parasite Bloom (Monster, Tide-Spawn-grade)

**Physical Form:** Monster — A bloated, pulsing mass of wet purple flesh shaped like an enormous flower-head, two meters across. Its petals are thick, veined, and glistening with a viscous fluid that smells of rot and fermentation. At its centre is a gaping maw lined with rows of soft, translucent tendrils that drip spore-laden gas. The whole thing shudders and contracts rhythmically, like a heart, and where it sits, the floor darkens and softens, as though the biomass is slowly digesting the surface beneath it..

| Stat | Value |
|---|---|
| **HP** | 500/500 out of 1000 |
| **Han Pressure [ATK]** | 35–60 per hit · Mixed |
| **Spawn Count** | 1–3 |

**Ability:** Deals damage themed to its form and element. **[35-60 Crimson (HP) -> 35 Deep Blue (Sanity) -> 35 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**

### The Rot-Tide (Non-Crystal, Tide-Spawn-grade)

**Physical Form:** Non-Crystal — A chest-high rolling wave of corrupted flesh — liquefied tissue, fungal mats, drifting slabs of necrotic muscle and bone-fragment — that flows rather than walks, reforming around every obstacle and leaving a trail of thriving invasive growth.

| Stat | Value |
|---|---|
| **HP** | 530/530 out of 1000 |
| **Han Pressure [ATK]** | 40–65 per hit · Mixed |
| **Spawn Count** | 1–3 |

**Ability:** It washes over, and the corrupt matter seeps into and begins to transform whatever it covers. **[40-65 Crimson (HP) -> 40 Deep Blue (Sanity) -> 40 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**

### The Root Network (Non-Humanoid, Tide-Spawn-grade)

**Physical Form:** Non-Humanoid — A spreading system of thick, fibrous roots that erupt from the floor, walls, and ceiling — not a single entity but a connected organism, a living infrastructure. The roots are purple, wet, and ridged, covered in fine translucent hairs that wave and seek. Where they meet, they fuse into thick knots that pulse with shared Han-fluid. The network grows visibly — a new root erupts every few seconds, reaching for warmth, for movement, for anything alive that it can wrap around and feed from..

| Stat | Value |
|---|---|
| **HP** | 560/560 out of 1000 |
| **Han Pressure [ATK]** | 45–70 per hit · Mixed |
| **Spawn Count** | 1–3 |

**Ability:** Deals damage themed to its form and element. **[45-70 Crimson (HP) -> 45 Deep Blue (Sanity) -> 45 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]**


### The Corrupted (Humanoid, Tide-Spawn-grade)

**Physical Form:** Humanoid — A towering humanoid more fungus than flesh — a walking garden of corruption trailing root and spore with every step.

| Stat | Value |
|---|---|
| **HP** | 410/410 out of 1000 |
| **Han Pressure [ATK]** | 30-44 per hit · Mixed |
| **Spawn Count** | 1 |

**Ability:** It spreads its arms, and a cloud of transformative spore washes the hall.. **[[30-44 Crimson (HP) -> 30-44 Deep Blue (Sanity) -> 30-44 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

### The Spore-Storm (Amorphous, Tide-Spawn-grade)

**Physical Form:** Amorphous — A rolling, living storm-cloud of spores that rains corruption, rooting whatever it passes over.

| Stat | Value |
|---|---|
| **HP** | 400/400 out of 1000 |
| **Han Pressure [ATK]** | 28-42 per hit · Mixed |
| **Spawn Count** | 1 |

**Ability:** It rains, and everything beneath begins to bloom and change against its will.. **[[28-42 Crimson (HP) -> 28-42 Deep Blue (Sanity) -> 28-42 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

### The Plague-Vermin (Swarm, Tide-Spawn-grade)

**Physical Form:** Swarm — A facility-wide swarm of corrupted vermin spreading the growth to every surface they touch.

| Stat | Value |
|---|---|
| **HP** | 40/40 out of 1000 |
| **Han Pressure [ATK]** | 7-11 per hit · Mixed |
| **Spawn Count** | facility-wide |

**Ability:** They scatter through the facility, seeding corruption wherever they run.. **[[7-11 Crimson (HP) -> 7-11 Deep Blue (Sanity) -> 7-11 Black (Both) -> 1 Pale White (5% Max HP) | 8s, 2s per type]]**

## Trivia

- The Fracture Wave is not an entity. It is what happens when the Weeping itself breaches the facility — not through a single point, but everywhere at once. It is the city's sorrow saying: 'Enough pretending. You are all sorrow. Let me show you.'
- Spawn count: 1–3 entities per event.
- Same Color Ordeals do not attack each other; different Colors will fight.
- Ordeal suppression permanently reduces facility Han-Density (unlike Sorrow Entity work, which adds to it).

## Document Information

**Document ID:** `ORDEAL-PURPLE-Tide-Watch`

**Author:** Commander Taeho (태호), R.D. Ordeal Response Manual

**Date:** Year 4220

**Classification:** Restricted
