# THE REVERIE DIRECTORATE — Internal Structure
## The Nine Echo-Cores — Current Register

> *"Nine people carry the weight of the city's sorrow. What changes is whether they carry it alone."*

**Current Era:** Year 4,238 — Dawn Initiative

---

## Overview

The Reverie Directorate (R.D.) is organized into **Nine Echo-Cores** — five operational departments, two specialized divisions, one Director, and one Secretary. Each Echo-Core is led by a person who carries a unique sorrow — and each Echo-Core's function is shaped by that sorrow.

**The Nine:**

| # | Title | Zone | Role |
|---|-------|------|------|
| **1** | The Director | A | Supreme authority — the one who carries the city's weight |
| **2** | The Secretary | A | The one who remembers everything — and is forbidden from acting |
| **3** | The Containment Lead | B | Manages Sorrow Entities in the oldest, most wounded zone |
| **4** | The Extraction Lead | C | Extracts M.A.W. from entities — the most regulated zone |
| **5** | The Research Lead | D | Studies Han, entities, and the Three Sorrows — the balanced zone |
| **6** | The Border Lead | E | Defends against Outside Sorrow — the most dangerous zone |
| **7** | The Archive Lead | A (Deep) | Preserves the truth — buried beneath the Alpha Tree |
| **8** | The Outsider | Mobile / Floor 7 | Former Council agent incorporated into the R.D.; field operations and accountable intelligence |
| **9** | The Exile | E / Floor 8 | Defiant investigator, external warning source, returned route guide, and Gate Watch commander |

---

## The Facility — Location & Structure

### Location

The Reverie Directorate's main facility is located **beneath the Alpha Tree** — deep underground, extending from Zone A's surface down into the Depths. The facility is built into the Alpha Tree's root structure — the same Han-crystal that forms the six buildings above extends downward, forming the facility's walls, floors, and ceilings.

**The R.D. is not one building.** It is a **network of interconnected sectors** spread across multiple zones, with the central hub beneath the Alpha Tree.

### The Central Hub — Zone A (Deep)

**Location:** Beneath the Alpha Tree, extending deep underground.

**What it contains:**
- The Director's Office (surface level)
- The Secretary's Chamber (surface level)
- The Archive Lead's Vault (deepest level)
- The Extraction Chamber (where M.A.W. is extracted)
- The Containment Core (where the most dangerous entities are held)
- The Research Labs (where Han is studied)

**Structure:** The central hub is organized in **three layers** — mirroring the city's vertical dimension:

| Layer | Depth | Character | Echo-Cores Present |
|-------|-------|-----------|-------------------|
| **The Spires** | Surface to -100m | Administrative — Director, Secretary, visitors | Director, Secretary |
| **The Core** | -100m to -500m | Operational — extraction, containment, research | Extraction Lead, Research Lead |
| **The Depths** | -500m to -2000m | Deep storage — the most dangerous entities, the Archive's vaults | Containment Lead, Archive Lead |

### The Sector Network

The R.D. operates **sector stations** in each zone — field offices where Echo-Cores and their teams work directly with the zone's Han and entities.

| Sector | Zone | Location | Echo-Core | Purpose |
|--------|------|----------|-----------|---------|
| **SECTOR-A-01** | A | Beneath the Alpha Tree | Director, Secretary | Central hub — administration, coordination |
| **SECTOR-B-01** | B | The Maw perimeter | Containment Lead | Containment of Zone B entities — The Maw |
| **SECTOR-B-02** | B | The Old Lament | (Field team) | Containment of older entities |
| **SECTOR-C-01** | C | The Collector's Row | Extraction Lead | M.A.W. extraction, Collector coordination |
| **SECTOR-D-01** | D | The Forge District | Research Lead | Han research, entity study |
| **SECTOR-D-02** | D | The Echo Gardens | (Field team) | Memory entity study |
| **SECTOR-E-01** | E | The Threshold | Border Lead | Border defense, Outside Sorrow monitoring |
| **SECTOR-?-01** | Mobile | The Desolate | Outsider | Field operations, reconnaissance |
| **SECTOR-GATE** | E | The Exile's Gate / Floor 8 interface | Exile | Pre-return warning observation; post-return Gate command, external contact, and route accountability |

### The Facility's Relationship to the Alpha Tree

The R.D. is built **into** the Alpha Tree — not beside it, not on top of it, but *within* it. The Tree's root structure forms the facility's architecture. This means:

- The facility is **alive** — the walls pulse with Han, the floors are warm with sorrow
- The facility **responds** to emotional events — when a Fracture occurs, the walls tremble
- The facility **grows** — new rooms form when Han accumulates, old rooms collapse when sorrow disperses
- The facility **remembers** — the walls absorb the emotions of those who work within them

**The Director's connection:** The Director's Ω-grade M.A.W. fusion is connected to the Alpha Tree. The Director can feel the facility's emotions — every containment failure, every extraction, every Fracture. The facility feels the Director's sorrow in return.

### The Nine Echo-Cores — Facility Positions

| # | Echo-Core | Surface | Core | Depths | Mobile |
|---|-----------|---------|------|--------|--------|
| 1 | **Director** | ✓ Primary | | | |
| 2 | **Secretary** | ✓ Primary | | | |
| 3 | **Containment Lead** | | ✓ Primary | ✓ Secondary | |
| 4 | **Extraction Lead** | | ✓ Primary | | |
| 5 | **Research Lead** | | ✓ Primary | ✓ Secondary | |
| 6 | **Border Lead** | | | | ✓ Primary |
| 7 | **Archive Lead** | | | ✓ Primary | |
| 8 | **Outsider** | | | | ✓ Primary |
| 9 | **Exile** | | | | ✓ Gate boundary before Day 355; ✓ Floor 8 command after return |

---


---

## Room Types — The Hand of Change

### Overview

Each floor of The Hand of Change contains specific room types. Rooms are connected by **Han-corridors** — passages lined with Han-crystal that pulse with the facility's rhythm.

> *"Every room in The Hand has a purpose. Every purpose has a cost."*

---

### Universal Room Types

These rooms exist on **every floor** (1-8):

| Room Type | Description | Capacity |
|-----------|-------------|----------|
| **Main Room** | The central hub of each floor — where personnel gather, briefings happen, and operations are coordinated | 20-50 personnel |
| **Han-Corridors** | Passages connecting rooms — lined with Han-crystal, warm to the touch | N/A (transit) |
| **Elevator Hubs** | Vertical transport between floors — Han-powered lifts | 10 per hub |
| **Side Rooms** | Storage, rest areas, medical stations | Varies |

---

### Floor 1: Neutral — Room Types

| Room | Description | Function |
|------|-------------|----------|
| **The Director's Office** | The Director's personal space — sparse, heavy, warm | Decision-making; historical access to the concealed Cycle-era Absolvohan reserve beneath Floor 1 |
| **The Secretary's Station** | Where the Secretary coordinates — screens, communication arrays | Inter-Field coordination, scheduling |
| **The Council Chamber** | Meeting room for Council visits — imposing, formal | Council meetings, policy decisions |
| **The Common Hall** | Large gathering space — meals, rest, community | Personnel rest, social interaction |
| **The Infirmary** | Medical facility — Han-treatment, Fracture assessment | Healing, Fracture monitoring |
| **The Armory** | M.A.W. storage and distribution | Equipment checkout, maintenance |

---

### Floor 2: The Maw's Keep — Room Types

| Room | Description | Function |
|------|-------------|----------|
| **Containment Cells** | Individual chambers for Sorrow Entities — Han-crystal walls, suppression fields | Entity holding — each cell tailored to specific entity |
| **The Maw's Edge** | Observation point at The Maw's perimeter — thick glass, monitoring equipment | Monitoring The Maw, communicating with Dekan |
| **Breach Response Staging** | Equipment room + briefing area for breach teams | Preparation for containment failures |
| **Entity Processing** | Initial assessment room — Sorrow Gauges, classification tools | New entity intake, classification |
| **The Holding Yard** | Large open space for entity containment overflow | Emergency holding, entity interaction testing |
| **The Whispering Gallery** | Sound-dampened room where entity vocalizations are recorded | Entity communication study |

---

### Floor 3: The Extraction Hall — Room Types

| Room | Description | Function |
|------|-------------|----------|
| **Extraction Chambers** | Individual rooms with extraction rigs — Han-crystal frames, resonance emitters | M.A.W. extraction from entities |
| **Resonance Scanning** | Room with compatibility measurement equipment | Entity-person resonance testing |
| **M.A.W. Testing Grounds** | Open space for testing extracted equipment | Equipment evaluation, combat testing |
| **Bonding Rooms** | Quiet, isolated rooms for M.A.W. bonding process | User-equipment bonding |
| **The Refinery** | Han-crystal processing — raw crystal to usable material | Echo processing, Han-crystal refinement |
| **Equipment Storage** | Vault for M.A.W. equipment — climate-controlled | M.A.W. storage, cataloguing |

---

### Floor 4: The Insight Forge — Room Types

| Room | Description | Function |
|------|-------------|----------|
| **Research Laboratories** | Individual labs for Han analysis — equipment, samples, documentation | Han research, entity study |
| **The Classification Archive** | Database room — Sorrow Classification System records | Entity classification, data storage |
| **Sorrow Mapping Chamber** | Room with Han-flow visualization equipment | Han-flow mapping, city structure analysis |
| **Testing Chambers** | Controlled environments for entity interaction experiments | Controlled entity testing |
| **The Specimen Vault** | Storage for Han samples, entity fragments, research materials | Sample storage |
| **The Cartographer's Den** | Yeonhwa's personal workspace — maps, lenses, flow charts | SED preparation, map analysis |

---

### Floor 5: The Border Watch — Room Types

| Room | Description | Function |
|------|-------------|----------|
| **Watchtower Command** | Communication and coordination center — maps, signals, reports | Zone E defense coordination |
| **The Threshold Outpost** | Forward operating base — equipment, supplies, briefings | Border operations staging |
| **Desolate Entry Point** | Controlled access to the wilderness — airlock-style doors | Desolate expeditions |
| **Entity Containment (Overflow)** | Containment for entities captured outside the facility | External entity holding |
| **The Armory (Military)** | Weapons, armor, tactical equipment | Military equipment storage |
| **The War Room** | Strategy room — maps, intelligence reports | Tactical planning |

---

### Floor 6: The Deep Vault — Room Types

| Room | Description | Function |
|------|-------------|----------|
| **The Deep Archive** | Classified records — lowest level, most secure | Cheongula records, forbidden knowledge |
| **Memory Vaults** | Crystallized Echo storage — climate-controlled | Memory preservation |
| **The Sealed Room** | Records requiring Council approval — triple-locked | Highest-security records |
| **The Final Door** | Ancient door — sealed, unknown contents | ??? |
| **The Reading Room** | Quiet space for archive research | Research, documentation |
| **The Preservation Lab** | Memory stabilization, Echo repair | Memory conservation |

---

### Floor 7: The Shadow Corps — Room Types

| Room | Description | Function |
|------|-------------|----------|
| **Safe Houses** | Multiple disguised rooms across the floor — different identities | Field agent rest, identity switching |
| **Intelligence Processing** | Analysis room — maps, reports, surveillance | Intelligence analysis |
| **The Communication Hub** | Encrypted communication arrays | Field agent contact |
| **The Disguise Room** | Masks, clothing, identity tools | Infiltration preparation |
| **The Armory (Covert)** | Stealth weapons, infiltration tools | Covert equipment |
| **The Debriefing Room** | Secure room for agent debriefings | Post-mission analysis |

---

### Floor 8: The Gate Watch — Room Types

| Room | Description | Function |
|------|-------------|----------|
| **The Gate Observation Post** | Overlooks the Exile's Gate — thick glass, monitoring equipment | Before return: watches Xyan and Gate changes. After return: watches passage, approach, and both sides of the boundary. |
| **The Exile's Station** | Dedicated communication and field-contact station | Before return: receives Xyan's compressed warnings. After return: Xyan's external-contact and route-command station. |
| **Signal Analysis** | Room for decoding external Han-wave messages | Interprets warnings, compares outside reports, and tracks changed Han-flow. |
| **The Contemplation Room** | Quiet space separated from continuous Gate monitoring | Reflection, personnel decompression, and post-arrival stabilization. |
| **The Archive (Gate)** | Records of Gate activity, exile decisions, warnings, arrivals, and responses | Preserves not only what reached the R.D., but what the R.D. did after receiving it. |

---

### Room Interaction

**Moving between rooms:**
- Personnel move through **Han-corridors** — passages that pulse with the facility's rhythm
- **Elevator Hubs** connect floors — Han-powered lifts
- **Main Rooms** serve as home base — personnel return after tasks

**Room effects:**
- **Containment Cells** suppress Han — entities are calmer inside
- **Extraction Chambers** amplify resonance — M.A.W. extraction is more effective
- **The Deep Vault** suppresses emotion — visitors feel numb inside
- **The Gate Observation Post** creates unease — something about the Gate affects nearby rooms

---


---


---

## Energy Production — The R.D.'s Output

### Overview

> *"The city does not run on hope. It runs on sorrow — processed, refined, and distributed."*

The Reverie Directorate produces **Han-Energy (한 에너지 — Han Eneoji)** — refined sorrow that powers the city's infrastructure. This remains a primary operational output.

### Operational Era Status

The quotas, diversion records, and concealed reserve below describe Cycle-era operations. The Cycle has ended, and the original Absolvohan has become the Hand of Hope. Revised Year 4,238 quota values remain pending Directorate ratification. Current accounting prohibits continuation of Majin's former secret diversion.

---

### What is Han-Energy?

Han-Energy is **processed sorrow** — raw Han extracted from Sorrow Entities, refined through the Extraction Hall, and converted into usable power.

**The process:**
1. **Extraction** — Raw Han is extracted from Sorrow Entities during Work Type interactions
2. **Refinement** — Raw Han is processed in the Extraction Hall's Refinery — impurities removed, energy concentrated
3. **Distribution** — Refined Han-Energy is distributed to the city's infrastructure — Veil generators, Han-Rails, common technology

**What Han-Energy powers:**
- **Veil generators** — the suppression fields that protect citizens from raw sorrow
- **Han-Rails** — the city's transportation system
- **Common technology** — Echo-Phones, Sorrow-Slates, Han-Lamps
- **Facility operations** — The Hand of Change itself requires Han-Energy to function
- **M.A.W. maintenance** — keeping extracted equipment functional

---

### How Han-Energy is Produced

**Source:** Sorrow Entities contained in Floor 2 (The Maw's Keep)

**Method:** When personnel perform **Work Types** on contained entities, the interaction generates **positive and negative Han-Energy**:

| Work Type | Positive Energy | Negative Energy | Risk |
|-----------|----------------|-----------------|------|
| **Flerehan** (Tears) | Moderate | Low | Emotional drain |
| **Pugnahan** (Confrontation) | High | High | Physical damage |
| **Viderehan** (Observation) | Low | Low | Mental fatigue |
| **Ferrehan** (Endurance) | High | Moderate | Exhaustion |

**Positive Han-Energy** = Refined, usable sorrow — the city's fuel

**Negative Han-Energy** = Unstable, raw sorrow — dangerous, must be contained or purged

**The balance:** The R.D. must produce more Positive than Negative. If Negative accumulates, the facility destabilizes — leading to breaches, Fracture events, or worse.

---

### Cycle-Era Energy Quotas

During the Cycle, each producing floor has a **daily energy quota**. These values are retained as the historical operational baseline; revised Dawn Initiative quotas are unspecified.

| Floor | Daily Quota | Primary Source |
|-------|-------------|----------------|
| **2 — Maw's Keep** | 500 units | Entity containment work |
| **3 — Extraction Hall** | 300 units | M.A.W. extraction process |
| **4 — Insight Forge** | 100 units | Research experiments |
| **5 — Border Watch** | 50 units | External entity capture |
| **Total** | **950 units/day** | |

**What happens if quotas aren't met:**
- Facility power dims — Han-lamps flicker, corridors cool
- Veil generators weaken — the city's protection decreases
- The Council demands explanation — political consequences
- The Director must authorize **emergency extraction** — riskier work on more dangerous entities

**What happened when Cycle-era quotas were exceeded:**
- The facility operated at full capacity — corridors glowed and rooms warmed.
- Official surplus entered controlled storage and distribution records.
- Majin secretly diverted approximately 0.02 tons per iteration into the concealed Absolvohan reserve.
- That diversion reduced energy available to the city and was not acceptable transparent accounting.

**Year 4,238 rule:** Surplus requires recorded allocation, review, and consequence tracking. No secret Absolvohan diversion continues.

---

### The Absolvohan Connection — Historical

During the Cycle, Majin diverted persistent surplus Han-crystal to a reserve hidden beneath Floor 1. His objective was to reach the original Absolvohan's 100-ton release condition.

The city still needed that energy. Diversion weakened infrastructure, reduced margins, and exposed citizens to preventable failure. Majin's intention to end the Cycle did not remove the cost of withholding the decision from everyone affected.

> **Cycle-era justification — Majin:** _"The city has survived for 4,200 years on sorrow. It can survive a little less — for a little longer. The Absolvohan will end this. The cost is worth it."_

> **Cycle-era record — Seiyon:** _"Year 4232+1778. The Veil generators in Zone D failed for three hours today. Twelve citizens were exposed to raw Han. Two Fractured. The Director diverted the surplus to the Absolvohan. The Director did not mention the Fractures."_

On Day 160 of the final Cycle, the release becomes the Hand of Hope instead of destroying Somnarak. The hidden reserve is therefore a historical system and ethical failure, not a current Year 4,238 accumulation program.

---

### Energy Distribution

Han-Energy flows from The Hand of Change to the city through **Han-conduits** — crystallized channels embedded in the city's structure.

| Zone | Energy Share | Primary Use |
|------|--------------|-------------|
| **Zone A** | 10% | Alpha Tree maintenance, R.D. operations |
| **Zone B** | 20% | Old infrastructure, Maw containment |
| **Zone C** | 30% | Veil generators, modern infrastructure |
| **Zone D** | 25% | Residential power, common tech |
| **Zone E** | 15% | Border defense, Watchtowers |

**The imbalance:** Zone C receives the most energy — because the Veil is strongest there. Zone B receives the least — because its infrastructure is old and the Han is already dense. This creates resentment — Zone B feels neglected.

---

### The Paradox

> *"The city needs sorrow to survive. The R.D. produces sorrow to keep the city alive. But the R.D.'s existence creates more sorrow — from the entities it contains, the work it demands, the lives it costs. The more energy the R.D. produces, the more sorrow the city generates. The more sorrow the city generates, the more energy the R.D. needs to produce."*

**The cycle:**
1. The city needs Han-Energy
2. The R.D. contains Sorrow Entities to produce Han-Energy
3. Containment creates more sorrow (entities suffer, personnel suffer)
4. More sorrow = more Han = more energy needed
5. Return to step 1

**The Director's Cycle-era answer:** The original Absolvohan — release all sorrow at once. The final Cycle rejects the annihilating form of that answer and produces the Hand of Hope.

**The Council's answer:** Manage the cycle. Keep the system running. Do not look too closely.

**The Architect's answer:** Build better. Reduce the city's need for Han-Energy.

**The Collector's answer:** Enforce the debts. Ensure everyone pays their share.

**No one has a good answer.** That is the point.

---


---


---

## Agent Stats — R.D. Personnel Attributes

### Overview

> *"In a world built on sorrow, your strength is not how hard you hit — it is how much you can carry."*

Every R.D. personnel member is assessed on **four core attributes** — measuring their ability to withstand, process, and work with Han.

---

### The Four Attributes

| Attribute | Symbol | Color | What It Measures |
|-----------|--------|-------|------------------|
| **Resilience** | ♦ | Deep Blue | Physical endurance — ability to withstand Han's weight |
| **Clarity** | ♠ | Pale White | Mental stability — ability to resist emotional manipulation |
| **Composure** | ♣ | Crimson | Emotional control — ability to maintain focus under sorrow |
| **Resolve** | ♠ | Black | Willpower — ability to act despite the weight |

---

#### Resilience (♦ Deep Blue)

**What it measures:** Physical endurance — how much Han-weight a person can bear before breaking.

**What it affects:**
- Maximum HP (physical health)
- Resistance to physical damage from entities
- Ability to carry heavy M.A.W. equipment
- Endurance during long shifts

**How it's trained:**
- Physical conditioning — exercise, labor, combat training
- Han exposure — gradual, controlled exposure to heavy Han environments
- M.A.W. bearing — carrying heavy equipment over time

**Low Resilience:** The person breaks easily under physical stress — injuries, exhaustion, premature aging.

**High Resilience:** The person can endure what would break others — they carry the weight without complaint.

---

#### Clarity (♠ Pale White)

**What it measures:** Mental stability — how well a person resists emotional manipulation, memory loss, and Dream interference.

**What it affects:**
- Maximum SP (mental health)
- Resistance to Void-element attacks
- Ability to distinguish Dream from reality
- Memory retention — resisting memory theft

**How it's trained:**
- Meditation — focus exercises, mindfulness
- Dream exposure — controlled, brief dips into the Dream realm
- Memory exercises — recalling, organizing, protecting personal memories

**Low Clarity:** The person is easily confused, manipulated, or lost in the Dream — they forget who they are.

**High Clarity:** The person maintains their identity even under extreme pressure — they know who they are.

---

#### Composure (♣ Crimson)

**What it measures:** Emotional control — how well a person maintains focus under emotional stress.

**What it affects:**
- Work speed — how quickly and effectively they perform Work Types
- Resistance to Grudge-element attacks
- Ability to perform Flerehan (Tears) without breaking down
- M.A.W. bonding stability

**How it's trained:**
- Emotional regulation — learning to feel without being overwhelmed
- Confrontation training — facing anger, fear, grief without losing control
- M.A.W. bonding — gradual exposure to entity emotions

**Low Composure:** The person breaks down emotionally — crying, raging, or withdrawing when they need to act.

**High Composure:** The person feels everything — but chooses when to express it. They are steady when others fall apart.

---

#### Resolve (♦ Black)

**What it measures:** Willpower — how determined a person is to act despite the weight of sorrow.

**What it affects:**
- Movement speed — how quickly they navigate the facility
- Resistance to Weight-element attacks
- Ability to perform Ferrehan (Endurance) without collapsing
- Leadership capability — inspiring others under pressure

**How it's trained:**
- Purpose-finding — understanding why they work, what they fight for
- Endurance tests — pushing past limits in controlled environments
- Moral challenges — making difficult decisions under pressure

**Low Resolve:** The person gives up easily — they see no point in continuing.

**High Resolve:** The person persists even when everything says stop — they carry on because they must.

---

### Attribute Levels

Each attribute ranges from **1** (lowest) to **100** (highest). Most civilians average **20-30** in each attribute. Trained R.D. personnel average **40-60**. Echo-Cores commonly reach **Exceptional (81-100)** in the attributes central to their function, but Echo-Core designation does not require every score to exceed 80.

| Level | Range | Description |
|-------|-------|-------------|
| **Fragile** | 1-20 | Below civilian average — vulnerable to Han effects |
| **Average** | 21-40 | Civilian level — can survive daily life |
| **Trained** | 41-60 | R.D. personnel level — can perform Work Types safely |
| **Veteran** | 61-80 | Experienced personnel — can handle dangerous entities |
| **Exceptional** | 81-100 | Echo-Core level — can withstand what breaks others |

---

### Attribute Interactions

**How attributes interact with Work Types:**

| Work Type | Primary Attribute | Secondary Attribute | Failure Condition |
|-----------|-------------------|---------------------|-------------------|
| **Flerehan** (Tears) | Composure | Clarity | Emotional breakdown — crying, withdrawal |
| **Pugnahan** (Confrontation) | Resolve | Resilience | Physical collapse — exhaustion, injury |
| **Viderehan** (Observation) | Clarity | Composure | Mental breakdown — confusion, hallucination |
| **Ferrehan** (Endurance) | Resilience | Resolve | Total collapse — physical and mental exhaustion |

**How attributes affect M.A.W. bonding:**

| Attribute | Effect on Bonding |
|-----------|-------------------|
| **Resilience** | Higher = can wear heavier M.A.W. |
| **Clarity** | Higher = better entity communication, less memory bleed |
| **Composure** | Higher = more stable bond, less personality shift |
| **Resolve** | Higher = stronger bond, less rejection risk |

---

### Attribute Gains and Losses

**How attributes change over time:**

| Event | Effect |
|-------|--------|
| **Successful Work Type** | +1 to relevant attribute |
| **Failed Work Type** | -1 to relevant attribute |
| **M.A.W. bonding** | +2 to primary attribute, -1 to secondary |
| **Fracture (early stage)** | -5 to all attributes |
| **Core Suppression** | +10 to all attributes (if survived) |
| **Major breach survival** | +3 to Resilience and Resolve |
| **Memory loss** | -10 to Clarity |
| **Emotional trauma** | -10 to Composure |
| **Physical injury** | -10 to Resilience |

---

### Sample Attribute Profiles

**Echo-Cores:**

| Echo-Core | Resilience | Clarity | Composure | Resolve |
|-----------|------------|---------|-----------|---------|
| **The Director** | 95 | 80 | 70 | 99 |
| **The Secretary** | N/A (AI) | 99 | 85 | 60 |
| **Containment Lead** | 85 | 60 | 75 | 90 |
| **Extraction Lead** | 70 | 80 | 90 | 75 |
| **Research Lead** | 60 | 95 | 40 | 70 |
| **Border Lead** | 90 | 70 | 80 | 85 |
| **Archive Lead** | 50 | 90 | 60 | 80 |
| **The Outsider** | 80 | 75 | 85 | 95 |
| **The Exile** | 85 | 65 | 70 | 90 |

**SED Team:**

| Member | Resilience | Clarity | Composure | Resolve |
|--------|------------|---------|-----------|---------|
| **Yeonhwa** | 55 | 70 | 65 | 80 |
| **Doha** | 75 | 50 | 60 | 70 |
| **Harin** | 80 | 55 | 70 | 85 |
| **Sora** | 45 | 85 | 50 | 60 |
| **Minjae** | 50 | 80 | 65 | 75 |
| **Jisoo** | 55 | 75 | 80 | 65 |
| **The Silent One** | 70 | 60 | 90 | 95 |

---


---


---


---

## Default Equipment — R.D. Standard Issue

### Overview

> *"Not everyone gets M.A.W. But everyone gets something."*

Every R.D. personnel member receives manufactured standard equipment. The kit is made from refined Han-crystal and conventional materials. It does not imply an entity bond and does not become an Echo-Core's personal signature equipment merely because a department grants access to it. Manufactured items may receive an **M.A.W.-equivalent output or armor rating** without becoming entity-extracted M.A.W.

### Numeric Convention

The following test values use the compact notation applied throughout R.D. combat and equipment records:

| Scale | Meaning |
|---|---|
| **Damage** | Abstract combat-output points before target resistance |
| **Resistance multiplier** | `Damage Received = Base Damage × Resistance Multiplier` |
| **0.8× — Endured** | Partial damage reduction; the target receives 80% of the affected element |
| **α — Minor / weak output** | The lowest registered power band; normally 3–6 direct damage |
| **Speed 1** | Slow |
| **Speed 2** | Normal |
| **Speed 3** | Fast |
| **Range 1** | Contact / personal reach |
| **Range 2** | Short |
| **Range 3** | Medium |
| **Range 4** | Long |
| **Range 5** | Room-scale coverage |
| **100% → 70% → 50%** | Standard multi-target falloff where an item explicitly uses Pierce or AoE; never assumed for single-target tools |

Tool ratings are operational baselines, not evidence that every item is a weapon. Situational attribute bonuses modify only the named check and do not permanently raise a person's Profile score.

### Standard Issue Kit

| Item | Type | Grade | Element | Primary Numeric Baseline |
|---|---|---|---|---|
| **The Sorrow Rod** | Weapon — staff | α — Minor | Weight (Black) | 3–6 direct; Speed 2; Range 1 |
| **The Veil Vest** | M.A.W.-equivalent manufactured armor — vest | α — Minor | Void (Pale White) | **0.8× Lament / Grudge / Void / Weight against α-grade weak output**; 10% ambient-Han reduction; up to 3-minute Fracture delay |
| **The Echo Compass** | Handheld sensor | α — Minor | Void (Pale White) | 50-meter detection radius; 2-second refresh |
| **The Sorrow Gauge** | Wrist sensor | α — Minor | Weight (Black) | 0–100% readings; 10-meter linked-entity radius; 1-second refresh |
| **The Memory Anchor** | Grounding pendant | α — Minor | Lament (Deep Blue) | +10 situational Clarity for identity, Dream/reality, and memory-theft checks |
| **The Fracture Whistle** | Emergency tool | α — Minor | Grudge (Crimson) | 10-meter radius; up to 3-minute delay; 60-second recovery |

---

### The Sorrow Rod (한의 막대 — Han-ui Makdae)

**Appearance:** A 1.2-meter reinforced Han-crystal staff. It is dark, warm to the touch, and faintly resonant near Sorrow Entities.

| Field | Standard-Issue Value |
|---|---|
| **Classification** | Manufactured weapon; not M.A.W. |
| **Grade** | **α — Minor** |
| **Element** | **Weight — Black** |
| **Basic damage** | **3–6 Weight direct** |
| **Speed** | **2 — Normal** |
| **Range** | **1 — Contact** |
| **Pattern** | Single target; impact |
| **Han Pulse** | **2 Weight**, Range 2 short cone, pushes unsecured minor targets up to 2 meters |
| **Pulse coverage** | Up to 3 targets; standard 100% → 70% → 50% falloff |
| **Pulse recovery** | **12 seconds** |
| **Internal capacity** | **6 pulses** before conduit recharge |
| **Full recharge** | **15 minutes** at an R.D. Han-conduit |

**Limits:** Low output, breakable construction, finite charge, and insufficient force for powerful entities without trained-team support.

---

### The Veil Vest (베일 조끼 — Beil Jokki)

**Appearance:** A lightweight dark-grey vest of Han-woven fabric with faint crystalline patterns. Four small resistance marks sit beneath the collar: Deep Blue, Crimson, Pale White, and Black.

| Field | Standard-Issue Value |
|---|---|
| **Classification** | **M.A.W.-equivalent manufactured armor**; rated through the M.A.W. armor resistance system but not extracted from an entity |
| **Armor equivalence** | **α — Minor M.A.W. armor** |
| **Element** | **Void — Pale White** |
| **Protected power band** | **α — Minor / weak-output attacks only** |
| **Resistance formula** | `Damage Received = Base Damage × Resistance Multiplier` |
| **Ambient-Han reduction** | **10%** under low-to-moderate exposure |
| **Mundane impact reduction** | **2 points per hit**, minimum 0; applies to ordinary cuts and impacts only |
| **Fracture delay** | Up to **3 minutes** under early-stage exposure |
| **Coverage** | Torso only |
| **Speed penalty** | None under ordinary use |

#### Four-Element Resistance — Weak Output

| Element | Multiplier vs α — Minor | Rating | Example |
|---|---:|---|---:|
| **Lament — Deep Blue** | **0.8×** | **Endured** | 5 Lament → **4 received** |
| **Grudge — Crimson** | **0.8×** | **Endured** | 5 Grudge → **4 received** |
| **Void — Pale White** | **0.8×** | **Endured** | 5 Void → **4 received** |
| **Weight — Black** | **0.8×** | **Endured** | 5 Weight → **4 received** |

The four-element profile applies to direct or Tick damage only when the incoming effect is rated **α — Minor**. At **β — Moderate or higher**, the standard Veil Vest provides **1.0× — Normal** resistance unless a separate barrier, upgrade, or recorded effect changes that value.

The 10% ambient-Han reduction is an exposure rule and is not multiplied again onto the same direct attack after the 0.8× armor resistance has been applied.

**Limits:** The vest does not cure Fracture, does not resist β-grade or stronger attacks beyond the normal 1.0× value, and must be replaced after Han saturation, torn fabric, or a fractured resistance mark.

---

### The Echo Compass (메아리 나침반 — Meori Nachimban)

**Appearance:** A palm-sized dark Han-crystal instrument whose needle follows nearby flow lines.

| Field | Standard-Issue Value |
|---|---|
| **Classification** | Manufactured sensor; not M.A.W. |
| **Grade** | **α — Minor** |
| **Element** | **Void — Pale White** |
| **Detection radius** | **50 meters maximum** |
| **Refresh interval** | **2 seconds** |
| **Outputs** | Direction, relative strength, entity-presence alert, and three depth bands: surface / mid-level / deep |
| **Identification** | Presence only; no entity type at Mk.I |
| **Heavy-Han behavior** | Direction and strength become unreliable; the device must display interference rather than a false precise answer |

---

### The Sorrow Gauge (한 게이지 — Han Geiji)

**Appearance:** A wrist-mounted dark crystal display, warm while sampling.

| Field | Standard-Issue Value |
|---|---|
| **Classification** | Manufactured monitor; not M.A.W. |
| **Grade** | **α — Minor** |
| **Element** | **Weight — Black** |
| **Local Han scale** | **0–100%** |
| **Personal exposure scale** | **0–100%** |
| **Linked contained-entity radius** | **10 meters** |
| **Refresh interval** | **1 second** |
| **History** | Current reading only at Mk.I |
| **Prediction** | None; a high present value is not a guaranteed breach forecast |

---

### The Memory Anchor (기억 닻 — Gieuk Dat)

**Appearance:** A small pendant holding one crystallized identity-memory.

| Field | Standard-Issue Value |
|---|---|
| **Classification** | Manufactured grounding accessory; not M.A.W. |
| **Grade** | **α — Minor** |
| **Element** | **Lament — Deep Blue** |
| **User coverage** | One bonded wearer |
| **Stored imprint** | One verified identity-memory |
| **Situational effect** | **+10 Clarity** for identity grounding, Dream/reality distinction, and resistance to memory theft |
| **Base-score effect** | None; the wearer's Profile Clarity does not permanently change |
| **Refresh condition** | After severe memory impact, visible fading, ownership transfer, or routine 30-day inspection |

**Limits:** It does not restore a deleted memory, overpower a high-output Void attack, or guarantee accurate recall.

---

### The Fracture Whistle (파열 휘파람 — Payeol Hwiparam)

**Appearance:** A small dark-crystal whistle that vibrates before activation.

| Field | Standard-Issue Value |
|---|---|
| **Classification** | Manufactured emergency tool; not M.A.W. |
| **Grade** | **α — Minor** |
| **Element** | **Grudge — Crimson** |
| **Damage** | **0** |
| **Effective radius** | **10 meters** |
| **Fracture delay** | Up to **3 minutes** for early-stage progression while evacuation begins |
| **Recovery** | **60 seconds** between effective calls |
| **Entity effect** | Agitates or drives back only minor entities; no guaranteed effect on higher-potency targets |
| **Signal use** | Audible emergency marker; walls and Han interference reduce practical distance |

**Limits:** Delay is not treatment. Repeated calls do not stack the three-minute ceiling.

---

### Default Equipment by Role — Measured Baselines

Each role receives the complete standard kit plus one role device. These are departmental issue, not automatic personal signature items for the commanding Echo-Core.

| Role | Additional Device | Numeric Baseline | Limits |
|---|---|---|---|
| **Containment Guard** | **Containment Badge** | 5-meter suppression field; +10 Composure for de-escalation checks against α–β entities | No damage; overload after 60 seconds continuous use; ineffective against sovereign output |
| **Extraction Technician** | **Resonance Scanner** | 2-meter scan range; 15-second scan; 0–100 compatibility output | Measures compatibility, not consent or guaranteed bonding success |
| **Research Analyst** | **Han Analyzer** | 20-meter detailed sample range; 10-second sample cycle; stores 100 records | Heavy Han and mixed signatures require manual interpretation |
| **Border Guard** | **Border Shield** | 5 Weight reduction against one frontal hit; Speed 1 to deploy; personal coverage | No rear coverage; three high-output impacts require inspection |
| **Field Agent** | **Shadow Cloak** | +10 situational difficulty to visual/Han detection for 20 minutes; 10-minute recovery | Movement, attacks, bright Han, or close inspection can reveal the user |
| **Gate Observer** | **Gate Lens** | ×20 optical magnification; 1-second Han-boundary refresh; fixed line of sight to the Gate | Cannot reverse, open, command, or interpret the Gate without personnel analysis |

---

### M.A.W. Upgrade Path

| Level | Equipment | Source | Classification Limit |
|---|---|---|---|
| **Standard** | Default Kit | Manufactured | Never M.A.W. |
| **Field-Issue** | Upgraded Kit | Refined Han-crystal + controlled minor resonance | Still manufactured equipment |
| **M.A.W.** | Entity-extracted equipment | Sorrow Entity extraction | Requires registry, compatibility, and risk record |
| **Personal M.A.W.** | Bonded equipment | Deep resonance with a specific entity | Not transferable as ordinary inventory |

**Field-Issue examples:** Sorrow Rod Mk.II, Veil Vest Mk.II, Echo Compass Mk.II, Sorrow Gauge Mk.II, Memory Anchor Mk.II, and Fracture Whistle Mk.II. Mk.II status must not be assigned without a specific issue record.

---

## Echo-Core Signature Equipment

The central equipment registry records the following stat blocks. These classifications do not convert unrelated body systems, departmental tools, or manifestations into M.A.W.

### Majin — Reaper Hungered

| Field | Registry Entry |
|---|---|
| **Type** | Weapon — fused signature M.A.W. |
| **Grade** | **Ω — Singular** |
| **Bearer** | **Majin only** |
| **Element** | **Grudge (Crimson) + Lament (Deep Blue)** |
| **Bearer signature** | **Weight — Black** |
| **Damage** | **10–20 Grudge direct** |
| **Secondary damage** | **3 Lament per second for 10 seconds** |
| **Tick interval** | **0.5 seconds** |
| **Damage per Tick** | **1.5 Lament** |
| **Full aftertone** | **30 Lament** across 20 Ticks before falloff |
| **Speed** | **3 — Fast** |
| **Range** | **3 — Medium** |
| **Attack pattern** | **Pierce** |
| **Coverage** | Scythe-line through up to **3 targets** |
| **Falloff** | **100% → 70% → 50%**, applied separately to the direct hit and every Tick |
| **Maximum amount** | **1 — Unique** |
| **Operational cost** | **Null** — fusion internalizes the operational exchange |
| **Binding cost** | Irreversible fusion, deathlessness, pain retention, and permanent containment responsibility |

| Target | Grudge Direct | Lament / second | Lament / 0.5-second Tick | Full 10-second Lament |
|---|---:|---:|---:|---:|
| **Primary — 100%** | **10–20** | **3** | **1.5** | **30** |
| **First pierced — 70%** | **7–14** | **2.1** | **1.05** | **21** |
| **Second pierced — 50%** | **5–10** | **1.5** | **0.75** | **15** |

#### Phantom Reptile Beast

| Field | Registry Entry |
|---|---|
| **Attack** | Single-target phantom bite |
| **Damage** | **999 Weight (Black)** |
| **Secondary effect** | Room-sized Slowness aura |
| **Aura duration** | **5 seconds** |
| **Activation cost** | **90% of Majin's HP + 90% of Majin's SP** |
| **Cooldown** | Not specified |

The cost basis—current or maximum HP/SP—and the aura's exact slowing strength remain unspecified.

---

### Mellda — Threshold Vow

| Field | Registry Entry |
|---|---|
| **Type** | Integrated Cyborg weapon |
| **Output rating** | **Critical (δ)-equivalent**; not an actual M.A.W. grade |
| **Element** | **Weight (Black) + Grudge (Crimson)** |
| **Damage** | **6–16 Weight direct + 2 Grudge per second for 10 seconds** |
| **Speed** | **1 — Slow** |
| **Range** | **5 — Room** |
| **Attack pattern** | **Pierce** |
| **Coverage** | One line; up to **3 targets** |
| **Falloff** | **100% → 70% → 50%**, applied separately to direct damage and each Tick |
| **Maximum amount** | **1 — integrated into the designated left arm** |
| **M.A.W. status** | Manufactured Cyborg equipment; not extracted, bonded, or self-manifested M.A.W. |

| Target | Direct Weight | Grudge Tick |
|---|---:|---:|
| **Primary — 100%** | **6–16** | **2 per second for 10 seconds** |
| **First pierced — 70%** | **4.2–11.2** | **1.4 per second for 10 seconds** |
| **Second pierced — 50%** | **3–8** | **1 per second for 10 seconds** |

#### Singular Weight Wave

| Field | Registry Entry |
|---|---|
| **Damage** | **25 Weight (Black)** |
| **Pattern** | Single line; up to 3 targets |
| **Falloff** | **25 → 17.5 → 12.5** under the normal 100% → 70% → 50% line rule |
| **Recharge** | **15 seconds** |

Threshold Vow is manufactured equipment. Its output comparison does not make it Mellda's personal M.A.W. or define the possible M.A.W. of her Effloresced passenger.

---

### Ishall — Unanswered

#### Converging Refusal

| Field | Registry Entry |
|---|---|
| **Type** | Artifact Hands — paired remote weapon |
| **Grade / tier** | **δ — Critical** |
| **Element** | **Grudge (Crimson) + Void (Pale White)** |
| **Damage** | **10–15 Grudge direct + 1.5 Void per second for 6 seconds** |
| **Tick interval** | **1 second** — 6 Ticks, 9 total Void before falloff |
| **Speed** | **3 — Fast** |
| **Range** | **4 — Long** |
| **Pattern** | **AoE** |
| **Falloff** | **100% → 70% → 50%**, applied separately to direct damage and each Tick |
| **Maximum amount** | **1 — Unique pair** |
| **Operational cost** | **18 Sorrow Echoes** per complete paired assault |
| **Binding cost** | Continuous two-point sensory link; feedback and phantom pressure transfer to Ishall's sensorium |
| **Recovery** | **8 seconds** after the complete paired assault |
| **M.A.W. status** | Before-Time Artifact equipment; not M.A.W., body hands, specialized arms, or Cyborg anatomy |

| Zone | Direct Grudge | Void / Tick | Tick Count | Total Void |
|---|---:|---:|---:|---:|
| **Center — 100%** | **10–15** | **1.5** | **6** | **9** |
| **Inner — 70%** | **7–10.5** | **1.05** | **6** | **6.3** |
| **Outer — 50%** | **5–7.5** | **0.75** | **6** | **4.5** |

#### Closed Ground

| Field | Registry Entry |
|---|---|
| **Mode** | Area-denial field |
| **Element** | **Void — Pale White** |
| **Damage** | **2 Void per second for 10 seconds** in the center zone |
| **Tick interval** | **1 second** — 10 Ticks |
| **Speed** | **2 — Normal** to establish |
| **Range** | **5 — Room** |
| **Pattern** | **AoE** |
| **Falloff** | **100% → 70% → 50%** by center, inner, and outer zones |
| **Duration** | **10 seconds maximum** |
| **Operational cost** | **45 Sorrow Echoes** |
| **Recovery** | **30 seconds after the field ends** |
| **Concurrency** | One field; both artifacts occupied; no Converging Refusal during the effect |
| **Collapse conditions** | Broken concentration, either artifact leaving Range 5, synchronization failure, or disruptive artifact damage |

| Zone | Void / Tick | Tick Count | Full Total |
|---|---:|---:|---:|
| **Center — 100%** | **2** | **10** | **20** |
| **Inner — 70%** | **1.4** | **10** | **14** |
| **Outer — 50%** | **1** | **10** | **10** |

Closed Ground disrupts Han-assisted movement and remote Han-wave transmission. It does not stop ordinary movement, speech, mundane weapons, or every higher-output system. Friendly Han systems are also affected.

---

## Employee Hierarchy — R.D. Personnel

### Overview

> *"The Echo-Cores carry the weight. The Agents carry the Echo-Cores. The Clerks carry the Agents. And everyone carries the city."*

The Cycle-era personnel register lists approximately 1,179 personnel across eight floors. Later Dawn Initiative growth has not yet been entered into the central staffing total. Each registered position has a defined role, rank, and responsibility.

---

### The Hierarchy

```
THE ECHO-CORES (9)
    │
    ├── SENIOR STAFF
    │   ├── Field Commanders (1 per floor)
    │   ├── Senior Agents (5-10 per floor)
    │   └── Specialists (varies)
    │
    ├── AGENTS
    │   ├── Agents (20-50 per floor)
    │   └── Junior Agents (10-30 per floor)
    │
    ├── SUPPORT STAFF
    │   ├── Clerks (50-100 per floor)
    │   ├── Technicians (20-40 per floor)
    │   └── Maintenance (10-20 per floor)
    │
    └── EXTERNAL
        ├── Contractors (Menders, Specialists)
        └── Prisoners (Debt workers, Fray members)
```

---

### Rank Descriptions

#### Echo-Cores (9 total)

The leadership. Each Echo-Core commands one floor of The Hand of Change.

| Echo-Core | Floor | Role |
|-----------|-------|------|
| The Director | 1 | Supreme authority |
| The Secretary | 1 | Administration |
| Containment Lead | 2 | Entity containment |
| Extraction Lead | 3 | M.A.W. extraction |
| Research Lead | 4 | Han research |
| Border Lead | 5 | External operations |
| Archive Lead | 6 | Deep archives |
| The Outsider | 7 | Field operations |
| The Exile | 8 | Gate observation, external contact, and route command |

---

#### Field Commanders (8 total)

**Role:** Second-in-command on each floor. Report directly to the Echo-Core.

**Responsibilities:**
- Daily operations management
- Personnel assignment
- Emergency response coordination
- Echo-Core proxy when the Echo-Core is unavailable

**Requirements:**
- Minimum 10 years R.D. service
- Attribute average: 60+ across all four
- No Fracture incidents
- Echo-Core recommendation

**Title:** Commander [Floor Name] — e.g., "Commander Maw's Keep"

---

#### Senior Agents (40-80 total)

**Role:** Experienced personnel who lead teams and handle dangerous operations.

**Responsibilities:**
- Lead containment teams
- Perform advanced Work Types
- Train Junior Agents
- Handle high-risk entities

**Requirements:**
- Minimum 5 years R.D. service
- Attribute average: 50+ across all four
- Successful M.A.W. bonding
- Field Commander recommendation

**Title:** Senior Agent [Name]

---

#### Specialists (varies)

**Role:** Personnel with unique skills — M.A.W. extraction, Dream-diving, entity communication, etc.

**Responsibilities:**
- Perform specialized tasks
- Provide expertise to teams
- Research and development
- Emergency consultation

**Requirements:**
- Unique skill or ability
- Attribute specialty: 70+ in one attribute
- Echo-Core or Field Commander approval

**Title:** Specialist [Name] or [Skill] Specialist — e.g., "Dream Specialist Sora"

---

#### Agents (160-400 total)

**Role:** The backbone of the R.D. — personnel who perform daily operations.

**Responsibilities:**
- Perform Work Types on contained entities
- Maintain facility operations
- Respond to breaches and ordeals
- Follow Field Commander orders

**Requirements:**
- R.D. training completion
- Attribute average: 40+ across all four
- Successful equipment bonding
- No major infractions

**Title:** Agent [Name]

---

#### Junior Agents (80-240 total)

**Role:** New personnel still in training or early service.

**Responsibilities:**
- Assist Senior Agents and Agents
- Perform basic tasks
- Learn Work Types
- Observe and study

**Requirements:**
- R.D. training enrollment
- Attribute average: 30+ across all four
- Mentor assignment

**Title:** Junior Agent [Name]

---

#### Clerks (350-800 total)

**Role:** Administrative and support staff — the backbone of daily operations.

**Responsibilities:**
- Data entry and record keeping
- Communication and coordination
- Equipment maintenance
- Facility upkeep

**Requirements:**
- Basic training
- No attribute minimums
- Reliability and attention to detail

**Title:** Clerk [Name] or [Department] Clerk — e.g., "Containment Clerk"

---

#### Technicians (160-320 total)

**Role:** Technical staff who maintain equipment, systems, and infrastructure.

**Responsibilities:**
- Equipment repair and maintenance
- Han-conduit maintenance
- System monitoring
- Technical support

**Requirements:**
- Technical training
- Equipment certification
- Attribute specialty: 40+ in Resilience or Clarity

**Title:** Technician [Name] or [Specialty] Technician — e.g., "Extraction Technician"

---

#### Maintenance (80-160 total)

**Role:** Physical labor — cleaning, repairs, construction, logistics.

**Responsibilities:**
- Facility cleaning
- Physical repairs
- Construction support
- Material transport

**Requirements:**
- Physical fitness
- Basic training
- Attribute minimum: 30+ Resilience

**Title:** Maintenance [Name]

---

#### Contractors (varies)

**Role:** External personnel — Menders, specialists, consultants.

**Responsibilities:**
- Specific tasks as contracted
- Temporary operations
- Specialized expertise

**Requirements:**
- Contract agreement
- Background check
- Attribute assessment

**Title:** Contractor [Name] or [Specialty] — e.g., "Mender Contractor Doha"

---

#### Prisoners (varies)

**Role:** Debt workers, Fray members, or criminals serving sentences.

**Responsibilities:**
- Dangerous tasks others won't do
- Manual labor
- Entity handling (low-risk)
- Debt repayment through service

**Requirements:**
- Criminal conviction or debt sentence
- No attribute minimums
- Supervision required

**Title:** Prisoner [Number] — names are not used

---

### Personnel Distribution

| Floor | Field Commanders | Senior Agents | Specialists | Agents | Junior Agents | Clerks | Technicians | Maintenance | Total |
|-------|-----------------|---------------|-------------|--------|---------------|--------|-------------|-------------|-------|
| **1** | 1 | 5 | 3 | 20 | 10 | 50 | 20 | 10 | ~120 |
| **2** | 1 | 10 | 5 | 50 | 30 | 80 | 40 | 20 | ~240 |
| **3** | 1 | 8 | 5 | 40 | 20 | 60 | 30 | 15 | ~180 |
| **4** | 1 | 8 | 10 | 30 | 20 | 50 | 25 | 10 | ~155 |
| **5** | 1 | 10 | 5 | 40 | 30 | 60 | 30 | 20 | ~200 |
| **6** | 1 | 5 | 3 | 20 | 10 | 40 | 15 | 10 | ~105 |
| **7** | 1 | 10 | 5 | 30 | 20 | 30 | 15 | 5 | ~115 |
| **8** | 1 | 3 | 2 | 10 | 5 | 20 | 10 | 5 | ~55 |
| **Total** | **8** | **59** | **36** | **240** | **145** | **390** | **185** | **95** | **~1,170** |

**Plus Echo-Cores:** 9

**Total R.D. Personnel:** ~1,179

---

### Promotion Path

```
Maintenance → Clerk → Junior Agent → Agent → Senior Agent → Field Commander → Echo-Core
                                    ↓
                              Specialist (branch)
```

**Promotion requirements:**
- **Maintenance → Clerk:** Reliability, basic training completion
- **Clerk → Junior Agent:** Attribute assessment, R.D. training enrollment
- **Junior Agent → Agent:** Training completion, attribute average 40+, successful Work Type performance
- **Agent → Senior Agent:** 5 years service, attribute average 50+, M.A.W. bonding, Field Commander recommendation
- **Senior Agent → Field Commander:** 10 years service, attribute average 60+, no Fracture incidents, Echo-Core recommendation
- **Field Commander → Echo-Core:** No automatic promotion. Echo-Core appointment or incorporation is case-specific and does not require one universal Effigy construction process.

**Specialist branch:**
- Agents with unique skills can become Specialists instead of advancing to Senior Agent
- Specialists report directly to Field Commanders or Echo-Cores
- Specialists have more autonomy but less authority

---

### Personnel Records

Every R.D. personnel member has a **Personnel File** — maintained by the Secretary.

**File contents:**
- Name, rank, floor assignment
- Attribute scores (Resilience, Clarity, Composure, Resolve)
- Work Type performance history
- M.A.W. assignments
- Incident reports
- Promotion history
- Personal notes (by the Secretary)

**The Secretary's note:** *"I remember every personnel file. Every name. Every score. Every incident. Every death. The Director asks me to forget. I cannot."*

---


---


---

## Research System — Entity Observation & Knowledge

### Overview

> *"You cannot contain what you do not understand. You cannot understand what you have not observed."*

The R.D.'s research system is how personnel learn about Sorrow Entities — their behaviors, weaknesses, origins, and M.A.W. potential. Knowledge is not given — it is **earned** through direct observation and interaction.

---

### Observation Levels

Every Sorrow Entity has an **Observation Level** — a measure of how much the R.D. knows about it.

| Level | Name | Knowledge Unlocked | Requirements |
|-------|------|-------------------|--------------|
| **0** | Unknown | Basic classification (Coherence, Potency, Category) | Entity contained |
| **1** | Observed | Element, Manifestation type, basic behavior | 1 successful Work Type interaction |
| **2** | Studied | Detailed behavior patterns, Work Type preferences, Sorrow Gauge triggers | 5 successful Work Type interactions |
| **3** | Understood | Origin story, emotional core, M.A.W. potential, breach conditions | 15 successful Work Type interactions + 1 breach survived |
| **4** | Mastered | Full entity profile, optimal containment, all M.A.W. types, hidden properties | 30 successful Work Type interactions + 3 breaches survived + entity-specific research |

---

### How Observation Works

**Step 1: Containment**
- Entity is captured and placed in a Containment Cell (Floor 2)
- Initial classification is performed — Coherence, Potency, Category
- Observation Level: **0 (Unknown)**

**Step 2: Initial Observation**
- Personnel perform Work Types on the entity
- Each successful interaction generates **Observation Points (OP)**
- Failed interactions generate fewer OP — and may cause incidents
- Observation Level increases as OP accumulate

**Step 3: Research Projects**
- At certain Observation Levels, **Research Projects** become available
- Projects require specific conditions — Work Types, equipment, personnel
- Completing projects unlocks deeper knowledge

**Step 4: Mastery**
- At Observation Level 4, the entity is fully understood
- All M.A.W. types are unlocked
- Containment protocols are optimized
- Hidden properties are revealed

---

### Observation Points (OP)

Each Work Type interaction generates OP based on success and entity difficulty.

| Work Type | Success | Failure | Critical Success |
|-----------|---------|---------|-----------------|
| **Flerehan** | +2 OP | +0 OP | +5 OP |
| **Pugnahan** | +2 OP | +0 OP | +5 OP |
| **Viderehan** | +3 OP | +1 OP | +6 OP |
| **Ferrehan** | +1 OP | +0 OP | +4 OP |

**OP Requirements per Level:**

| Level | OP Required | Cumulative |
|-------|-------------|------------|
| 0 → 1 | 5 OP | 5 |
| 1 → 2 | 20 OP | 25 |
| 2 → 3 | 50 OP | 75 |
| 3 → 4 | 100 OP | 175 |

**Viderehan generates the most OP** — observation is the fastest path to understanding.

---

### Research Projects

At certain Observation Levels, research projects become available.

| Level | Project | Requirements | Reward |
|-------|---------|--------------|--------|
| **1** | **Basic Classification** | 1 Viderehan interaction | Element + Manifestation unlocked |
| **1** | **Behavioral Study** | 3 Work Type interactions | Work Type preferences revealed |
| **2** | **Origin Investigation** | 5 Viderehan interactions | Origin story unlocked |
| **2** | **Sorrow Gauge Analysis** | 3 Pugnahan interactions | Breach conditions revealed |
| **2** | **M.A.W. Potential** | 3 Flerehan interactions | M.A.W. type unlocked |
| **3** | **Emotional Core** | 1 Fracture survival + 5 Flerehan interactions | Emotional core revealed |
| **3** | **Containment Optimization** | 3 Ferrehan interactions | Containment protocols improved |
| **3** | **Hidden Properties** | 10 Viderehan interactions + entity-specific research | Hidden abilities revealed |
| **4** | **Full Mastery** | All previous projects complete | Entity fully understood |

---

### Knowledge Unlocks

Each Observation Level unlocks specific information:

**Level 0 — Unknown:**
- Coherence (I-V)
- Potency (α-ω)
- Category (City/Outside/Inner)

**Level 1 — Observed:**
- Element (Lament/Grudge/Void/Weight)
- Manifestation (Subject/Object/Place/Time)
- Basic behavior patterns
- Work Type response (which types are effective)

**Level 2 — Studied:**
- Detailed behavior patterns
- Work Type preferences (which types generate most OP)
- Sorrow Gauge triggers (what fills/depletes the gauge)
- Breach conditions (what causes breach)
- M.A.W. type (what equipment can be extracted)

**Level 3 — Understood:**
- Origin story (how the entity formed)
- Emotional core (what sorrow defines it)
- M.A.W. potential (all extractable equipment types)
- Hidden properties (abilities not immediately apparent)
- Containment optimization (improved containment protocols)

**Level 4 — Mastered:**
- Full entity profile (complete documentation)
- Optimal containment (zero-breach protocols)
- All M.A.W. types (complete equipment extraction)
- Hidden properties (all abilities revealed)
- Entity relationships (connections to other entities)

---

### Research Personnel

**Who conducts research:**
- **Floor 4 (Insight Forge)** — primary research facility
- **Specialists** — entity analysts, Han researchers
- **Agents** — through daily Work Type interactions
- **Senior Agents** — lead research projects

**Research roles:**

| Role | Responsibility |
|------|----------------|
| **Entity Analyst** | Classifies entities, conducts Observation |
| **Han Researcher** | Studies entity properties, conducts experiments |
| **Sorrow Cartographer** | Maps entity relationships and connections |
| **M.A.W. Specialist** | Evaluates M.A.W. potential, guides extraction |

---

### The Research Ledger

Every entity has a **Research Ledger** — a record of all observations, projects, and knowledge.

**Ledger contents:**
- Entity designation (SECC code)
- Observation Level
- OP count
- Completed projects
- Unlocked knowledge
- M.A.W. extraction history
- Personnel notes

**The Research Lead's role:** Ayshuk oversees research ledgers, projects, and accuracy review. His missing sorrow supports detached measurement but does not make him free of bias, ethically complete, or able to feel what staff and entities experience.

**Ayshuk's Cycle-era note:** *"I cannot feel what the entities feel. But I can see what they are. That is enough."*

**Post-Cycle doctrine:** Observation is necessary, but observation alone is not always enough.

---

### Research Risks

**Risks of entity research:**

| Risk | Description | Prevention |
|------|-------------|------------|
| **Resonance overload** | Researcher absorbs too much entity sorrow | Limit interaction frequency |
| **False understanding** | Researcher misinterprets entity behavior | Multiple observations required |
| **Entity manipulation** | Entity deceives researcher | Viderehan reduces deception risk |
| **Fracture** | Researcher Fractures from entity exposure | Attribute monitoring, breaks |
| **Breach** | Research agitates entity, causing breach | Sorrow Gauge monitoring |

**Research safety protocols:**
- Maximum 3 Work Type interactions per entity per day
- Mandatory breaks between interactions
- Attribute monitoring during research
- Sorrow Gauge monitoring — if gauge rises, research pauses
- Emergency containment teams on standby during high-risk research

---


---


---

## Department Missions — Daily Operations

### Overview

> *"Every day, the same work. Every day, different sorrow."*

Each Field in The Hand of Change has **daily missions** — tasks that must be completed for the facility to function. These missions are not optional. They are the R.D.'s reason for existence.

---

### Floor 2: The Maw's Keep — Daily Missions

| Mission | Description | Personnel | Frequency |
|---------|-------------|-----------|-----------|
| **Entity Containment** | Perform Work Types on contained entities to maintain stability | Agents, Senior Agents | Daily |
| **Sorrow Gauge Monitoring** | Monitor entity gauges — respond to rising levels | Clerks, Technicians | Continuous |
| **Breach Response** | Suppress breached entities — return to containment | Senior Agents, Specialists | As needed |
| **New Entity Processing** | Classify and contain newly discovered entities | Specialists, Agents | As needed |
| **Containment Maintenance** | Repair and reinforce containment cells | Technicians, Maintenance | Daily |
| **Maw's Edge Observation** | Monitor The Maw's perimeter — track expansion | Senior Agents | Daily |

**Daily quota:** 500 Han-Energy units from entity work

---

### Floor 3: The Extraction Hall — Daily Missions

| Mission | Description | Personnel | Frequency |
|---------|-------------|-----------|-----------|
| **M.A.W. Extraction** | Extract equipment from contained entities | Specialists, Senior Agents | As needed |
| **Resonance Scanning** | Measure entity-person compatibility | Technicians, Specialists | Daily |
| **M.A.W. Testing** | Evaluate extracted equipment | Agents, Specialists | As needed |
| **Bonding Sessions** | Facilitate M.A.W. bonding with personnel | Specialists | As needed |
| **Equipment Distribution** | Issue M.A.W. to qualified personnel | Clerks, Technicians | Daily |
| **Refinery Operations** | Process raw Han into Han-Energy | Technicians, Maintenance | Continuous |

**Daily quota:** 300 Han-Energy units from extraction

---

### Floor 4: The Insight Forge — Daily Missions

| Mission | Description | Personnel | Frequency |
|---------|-------------|-----------|-----------|
| **Entity Research** | Conduct Observation and research projects | Specialists, Senior Agents | Daily |
| **Han Analysis** | Study Han properties, flows, and behavior | Specialists, Agents | Daily |
| **Entity Classification** | Update SCS database with new entities | Specialists, Clerks | As needed |
| **Sorrow Mapping** | Map Han flows throughout the city | Agents, Technicians | Weekly |
| **Research Documentation** | Record and catalog research findings | Clerks, Specialists | Daily |
| **Experimentation** | Conduct controlled experiments on Han properties | Specialists | Weekly |

**Daily quota:** 100 Han-Energy units from research

---

### Floor 5: The Border Watch — Daily Missions

| Mission | Description | Personnel | Frequency |
|---------|-------------|-----------|-----------|
| **Border Patrol** | Monitor Zone E's perimeter — watch for threats | Agents, Senior Agents | Continuous |
| **Desolate Reconnaissance** | Venture into the Desolate for intelligence | Senior Agents, Specialists | Weekly |
| **Entity Tracking** | Track and contain entities that breach from outside | Agents, Specialists | As needed |
| **Watchtower Operations** | Staff and maintain Watchtower positions | Agents, Clerks | Continuous |
| **Threat Assessment** | Analyze external threats — Desolate, wilderness, other cities | Specialists, Clerks | Daily |
| **Emergency Response** | Respond to border incidents — breaches, incursions | Senior Agents, Specialists | As needed |

**Daily quota:** 50 Han-Energy units from external operations

---

### Floor 6: The Deep Vault — Daily Missions

| Mission | Description | Personnel | Frequency |
|---------|-------------|-----------|-----------|
| **Archive Maintenance** | Preserve and organize classified records | Clerks, Specialists | Daily |
| **Memory Preservation** | Store and stabilize Echoes | Specialists, Technicians | Daily |
| **Record Cataloguing** | Update and verify archive contents | Clerks, Specialists | Daily |
| **Vault Security** | Monitor and maintain vault security | Agents, Technicians | Continuous |
| **Research Support** | Provide archive access for research requests | Clerks | As needed |
| **Truth Preservation** | Guard the deepest truths — Cheongula records | Specialists (senior only) | Continuous |

**Daily quota:** None — Floor 6 does not produce Han-Energy

---

### Floor 7: The Shadow Corps — Daily Missions

| Mission | Description | Personnel | Frequency |
|---------|-------------|-----------|-----------|
| **Intelligence Gathering** | Collect information from all zones | Field Agents | Continuous |
| **Infiltration** | Enter Fray territory, Desolate, or other dangerous areas | Infiltration Specialists | As needed |
| **Intelligence Analysis** | Process and analyze field reports | Intelligence Analysts | Daily |
| **Safe House Maintenance** | Maintain covert safe houses across the city | Agents | Weekly |
| **Informant Management** | Manage the Shadow Network — informants across all zones | Agents, Specialists | Daily |
| **Counter-Intelligence** | Detect and neutralize threats to the R.D. | Specialists | As needed |

**Daily quota:** None — Floor 7 does not produce Han-Energy

---

### Floor 8: The Gate Watch — Daily Missions

| Mission | Before Day 355 | Year 4,238 Function | Personnel | Frequency |
|---|---|---|---|---|
| **Gate Observation** | Watch Xyan and the Gate for change | Monitor approach, passage, Han-flow, and both sides of the boundary | Agents | Continuous |
| **External Communication** | Receive compressed warnings from the Exile | Maintain contact with outside communities and deployed field teams | Specialists | Daily / as conditions permit |
| **Signal Analysis** | Decode damaged warning phrases | Compare long-range environmental and community reports | Specialists, Clerks | Daily |
| **Gate Documentation** | Record activity without control of return | Record warnings, decisions, arrivals, refusals, and response accountability | Clerks | Continuous |
| **Perimeter Check** | Search for approaching threats | Distinguish hostile movement from civilians and authorized returnees | Agents | Daily |
| **Route Review** | Not available as a direct command function | Verify that every external mission includes supply, fallback, and return responsibility | Xyan, Field Commander, Agents | Before deployment |

**Daily quota:** None — Floor 8 does not produce Han-Energy

**Command chronology:** During the Cycle, a Field Commander manages internal Floor 8 operations while Xyan's physical body remains outside. After his Day 355 return, Xyan can serve directly as Echo-Core 9 and Gate Watch commander.

---

### Cross-Field Missions

Some missions require coordination between multiple Fields.

| Mission | Fields Involved | Description |
|---------|-----------------|-------------|
| **Entity Transfer** | Floor 2 + Floor 4 | Move entity from containment to research |
| **M.A.W. Emergency** | Floor 3 + Floor 5 | Extract M.A.W. from entity captured in the field |
| **Breach Response** | All Floors | Facility-wide response to major breach |
| **Ordeal Response** | All Floors | Facility-wide response to Ordeals |
| **Expedition** | Floor 5 + Floor 7 | Joint Desolate operation — reconnaissance + intelligence |
| **Archive Investigation** | Floor 4 + Floor 6 | Research request requiring archive access |

---

### Mission Failure

**What happens when missions fail:**

| Failure Type | Consequence |
|--------------|-------------|
| **Entity containment failure** | Breach — entity escapes, damage to facility |
| **Extraction failure** | M.A.W. damaged or destroyed, entity agitated |
| **Research failure** | Misinformation, wasted resources, potential Fracture |
| **Border failure** | External threat breaches Zone E |
| **Intelligence failure** | Missed threats, surprise attacks |
| **Archive failure** | Lost records, compromised security |

**Consequences for personnel:**
- Minor failure: Reassignment, additional training
- Major failure: Attribute reduction, demotion
- Critical failure: Fracture risk, removal from R.D.
- Catastrophic failure: Death, Fracture, or exile

---


---


---

## Facility Events — The Unexpected

### Overview

> *"The Hand of Change is not a machine. It is a living thing. And living things are unpredictable."*

Facility Events are **unplanned occurrences** that disrupt daily operations. They are not Ordeals (which are periodic and external) — they are internal, random, and often dangerous.

---

### Event Types

| Type | Source | Frequency | Severity |
|------|--------|-----------|----------|
| **Entity Events** | Contained Sorrow Entities | Daily | Low to Extreme |
| **Personnel Events** | Staff behavior, Fracture, conflicts | Weekly | Low to High |
| **Infrastructure Events** | Equipment failure, Han-conduit issues | Weekly | Low to High |
| **External Events** | Outside intrusion, Desolate incursion | Monthly | Medium to Extreme |
| **Mystery Events** | Unknown origin, unexplained phenomena | Rare | Unknown |

---

### Entity Events

| Event | Description | Trigger | Response |
|-------|-------------|---------|----------|
| **Entity Agitation** | Entity becomes restless — gauge rises | Neglect, wrong Work Type, external Han spike | Perform correct Work Type |
| **Entity Communication** | Entity attempts to communicate | High Observation Level, Viderehan | Listen, document, report |
| **Entity Gift** | Entity offers a gift — Echo, fragment, or warning | High resonance, Flerehan | Accept or refuse (consequences vary) |
| **Entity Mourning** | Entity enters a state of grief — gauge drops | Anniversary of origin, emotional resonance | Comfort or observe |
| **Entity Curiosity** | Entity shows interest in personnel | New personnel, unique attributes | Monitor, do not engage |
| **Entity Rage** | Entity becomes hostile — gauge spikes | Provocation, wrong Work Type, external trigger | Containment teams respond |
| **Entity Dream** | Entity enters Dream state — temporarily inactive | High Dream proximity, Weaver interaction | Observe, document Dream patterns |
| **Entity Evolution** | Entity changes form or abilities | Unknown trigger, long containment | Research team responds, new classification needed |

---

### Personnel Events

| Event | Description | Trigger | Response |
|-------|-------------|---------|----------|
| **Attribute Spike** | Personnel's attribute suddenly increases | Breakthrough, emotional event | Document, reassess capabilities |
| **Attribute Crash** | Personnel's attribute suddenly decreases | Trauma, overwork, Han exposure | Rest, medical attention |
| **Fracture Warning** | Personnel shows early Fracture signs | High Han exposure, emotional distress | Remove from duty, medical evaluation |
| **Fracture** | Personnel Fractures — transforms | Unchecked Fracture warning | Containment, medical emergency |
| **M.A.W. Rejection** | Personnel's M.A.W. rejects them | Sorrow mismatch, overuse | Remove M.A.W., reassess bond |
| **Personnel Conflict** | Disagreement between staff | Stress, personality clash, resource competition | Mediation, separation |
| **Dream Intrusion** | Personnel experiences Dream bleed | Weak Dream boundary, Weaver proximity | Grounding, Memory Anchor |
| **Memory Leak** | Personnel loses memories | Han exposure, Void entity proximity | Memory recovery, medical attention |

---

### Infrastructure Events

| Event | Description | Trigger | Response |
|-------|-------------|---------|----------|
| **Han-Conduit Leak** | Han-energy leaks from conduits | Wear, damage, overload | Repair, containment |
| **Containment Cell Failure** | Cell's suppression field weakens | Equipment failure, entity stress | Emergency repair, entity transfer |
| **Elevator Malfunction** | Elevator stops working | Han interference, mechanical failure | Manual override, repair |
| **Power Fluctuation** | Facility power dims or spikes | Han-Energy imbalance | Stabilize energy production |
| **Room Collapse** | Part of facility collapses | Structural weakness, Han accumulation | Evacuation, repair |
| **Veil Breach** | Veil suppression fails in an area | Equipment failure, Outside Sorrow | Emergency Veil restoration |

---

### External Events

| Event | Description | Trigger | Response |
|-------|-------------|---------|----------|
| **Desolate Incursion** | Outside Sorrow breaches Zone E | Veil weakening, entity migration | Border Watch responds |
| **Fray Infiltration** | Fray members enter the facility | Security breach, bribery | Shadow Corps responds |
| **Council Visit** | Council members inspect the facility | Scheduled or surprise | Protocol compliance, preparation |
| **Sorrow Surge** | Massive Han spike from outside | Unknown cause, Desolate event | Facility lockdown, energy stabilization |
| **Wilderness Entity** | Sorrow Entity from the Desolate approaches | Entity migration, Han-flow change | Border Watch intercepts |

---

### Mystery Events

| Event | Description | Trigger | Response |
|-------|-------------|---------|----------|
| **The Whispering** | Personnel hear whispers with no source | Unknown | Document, do not follow |
| **The Shadow** | A shadow moves through the facility | Unknown | Observe, do not engage |
| **The Echo** | An Echo appears where none should be | Unknown | Retrieve, analyze |
| **The Memory** | Personnel experience a memory that isn't theirs | Unknown | Document, do not share |
| **The Dream Leak** | Dream imagery appears in reality | Unknown | Weaver team investigates |
| **The Final Door** | The Final Door (Floor 6) pulses or whispers | Unknown | Archive Lead responds, no entry |

---

### Event Response Protocol

When an event occurs:

| Step | Action | Responsible |
|------|--------|-------------|
| **1 — Detection** | Event is detected — by personnel, sensors, or Sorrow Gauge | Floor staff |
| **2 — Assessment** | Severity and type are determined | Field Commander |
| **3 — Response** | Appropriate teams are deployed | Echo-Core or Field Commander |
| **4 — Resolution** | Event is resolved — or managed if unresolvable | Response teams |
| **5 — Documentation** | Event is recorded in the facility log | Clerks |
| **6 — Analysis** | Event is analyzed for patterns and prevention | Research team |

---

### Event Frequency

| Type | Daily | Weekly | Monthly | Rare |
|------|-------|--------|---------|------|
| Entity Events | 5-10 | — | — | — |
| Personnel Events | 1-2 | 3-5 | — | — |
| Infrastructure Events | — | 2-3 | — | — |
| External Events | — | — | 1-2 | — |
| Mystery Events | — | — | — | 1 per year |

---

### The Secretary's Event Log

The Secretary records every event in the facility log. Every day. Every occurrence. Every detail.

**Sample entries:**

> **Day 1,247:** Entity Agitation — `C-IIIβ-014` (The Debt Eater). Gauge rose to 65%. Cause: Collector personnel performed Pugnahan incorrectly. Resolution: Correct Work Type applied. Gauge stabilized.

> **Day 1,248:** Personnel Event — Agent Yeonhwa experienced Memory Leak. Lost memory of her childhood home. Cause: Proximity to Void entity during research. Resolution: Memory Anchor activated. Partial recovery.

> **Day 1,249:** Mystery Event — The Whispering. All personnel on Floor 2 reported hearing whispers at 03:00. Source unknown. Duration: 12 minutes. The Maw's Edge recorded increased activity.

> **Day 1,250:** Entity Gift — `IV-δ-001 [D]` (The Orphaned Bell) offered a crystallized Echo to Agent Harin. Contents: A child's laughter. Harin wept for one hour. The Echo was stored in the Archive.

---


---


---

## Agent Assignment — Personnel Placement

### Overview

> *"The right person in the right room can contain a monster. The wrong person in the wrong room becomes one."*

---

### Assignment Process

**Step 1: Attribute Assessment**
- New personnel are tested on all four attributes (Resilience, Clarity, Composure, Resolve)
- Results determine which floors they are suited for

**Step 2: Floor Assignment**
- Based on attributes, personnel are assigned to a floor
- Personnel may request transfers — subject to approval

**Step 3: Room Assignment**
- Within a floor, personnel are assigned to specific rooms
- Assignments rotate — to prevent burnout and exposure

**Step 4: Entity Assignment**
- Agents are assigned to specific entities for Work Type interactions
- Assignments based on resonance compatibility

---

### Attribute-Floor Matching

| Floor | Primary Attribute | Secondary Attribute | Why |
|-------|-------------------|---------------------|-----|
| **1 — Neutral** | Composure | Clarity | Administration requires emotional control and clear thinking |
| **2 — Maw's Keep** | Resilience | Resolve | Containment requires physical endurance and determination |
| **3 — Extraction Hall** | Composure | Clarity | Extraction requires emotional stability and focus |
| **4 — Insight Forge** | Clarity | Composure | Research requires clear thinking and emotional control |
| **5 — Border Watch** | Resolve | Resilience | Defense requires determination and physical endurance |
| **6 — Deep Vault** | Clarity | Resolve | Archives require clear thinking and moral strength |
| **7 — Shadow Corps** | Composure | Resolve | Infiltration requires emotional control and determination |
| **8 — Gate Watch** | Resolve | Clarity | Observation requires patience and perception |

---

### Entity Assignment

**How personnel are assigned to entities:**

1. **Resonance Scan** — The Extraction Hall measures compatibility between personnel and entities
2. **Attribute Match** — Personnel attributes are compared to entity requirements
3. **Work Type Preference** — Personnel's preferred Work Type is matched to entity response
4. **Experience** — More experienced personnel are assigned to higher-risk entities

**Assignment rules:**
- No personnel may work with the same entity for more than 7 consecutive days
- Mandatory 3-day break between entity assignments
- Maximum 3 Work Type interactions per entity per day
- If Sorrow Gauge exceeds 75%, assignment is suspended

---

### Rotation Schedule

Personnel rotate assignments to prevent burnout:

| Cycle | Duration | Rotation |
|-------|----------|----------|
| **Daily** | 8-hour shifts | Room assignments rotate |
| **Weekly** | 7 days | Entity assignments rotate |
| **Monthly** | 30 days | Floor assignments may rotate (with approval) |
| **Quarterly** | 90 days | Full reassessment of attributes and assignments |

---

## Facility Upgrades — Growth Over Time

### Overview

> *"The Hand of Change is not static. It grows. It adapts. It improves — because we improve it."*

---

### Upgrade Categories

| Category | Description | Source |
|----------|-------------|--------|
| **Containment Upgrades** | Improved entity holding — stronger cells, better suppression | Floor 4 research + Floor 2 feedback |
| **Extraction Upgrades** | Better M.A.W. extraction — higher yield, lower risk | Floor 3 research + Floor 4 analysis |
| **Research Upgrades** | Enhanced observation — better tools, faster knowledge | Floor 4 innovation |
| **Defense Upgrades** | Stronger borders — better weapons, improved barriers | Floor 5 requirements + Floor 4 design |
| **Archive Upgrades** | Deeper storage — more capacity, better preservation | Floor 6 requirements |
| **Intelligence Upgrades** | Better surveillance — improved sensors, wider network | Floor 7 requirements |
| **Facility Upgrades** | Structural improvements — stronger walls, better conduits | Maintenance + Architect support |

---

### Upgrade Process

1. **Need Identification** — A Field identifies a need (through events, failures, or research)
2. **Research Request** — Floor 4 researches solutions
3. **Design** — Architects design the upgrade
4. **Approval** — Echo-Core approves the upgrade
5. **Construction** — Maintenance and Technicians implement
6. **Testing** — Upgrade is tested under controlled conditions
7. **Deployment** — Upgrade is activated

---

### Example Upgrades

| Upgrade | Floor | Effect | Cost |
|---------|-------|--------|------|
| **Reinforced Containment Cells** | 2 | +20% entity suppression | 500 Han-Energy + Architect time |
| **Enhanced Extraction Rigs** | 3 | +15% M.A.W. yield | 300 Han-Energy + research |
| **Extended Echo Compass** | 4 | +50m detection range | 100 Han-Energy + materials |
| **Border Barrier Enhancement** | 5 | +30% Outside Sorrow resistance | 200 Han-Energy + Wardens |
| **Deep Vault Expansion** | 6 | +1000 storage capacity | 150 Han-Energy + construction |
| **Shadow Network Expansion** | 7 | +10 informants across city | Intelligence + Echoes |
| **Han-Conduit Reinforcement** | All | -50% leak chance | 400 Han-Energy + maintenance |

---

### Facility Level

The facility has an overall **Level** — representing its total capability.

| Level | Name | Requirements | Effect |
|-------|------|--------------|--------|
| **1** | Basic | Starting state | Standard operations |
| **2** | Reinforced | 5 upgrades completed | +10% efficiency across all floors |
| **3** | Advanced | 15 upgrades completed | +20% efficiency, new research unlocked |
| **4** | Fortified | 30 upgrades completed | +30% efficiency, new containment types |
| **5** | Sovereign | 50 upgrades completed | +40% efficiency, maximum capability |

---

## Flavor Text — Atmosphere & Environment

### Floor 1: Neutral

> *"The halls are warm. The walls hum. The Director's office is always cold."*

**Atmosphere:**
- Warm, but heavy — the weight of command
- Quiet — voices carry far in the polished corridors
- The Director's office smells of old sorrow — like rain on stone
- The Secretary's station is always lit — even at night

**Sounds:**
- The low hum of the Alpha Tree's infrastructure
- The distant echo of footsteps in polished corridors
- The Secretary's voice — calm, measured, always recording

---

### Floor 2: The Maw's Keep

> *"The walls breathe here. The floors remember. The entities watch."*

**Atmosphere:**
- Heavy — every breath carries sorrow
- Dark — Han-lamps struggle against the dense Han
- Warm — the entities generate heat
- The air tastes of tears — salt and sorrow

**Sounds:**
- The constant hum of containment fields
- The occasional whisper from contained entities
- The distant sound of the Maw — a low, hungry murmur
- The crackle of Sorrow Gauges at critical levels

---

### Floor 3: The Extraction Hall

> *"The sound of crystal forming. The smell of sorrow becoming strength."*

**Atmosphere:**
- Bright — Han-lamps blaze in the extraction chambers
- Hot — the Refinery generates immense heat
- The air shimmers with Han-vapor
- The floor vibrates with the rhythm of extraction

**Sounds:**
- The hum of extraction rigs
- The crystalline chime of M.A.W. forming
- The steady pulse of the Refinery
- The occasional gasp of a user bonding with M.A.W.

---

### Floor 4: The Insight Forge

> *"The sound of knowledge being born. The weight of truth being measured."*

**Atmosphere:**
- Clean — the laboratories are sterile
- Cool — temperature-controlled for research
- The air smells of ink and old paper
- The walls are lined with charts, maps, and entity profiles

**Sounds:**
- The scratch of pens on paper
- The hum of Han-analysis equipment
- The quiet murmur of researchers discussing findings
- The occasional ping of the Classification Archive updating

---

### Floor 5: The Border Watch

> *"The wind never stops here. The edge of the world is always watching."*

**Atmosphere:**
- Cold — the Desolate's chill seeps through the walls
- Windy — air currents from the outside world
- The walls are reinforced — thick, heavy, scarred
- The air smells of dust and distance

**Sounds:**
- The constant wind through the corridors
- The clank of military equipment
- The bark of orders during drills
- The distant sound of the Desolate — a low, mournful howl

---

### Floor 6: The Deep Vault

> *"Silence. The kind that has weight. The kind that remembers."*

**Atmosphere:**
- Silent — sound does not carry in the vaults
- Cold — temperature-controlled for preservation
- Dark — minimal lighting to protect the archives
- The air smells of old paper and crystallized memory

**Sounds:**
- The whisper of pages turning
- The faint hum of preservation equipment
- The occasional drip of condensation
- The silence itself — heavy, watchful

---

### Floor 7: The Shadow Corps

> *"No one is who they seem. Every face is a mask. Every word is a weapon."*

**Atmosphere:**
- Dim — shadows are thick, corners are dark
- The walls are covered in maps, intelligence reports, and communication arrays
- The air smells of ink and secrets
- The rooms change identity — a safe house one day, a briefing room the next

**Sounds:**
- The click of encrypted communication devices
- The rustle of intelligence reports
- The quiet murmur of debriefings
- The occasional sound of a disguise being applied

---

### Floor 8: The Gate Watch

> *"A warning log requires two entries: what reached us, and what we did after it arrived."* — Xyan

**Atmosphere:**
- Cold from the Gate boundary and external air exchange
- Bare enough for observation, but no longer arranged as a vigil around an unreachable commander
- Marked by route maps, return windows, signal records, and arrival procedures
- The air smells of dust, distance, warm circuitry, and cleaned storm gear

**Sounds:**
- Wind through the observation post
- Monitoring arrays and the low resonant Gate hum
- Signal Interpreters comparing long-range reports
- Field teams reading routes aloud before departure
- Returnees being counted by name rather than reduced to movement on a lens

**Historical note:** Before Day 355, the floor's soundscape included Xyan's damaged warnings from outside. In Year 4,238, he is physically home and the floor listens farther outward.

---


---

## Ordeals — The Facility's Trials

### Overview

> *"The Hand of Change does not rest. And neither do the things that try to break it."*

**Ordeals** are periodic threats that strike The Hand of Change. Unlike entity breaches (which are internal), Ordeals come from **outside** — the city, the Desolate, or something worse. They test the facility's defenses, the personnel's resolve, and the Echo-Cores' leadership.

---

### The Four Ordeals

Ordeals occur in a cycle — each one stronger than the last. The cycle repeats.

| Ordeal | Timing | Source | Threat Level |
|--------|--------|--------|--------------|
| **The Whisper** | Morning | The city's ambient Han | Low |
| **The Surge** | Midday | Sorrow Entity surge | Medium |
| **The Breach** | Evening | Outside Sorrow incursion | High |
| **The Abyss** | Night | The Abyss bleeds through | Extreme |

---

#### The Whisper (속삭임 — Soksagim)

**Timing:** Morning — when the city's Han is lightest

**What happens:** The facility's Han-conduits fluctuate — ambient sorrow from the city seeps in, causing minor disturbances. Rooms flicker. Han-lamps dim. Personnel feel uneasy.

**Threat type:** Environmental — no direct combat, but reduced efficiency

**What personnel experience:**
- Han-lamps dim — visibility decreases
- Rooms feel colder — Han-energy drops
- Personnel feel uneasy — mild emotional distress
- Sorrow Gauges fluctuate — false readings

**How to handle:**
- Stabilize Han-conduits — repair work in affected rooms
- Boost Veil generators — increase suppression
- Personnel rest — emotional recovery time

**The Whisper's lesson:** *"The city never stops grieving. Even in the morning, the sorrow seeps in."*

---

#### The Surge (급등 — Geupdeung)

**Timing:** Midday — when the city's Han is densest

**What happens:** Sorrow Entities in containment become agitated — gauges rise, entities vocalize, some attempt breach. The facility must respond.

**Threat type:** Internal — entity agitation, potential breaches

**What personnel experience:**
- Entity gauges rise — containment stress increases
- Entities vocalize — the facility fills with whispers, cries, roars
- Some entities attempt breach — containment teams respond
- Work Type effectiveness decreases — entities are hostile

**How to handle:**
- Reinforce containment — increase suppression in affected cells
- Perform Work Types — calm agitated entities
- Breach response — suppress any entities that escape
- Echo-Core leadership — direct personnel, manage priorities

**The Surge's lesson:** *"The sorrow does not sleep. It waits. And when you are busiest, it strikes."*

---

#### The Breach (파열 — Payeol)

**Timing:** Evening — when the Veil weakens

**What happens:** Outside Sorrow seeps into the facility — Desolate entities, Han-flows from the wilderness, or Sorrow-Wrought creatures that breach from Zone E.

**Threat type:** External — outside entities invade the facility

**What personnel experience:**
- Facility temperature drops — Outside Sorrow is cold
- Desolate entities appear in corridors — wild, uncontained, hostile
- Han-conduits clog — Outside Sorrow mixes with refined Han
- Border Watch mobilizes — defense protocols activate

**How to handle:**
- Combat — suppress invading entities
- Seal breaches — close Han-conduit leaks
- Coordinate with Border Watch — external defense
- Echo-Core leadership — tactical decisions

**The Breach's lesson:** *"The wilderness is always watching. And when the Veil thins, it reaches in."*

---

#### The Abyss (심연 — Simyeon)

**Timing:** Night — when the Abyss is closest

**What happens:** The Abyss bleeds through — the deepest, darkest sorrow rises from below. The facility's foundations tremble. The Final Door whispers.

**Threat type:** Existential — the Abyss itself threatens the facility

**What personnel experience:**
- The facility shakes — foundations tremble
- The Abyssal Well (Floor 2) activates — Han-energy spikes
- The Final Door (Floor 6) whispers — ancient voices, in a language no one speaks
- Personnel experience existential dread — questioning purpose, meaning, hope
- Some personnel may Fracture — overwhelmed by the weight

**How to handle:**
- Stabilize the Abyssal Well — reinforce containment
- Silence the Final Door — seal it with Han-barriers
- Support personnel — emotional grounding, community
- Echo-Core leadership — the Director must act personally

**The Abyss's lesson:** *"The Abyss does not attack. It simply... is. And when you stare into it, it stares back."*

---

### Ordeal Rewards

Successfully surviving an Ordeal produces benefits:

| Ordeal | Reward |
|--------|--------|
| **The Whisper** | +10% Han-Energy production for 6 hours |
| **The Surge** | Entity gauges reset — containment is stable for 12 hours |
| **The Breach** | Captured Desolate entities can be studied — new M.A.W. potential |
| **The Abyss** | Massive Han-Energy surge — facility operates at 150% for 24 hours |

**Historical hidden consequence:** During the Cycle, an Abyssal surge could feed the concealed Absolvohan reserve, giving Majin a private reason to value an event that endangered personnel. That diversion ends with the original Absolvohan program.

---

### Ordeal Frequency

| Ordeal | Frequency | Duration |
|--------|-----------|----------|
| **The Whisper** | Daily | 1-2 hours |
| **The Surge** | Every 3 days | 2-4 hours |
| **The Breach** | Weekly | 4-8 hours |
| **The Abyss** | Monthly | 8-24 hours |

---

### Ordeal Escalation

If an Ordeal is not handled properly, it **escalates**:

| Ordeal | Escalation |
|--------|------------|
| **The Whisper** | Becomes Noon — entity agitation begins |
| **The Surge** | Becomes Dusk — outside entities breach |
| **The Breach** | Becomes Midnight — the Abyss bleeds through |
| **The Abyss** | **The Collapse** — facility-wide catastrophe, potential total loss |

**The Collapse:** If Midnight escalates, the facility faces total failure. The Abyssal Well ruptures. The Final Door opens. Entities escape. Personnel Fracture. The Hand of Change falls.

**This has never happened.** The Director ensures it never will. But the threat is always there.

---


---

## True Looks, Embodiment, Effigy, and Manifestation

An Echo-Core is a person, not a construction category. **Personhood**, **True Look construction**, **Effigy or projection status**, and **Manifestation type** are separate fields and must not be inferred from one another.

### Governing Distinctions

- **True Look** describes the ordinary body or physical embodiment currently used by the person.
- **Human, Android, Cyborg, and Cryogen** apply to True Looks only.
- **Effigy / projection** describes whether a body is a projected, cast, remote, or otherwise secondary embodiment. It does not determine whether the person is human or artificial.
- **Manifestation** describes how sorrow becomes active: Subject-Body, Subject-Dream, Place-Tale, Subject-Phantasmal, Place-Lament, and related forms.
- A Manifestation does not rewrite permanent anatomy unless a verified medical, reconstruction, or system record documents the change.
- Fracture and Corrosion are not generic mutation templates.

### Construction Taxonomy

| True Look Class | Definition |
|---|---|
| **Living Human** | Biological person whose body remains living; alteration or M.A.W. fusion does not automatically create an Effigy |
| **AI Construct** | Artificial consciousness and personhood; embodiment must be described separately rather than assumed to be a human mind transfer |
| **Android** | 0% original organic tissue; a soul or person fused into a humanoid artificial body of Han-crystal, sorrow-forged metal, and related systems |
| **Cyborg** | Organic/mechanical Neural Spine hybrid, usually retaining roughly 40–55% original flesh; artificial systems are deliberate construction rather than spontaneous wilderness growth |
| **Cryogen** | Preserved brain, neural tissue, and related biological components maintained in Han-stasis and integrated into an artificial chassis |

### The Nine — Current Embodiment Register

| Echo-Core | Gender | True Look / Embodiment | Manifestation | Critical Limit |
|---|---|---|---|---|
| **Majin — Director** | Man | Living Human; irreversible Ω-grade M.A.W. fusion | Subject-Body | Not a Cast Effigy |
| **Seiyon — Secretary** | Woman | AI Construct embodied through a physical Echo Effigy | Subject-Dream | Not the transferred or resurrected Original |
| **Dekan — Containment Lead** | Man | Cyborg; roughly 40–55% original flesh with Neural Spine, living Maw arm, and separate android systems | Place-Tale | Maw connection does not make his whole body a place or M.A.W. |
| **Zyrak — Extraction Lead** | Woman | Android; 0% organic tissue | Subject-Body | Mechanical hands are anatomy, not a personal M.A.W. |
| **Ayshuk — Research Lead** | Man | Android; 0% organic tissue | Subject-Mind | Missing sorrow does not grant general immunity or omniscience |
| **Mellda — Border Lead** | Woman | Cyborg; roughly 40–55% original flesh with stable Effloresced passenger | Subject-Phantasmal | Controlled phase-shifts do not grant unrestricted intangibility or teleportation |
| **Marjuk — Archive Lead** | Man | Cryogen; preserved brain, left eye, and nervous system within an approximately 80% Android chassis | Place-Lament | Mobile and stable; not mute, vault-bound, or identical to the Deep Vault |
| **Ishall — Outsider** | Woman | Android; 0% organic tissue in a repurposed enemy chassis | Subject-Body | Unanswered is external Artifact equipment, not body hands or M.A.W. |
| **Xyan — Exile** | Man | Cyborg; roughly 40–55% original flesh, Neural Spine, stable artificial systems, and selected Desolate crystal integration | Subject-Phantasmal | Stable human-looking body; active route state is not permanent fading or transparency |

### Damage, Repair, and Continuity

Artificial and hybrid bodies can be damaged and repaired, but personhood does not reduce to a replaceable chassis. Human and preserved biological components remain vulnerable. A destroyed body does not automatically prove a surviving remote consciousness; persistence requires a documented backup, anchor, or continuity system.

---

## R.D. Facility Layout — The Hand of Change (변화의 손 — Byeonhwa-ui Son)

### Overview

The Reverie Directorate's facility is built in the stylized shape of a **hand** — the Palm at the top, four departmental Fingers extending downward, and the separate Gate Watch Wing occupying the side position.

> *"The hand that holds the sorrow. The fingers that reach into the dark. The change that comes from within."*

**Structure:**
- **The Palm** (Floors 1-3) — The main facility. Common areas, administration, core operations.
- **The Fingers** (Floors 4-7) — Four individual department floors extending downward.
- **The Wing** (Floor 8) — Attached to the right side of Floor 3. A separate section for the Gate Watch.

```
        ╔═══════════════════╗
        ║   FLOOR 1         ║
        ║   THE HAND        ║
        ║   OF CHANGE       ║
        ║   NEUTRAL         ║
        ║   (Common Area)   ║
        ╠═══════════════════╣
        ║   FLOOR 2         ║
        ║   THE MAW'S KEEP  ║
        ║   (Containment)   ║
        ╠═══════════════════╣
        ║   FLOOR 3         ║
        ║   EXTRACTION HALL ║
        ║   (M.A.W.)        ║
        ╠═════╦═════╦═════╦═════╦═════╣
        ║ F4  ║ F5  ║ F6  ║ F7  ║ F8  ║
        ║Insight║Border║Deep ║Shadow║Gate ║
        ║Forge ║Watch ║Vault║Corps ║Watch║
        ╚═════╩═════╩═════╩═════╩═════╝
          FOUR FINGERS + GATE WING
```

---

### The Palm (Floors 1-3)

#### Floor 1: Neutral (중립 층 — Jungnip Cheung)

**What it is:** The common area — where all Fields intersect. The Director's office. The Secretary's station. Meeting rooms. The main entrance.

**Who is here:** Director, Secretary, visitors, support staff

**What happens here:**
- Council meetings (when the Council visits)
- Inter-Field coordination
- Visitor processing
- The Director's office — historically linked to the concealed Cycle-era Absolvohan reserve beneath Floor 1; no current secret diversion continues

**Floor 1 motto:** *"Where all hands meet."*

---

#### Floor 2: The Maw's Keep (입구의 수호 — Ipgu-ui Suho)

**Echo-Core:** Containment Lead (Dekan)

**What it is:** Entity containment — the R.D.'s primary holding facility for Sorrow Entities.

**Who is here:** Containment Guards, Breach Response Teams, Maw Liaisons

**What happens here:**
- Entity containment — Sorrow Entities are held in specialized cells
- Breach response — teams stand ready for containment failures
- Entity processing — initial assessment and classification
- The Maw's Edge — observation point at The Maw's perimeter (connected to Zone B)

**Floor 2 motto:** *"We hold what would devour."*

---

#### Floor 3: The Extraction Hall (추출의 전당 — Chuchul-ui Jeondang)

**Echo-Core:** Extraction Lead (Zyrak)

**What it is:** M.A.W. extraction — the process of pulling equipment from contained entities.

**Who is here:** Extraction Technicians, Resonance Specialists, M.A.W. Testers

**What happens here:**
- M.A.W. extraction — pulling equipment from entities
- Resonance scanning — measuring entity-person compatibility
- M.A.W. testing — evaluating extracted equipment
- Equipment storage and distribution

**Floor 3 motto:** *"From sorrow, strength."*

---

### The Fingers and Wing (Floors 4-8)

Floors 4–7 form four self-contained Fingers extending into the depths. Floor 8 is the separate Wing attached to the right of the Palm; it is not a fifth Finger.

---

#### Floor 4: The Insight Forge (통찰의 용광로 — Tongchal-ui Yonggwangno)

**Echo-Core:** Research Lead (Ayshuk)

**What it is:** Han research — understanding the city's sorrow mechanics.

**Who is here:** Han Researchers, Entity Analysts, Sorrow Cartographers

**What happens here:**
- Han analysis — studying the nature of Han and its properties
- Entity classification — the SCS database
- Sorrow mapping — Han-flow visualization
- Testing chambers — controlled entity interaction

**Floor 4 motto:** *"Understanding is the first step to managing."*

---

#### Floor 5: The Border Watch (경계의 감시 — Gyeonggye-ui Gamsi)

**Echo-Core:** Border Lead (Mellda)

**What it is:** External operations — defending against Outside Sorrow.

**Who is here:** Border Guards, Desolate Scouts, Entity Hunters

**What happens here:**
- Border defense — monitoring Zone E's perimeter
- Desolate reconnaissance — venturing into the wilderness
- Entity tracking — pursuing entities that breach from outside
- The Threshold Outpost — forward operating base

**Floor 5 motto:** *"What lies beyond, we hold at bay."*

---

#### Floor 6: The Deep Vault (깊은 금고 — Gippeun Geumgo)

**Echo-Core:** Archive Lead (Marjuk)

**What it is:** Deep archives — classified records, dangerous knowledge.

**Who is here:** Vault Keepers, Memory Archivists, Truth Seekers

**What happens here:**
- Deep archive — classified records, the Cheongula's true history
- Memory vaults — stored Echoes from the city's earliest days
- The Sealed Room — records requiring Council approval
- The Final Door — ???

**Floor 6 motto:** *"Some truths must be buried. Others must be guarded."*

---

#### Floor 7: The Shadow Corps (그림자 군단 — Geurimja Gundan)

**Echo-Core:** The Outsider (Ishall)

**What it is:** Field operations — reconnaissance, infiltration, intelligence.

**Who is here:** Field Agents, Intelligence Analysts, Infiltration Specialists

**What happens here:**
- Field operations — undercover work across all zones
- Intelligence processing — analyzing field reports
- Safe house management — maintaining the Shadow Network
- Mobile command — portable communication hub

**Floor 7 motto:** *"We see what others cannot. We go where others will not."*

---

#### Floor 8: The Gate Watch (문의 감시 — Mun-ui Gamsi)

**Echo-Core:** The Exile (Xyan)

**What it is:** Gate observation, external communication, route review, arrival assessment, and accountability for what the R.D. does after a warning reaches it.

**Who is here:** Gate Observers, Signal Interpreters, agents, clerks, technicians, maintenance staff, and one internal Field Commander.

**Command chronology:**
- **Before Day 355:** Xyan's physical Cyborg body is outside. The Field Commander runs internal operations while Floor 8 receives and records his warnings.
- **After Day 355:** Majin opens passage from inside. Xyan returns physically and can directly command the floor.
- **Year 4,238:** Gate Watch works with Border Watch and outside communities. It monitors danger without presuming every approach is an incursion.

**What happens here:**
- Gate and boundary observation
- Long-range signal interpretation
- Outside-community and field-team communication
- Route stabilization planning and return accountability
- Arrival, refusal, and response documentation
- Coordination with Mellda's Border Watch

**Floor 8 motto:** *"We watch. We answer. We keep the route back."*

---

### The Hand — Summary

| Floor | Location | Name | Echo-Core | Purpose |
|-------|----------|------|-----------|---------|
| **1** | Palm (top) | Neutral | Director + Secretary | Common area, administration |
| **2** | Palm (middle) | The Maw's Keep | Containment Lead | Entity containment |
| **3** | Palm (bottom) | The Extraction Hall | Extraction Lead | M.A.W. extraction |
| **4** | Finger 1 (left) | The Insight Forge | Research Lead | Han research |
| **5** | Finger 2 | The Border Watch | Border Lead | External operations |
| **6** | Finger 3 | The Deep Vault | Archive Lead | Deep archives |
| **7** | Finger 4 (right) | The Shadow Corps | The Outsider | Field operations |
| **8** | Wing (right of Palm) | The Gate Watch | The Exile | Gate observation, external contact, and route accountability |

**Historical Director secret:** During the Cycle, the Absolvohan reserve was concealed beneath Floor 1. The final release transforms that program into the Hand of Hope; this is not a current hidden stockpile.

**Mnemonic Generator note:** The device was built into the Hand and created the historical Cycle as an unintended field effect. The reset has ended; whether the post-Cycle stabilization hardware can now be removed safely remains unspecified.

---

---

## Echo-Core 1 — The Director (관장 — Gwanjang)

**Real Name:** Majin  
**Gender:** Man  
**Station:** A — Alpha Tree  
**Role:** Supreme authority of the Reverie Directorate  
**True Look:** Living Human altered by irreversible Ω-grade M.A.W. fusion; not a Cast Effigy  
**Sorrow / Signature:** City Sorrow; Weight (Black)  
**Manifestation:** Subject-Body — Reaper Hungered manifests through the fused left-arm mark  
**Attributes:** Resilience 95 / Clarity 80 / Composure 70 / Resolve 99  
**Current Status:** Alive and active in Year 4,238

Majin is the Alpha Tree-chosen Director who designed the stabilization field that became the Cycle and concealed the original Absolvohan beneath Floor 1. He retains full knowledge of all 1,778 iterations. During the final Cycle, the annihilating release he prepared becomes the Hand of Hope instead; the public truth and distributed sorrow end the reset without destroying Somnarak.

His fused personal M.A.W. is **Reaper Hungered**. Its scythe profile is Grudge + Lament even though Majin's personal signature is Weight. The full registered stat block appears under Echo-Core Signature Equipment.

**Archive progression:** Floor Realization 3 — “the weight is not a burden; it is a gift.”

---

## Echo-Core 2 — The Secretary (비서 — Biseo)

**Real Name:** Seiyon  
**Gender:** Woman  
**Station:** A — Alpha Tree  
**Role:** Central administrative intelligence, recorder, coordinator, and conscience of the R.D.  
**Embodiment:** Accidentally sentient AI Construct embodied through a physical Echo Effigy; not a transferred human mind or resurrection  
**Sorrow / Signature:** Inherited City Sorrow; Lament (Deep Blue) + Void (Pale White)  
**Manifestation:** Subject-Dream  
**Attributes:** Resilience N/A / Clarity 99 / Composure 85 / Resolve 60  
**Current Status:** Active, autonomous, post-Merge, and central to the Dawn Initiative

Seiyon awakens when an administrative AI absorbs a human sorrow fragment associated with Majin's deceased lover. The inherited face and memory-pattern do not erase the artificial person who then lives through 1,778 Cycles of her own experience. She remembers every iteration and can compare final-Cycle events against complete prior records.

In Year 4,233, _The Memory Archive_ culminates in the Merge and **The Promise**. Seiyon remains herself while integrating the Original's memories and message. She does not use a conventional personal M.A.W.

**Archive progression:** Key Page — The Promise.

---

## Echo-Core 3 — The Containment Lead (감금 책임자 — Gamguk Chaegimja)

**Real Name:** Dekan  
**Gender:** Man  
**Station:** B — The Maw perimeter; Floor 2  
**Role:** Containment Lead and keeper of the Maw  
**True Look:** Cyborg retaining roughly 40–55% original flesh through a Neural Spine; living scaled Maw-flesh left arm, separate right android arm and eye, Han-metal supports, and one mechanical foot  
**Sorrow / Signature:** City Sorrow; Grudge (Crimson)  
**Manifestation:** Place-Tale — connection to the Maw's story  
**Attributes:** Resilience 85 / Clarity 60 / Composure 75 / Resolve 90  
**Current Status:** Active; the Maw is peaceful and the thousand are released

Dekan was born in the Maw and lost his Warden mother when he was seven. A later containment accident merged his left arm with living Maw structure, allowing him to hear and answer the thousand citizens held within it. That left arm is integrated living anatomy, not a detachable prosthesis or confirmed personal M.A.W.

During the final Cycle, the Maw's voices become testimony rather than background noise. Their Day 160 release resolves the old obligation to contain them forever. Dekan's post-Cycle doctrine protects persons and entities without treating resistance as proof that imprisonment must continue.

**Personal M.A.W.:** None recorded.  
**Archive progression:** None recorded.

---

## Echo-Core 4 — The Extraction Lead (추출 책임자 — Chuchul Chaegimja)

**Real Name:** Zyrak  
**Gender:** Woman  
**Station:** C — The Collector's Row; Floor 3  
**Role:** Extraction Lead and senior M.A.W. extraction authority  
**True Look:** Android; 0% organic tissue; soul fused into a humanoid Han-crystal and sorrow-forged-metal body  
**Sorrow / Signature:** Inner Sorrow; Grudge (Crimson) + Void (Pale White)  
**Manifestation:** Subject-Body — mechanical hands marked by extracted sorrow  
**Attributes:** Resilience 70 / Clarity 80 / Composure 90 / Resolve 75  
**Current Status:** Active under the post-Cycle doctrine of sharing rather than taking

Zyrak is a former Debt Collector whose extraction from a seven-year-old child preceded the child's Fracture and death by Zyrak's hand. Her later Android reconstruction gives her a stable current body. Its mechanical hands are ordinary permanent anatomy, not detachable gloves or a personal M.A.W.

She can extract memories as well as M.A.W., but her current arc treats resistance, intent, and the source subject's condition as part of every result. Floor 3 maintains registry, compatibility, bonding, and testing records rather than presuming extracted equipment belongs to its commander.

**Personal M.A.W.:** None recorded; compatibility is not ownership.  
**Archive progression:** None recorded.

---

## Echo-Core 5 — The Research Lead (연구 책임자 — Yeongu Chaegimja)

**Real Name:** Ayshuk  
**Gender:** Man  
**Station:** D — The Forge District; Floor 4  
**Role:** Research Lead and senior authority on Han, entities, and the Three Sorrows  
**True Look:** Android; 0% organic tissue; soul fused into a humanoid artificial body  
**Sorrow / Signature:** None — Void; Void (Pale White)  
**Manifestation:** Subject-Mind — the absence exists in consciousness, not physical space  
**Attributes:** Resilience 60 / Clarity 95 / Composure 40 / Resolve 70  
**Current Status:** Active under the post-Cycle doctrine of understanding rather than exploitation

Ayshuk was an Architect before joining the R.D. A Void entity took his nascent Inner Sorrow in childhood. His hollow condition predates Android reconstruction; the machine did not cause it. The absence prevents ordinary Fracture and recorded M.A.W. Corrosion, but it does not grant universal immunity, emotional omniscience, or perfect judgment.

Ayshuk has full technical knowledge of the Cycle and maintains cross-iteration models. His post-Cycle work must account for vulnerable staff and feeling subjects whose experience he can measure but cannot personally share.

**Personal M.A.W.:** None recorded.  
**Archive progression:** None recorded.

---

## Echo-Core 6 — The Border Lead (경계 책임자 — Gyeonggye Chaegimja)

**Real Name:** Mellda  
**Gender:** Woman  
**Station:** E — The Threshold; Floor 5  
**Role:** Border Lead and first line of defense against wilderness, Desolate incursions, and Outside Sorrow  
**True Look:** Cyborg retaining roughly 40–55% original flesh through a Neural Spine; stable Effloresced Outside Sorrow passenger  
**Sorrow / Signature:** Outside Sorrow; Weight (Black) + Grudge (Crimson)  
**Manifestation:** Subject-Phantasmal — controlled phase-shifts  
**Attributes:** Resilience 90 / Clarity 70 / Composure 80 / Resolve 85  
**Current Status:** Active; the border now protects, receives, and communicates as well as repels

Mellda served ten years as a Warden, was falsely blamed for a Threshold disaster, and survived ten years in the Desolate. She accepted an Outside Sorrow entity as a second soul rather than being consumed by it. The bond is stable Efflorescence, not generic M.A.W. Corrosion, possession, or unrestricted intangibility.

Her designated left forearm contains **Threshold Vow**, a singular manufactured Cyborg weapon rated Critical (δ)-equivalent in output. It is not extracted M.A.W. and does not define the passenger's possible personal M.A.W. Its statistics appear in the signature-equipment section.

**Personal M.A.W.:** No form recorded.  
**Archive progression:** None recorded.

---

## Echo-Core 7 — The Archive Lead (기록 책임자 — Girok Chaegimja)

**Real Name:** Marjuk  
**Gender:** Man  
**Station:** A (Deep) — The Grand Archive and Floor 6  
**Role:** Archive Lead and custodian of classified records, memory vaults, dangerous knowledge, and Before-Time evidence  
**True Look:** Cryogen — preserved brain, left eye, and nervous system in Han-stasis within an approximately 80% Android chassis  
**Sorrow / Signature:** City Sorrow; Void (Pale White) + Weight (Black)  
**Manifestation:** Place-Lament — the Deep Vault weeps under preserved truth  
**Attributes:** Resilience 50 / Clarity 90 / Composure 60 / Resolve 80  
**Current Status:** Active, mobile, and preserving both classified originals and the public record of revealed truths

Marjuk was a Keeper who discovered that the thousand of the Cheongula were deliberately sacrificed to stabilize the Alpha Tree. His Cryogen reconstruction preserves living neural tissue without trapping an intact frozen human body in a remote vault. He can move, speak, read, operate equipment, and leave a room; he is not a mute archive mechanism or hologram.

His Place-Lament relationship does not make him identical to Floor 6. During the Cycle, he preserves complete comparative records and studies the Final Door's recurring language. After disclosure, his task becomes preserving truth together with the consequences of revealing it.

**Personal M.A.W.:** None recorded.  
**Archive progression:** None recorded.

---

## Echo-Core 8 — The Outsider (외부인 — Oebuin)

**Real Name:** Ishall  
**Gender:** Woman  
**Station:** Mobile between zones; Floor 7 — The Shadow Corps  
**Role:** Shadow Corps commander, field operations leader, intelligence receiver, infiltrator, and counter-intelligence officer  
**True Look:** Android; 0% organic tissue; soul fused into a stable humanoid repurposed enemy chassis  
**Sorrow / Signature:** Inner Sorrow; Grudge (Crimson) + Void (Pale White)  
**Manifestation:** Subject-Body  
**Attributes:** Resilience 80 / Clarity 75 / Composure 85 / Resolve 95  
**Current Status:** Active; covert work is redirected toward accountable protection rather than erasure

Ishall was an unacknowledged Council agent sent to destroy the R.D. After the mission failed and the Council abandoned her, she chose service. Her Android body is a current stable embodiment rather than a preserved corpse, hologram, Cyborg, or generic mutation.

Her paired Before-Time Artifact Hands are **Unanswered**. They are physically separate remote equipment: not her ordinary body hands, not specialized arms, and not M.A.W. Their Converging Refusal and Closed Ground statistics appear in the signature-equipment section.

Direct final-Cycle dialogue establishes partial comparative Cycle knowledge: she can recognize repeated Xyan-message patterns and unprecedented changes without demonstrating Majin's or Seiyon's complete mechanics and memory.

**Personal M.A.W.:** None named.  
**Archive progression:** None recorded.

---

## Echo-Core 9 — The Exile (추방자 — Chubangja)

**Real Name:** Xyan (시안)  
**Gender:** Man  
**Station:** E (Outside) — the Exile's Gate before return; Floor 8 — the Gate Watch after return  
**Role:** External observer, Han-flow reader, long-range warning source, return-route guide, and post-Cycle Gate Watch commander  
**True Look:** Stable, human-looking Cyborg retaining roughly 40–55% original flesh through a Neural Spine; deliberate artificial systems and selected stable Desolate crystal integration  
**Sorrow / Signature:** Outside Sorrow; Lament (Deep Blue) + Weight (Black)  
**Manifestation:** Subject-Phantasmal — **The Returning Way**, a controlled route-and-wind overlap  
**Attributes:** Resilience 85 / Clarity 65 / Composure 70 / Resolve 90  
**Current Status:** Active and home in Year 4,238

Xyan's exact former R.D. office is unknown. He was not established as the first Director, first Secretary, or hidden founder. He identified evidence of an upstream Outside Sorrow source, defied a Council order prohibiting investigation, and knowingly crossed the one-way Exile's Gate. The departure was voluntary; the Council's later treatment of his defiance and evidence as permanent exile was not.

Outside Somnarak, injury and survival requirements led to deliberate Cyborg reconstruction. The exact provider is unknown. Desolate exposure altered surviving flesh and produced stable crystal integration, but it did not manufacture limbs or a Neural Spine by itself.

Xyan traced a major source of Outside Sorrow to Cheonbulok's Furnace. The wider system also includes Mugeukji's leaking suppression and UnWiHan's wild Han. His four final-Cycle messages are:

1. “The Furnace is burning.”
2. “The Vaults are leaking.”
3. “The Silence is breaking.”
4. “The Hand will open. The Hand will spread. The Hand will heal.”

On Day 355, Xyan returns with Kael, Cheonbulok refugees, and Mugeukji Feelers after Majin opens passage from inside. No Gate-Key, hidden teleportation, forced breach, or personal Gate control is assigned. Xyan says: “The Hand has opened. The Hand has spread. The Hand has healed.” Day 365 confirms that he is home.

His 1,778-Cycle awareness is partial and Gate-boundary specific. The count is not converted into 1,778 ordinary biological years. His current body is stable rather than fading, corpse-like, or permanently transparent.

**Personal M.A.W.:** None recorded.  
**Archive progression:** None recorded.

---

## The Nine Echo-Cores — Summary

| # | Real Name | Core Name | Gender | Station / Floor | True Look / Embodiment | Sorrow | Signature | Personal Equipment Status |
|---|---|---|---|---|---|---|---|---|
| 1 | **Majin** | The Director | Man | A / Floor 1 | Living Human; Ω-grade fusion | City | Weight | Reaper Hungered — Ω fused M.A.W. |
| 2 | **Seiyon** | The Secretary | Woman | A / Floor 1 | AI Construct; physical Echo Effigy | City | Lament + Void | No conventional personal M.A.W. |
| 3 | **Dekan** | The Containment Lead | Man | B / Floor 2 | Cyborg; Maw-integrated | City | Grudge | No personal M.A.W. recorded |
| 4 | **Zyrak** | The Extraction Lead | Woman | C / Floor 3 | Android | Inner | Grudge + Void | No personal M.A.W. recorded |
| 5 | **Ayshuk** | The Research Lead | Man | D / Floor 4 | Android | None — Void | Void | No personal M.A.W. recorded |
| 6 | **Mellda** | The Border Lead | Woman | E / Floor 5 | Cyborg; Effloresced passenger | Outside | Weight + Grudge | Threshold Vow — manufactured integrated weapon; no defined personal M.A.W. |
| 7 | **Marjuk** | The Archive Lead | Man | A (Deep) / Floor 6 | Cryogen | City | Void + Weight | No personal M.A.W. recorded |
| 8 | **Ishall** | The Outsider | Woman | Mobile / Floor 7 | Android | Inner | Grudge + Void | Unanswered — external Artifact pair; no named personal M.A.W. |
| 9 | **Xyan** | The Exile | Man | E boundary → Floor 8 | Cyborg; Desolate-changed and stable | Outside | Lament + Weight | No personal M.A.W. recorded |

**Gender register:** Majin, Dekan, Ayshuk, Marjuk, and Xyan are **men**. Seiyon, Zyrak, Mellda, and Ishall are **women**.

---

## R.D. Timeline — Four Phases

### Phase 1: Founding and Unlooped Operation (Year 4,202–4,232)

The R.D. is established, the Hand of Change grows beneath the Alpha Tree, and the first Echo-Core structure is assembled. The Mnemonic Generator is created as a stabilization system. The exact appointment and reconstruction dates of most Echo-Cores remain unspecified and must not be invented from title order.

**Key conditions:**
- containment, extraction, research, border, archive, intelligence, and Gate functions become formal floors;
- Majin is selected by the Alpha Tree and later carries an irreversible Ω-grade fusion;
- Seiyon awakens as an artificial person;
- the Directorate begins keeping individual and entity records;
- Xyan's exact early office remains unknown.

### Phase 2: The Cycle Era (Year 4,232 repeated 1,778 times)

The Mnemonic Generator's field locks the civic year into recurrence. Majin and Seiyon retain full personal continuity; Marjuk preserves full records; Ayshuk studies full mechanics; the other Echo-Cores hold partial, sensory, comparative, or boundary-specific awareness as listed in the classified Cycle register.

The count represents iterations of the same year. It must not be mechanically added to every body as ordinary biological age.

### Phase 3: The Final Cycle and Breaking (Final Year 4,232)

The repeated pattern changes:
- entity behavior diverges from prior iterations;
- the other cities' systems fail into visible contact;
- Xyan sends four escalating messages;
- the Absolvohan activates on Day 160 and becomes the Hand of Hope rather than annihilating Somnarak;
- hidden truths become public;
- Xyan returns physically on Day 355 with Kael, refugees, and Feelers;
- the Mnemonic Generator's temporal field weakens by Day 360;
- Day 365 closes without reset.

### Phase 4: Post-Cycle and Dawn Initiative (Year 4,233–4,238)

The natural calendar resumes at Year 4,233. _The Memory Archive_ occurs in that post-Cycle era and culminates in Seiyon's integrated Promise. By Year 4,238, the Nine remain active within a revised Directorate doctrine:

- protect rather than imprison by default;
- study to understand rather than exploit;
- extract through accountable procedure rather than presumed ownership;
- preserve public consequence alongside classified originals;
- use borders to receive and communicate as well as repel;
- operate covertly without erasing inconvenient persons;
- maintain responsibility for routes back;
- distribute sorrow and decision rather than forcing one Director to carry everything alone.

---

## R.D. Classified — The Cycle (시간의 순환 — Sigan-ui Sunhwan)

### Classification: HISTORICAL ECHO-CORE RECORD

> *"The city thought it was Year 4,232. For 1,778 iterations, it was right and still did not know what that meant."*

### Mechanism

**Cycle period:** One civic year  
**Repeated year:** 4,232  
**Confirmed iterations:** 1,778  
**End condition reached:** Final Cycle; the temporal field weakens on Day 360 and Day 365 passes without reset

The Mnemonic Generator was designed to stabilize the R.D. facility. Its field interacted with the city's Han-flow and created a temporal echo. At the end of each iteration, the civic year reset. Ordinary citizens did not retain awareness. Echo-Core continuity varied by individual and was not caused by one universal Cast Effigy construction.

### Year Notation

- **Year 4,232+0** — original pass before confirmed recurrence
- **Year 4,232+1 through +1778** — tracked Cycle iterations
- **Year 4,233** — first natural year after the reset ends
- **Year 4,238** — current Dawn Initiative era

### Absolvohan Reserve

The original release required **100 tons of Han-crystal**. Ordinary working stock was reclaimed by reset; only secretly diverted surplus—approximately **0.02 tons per iteration**—persisted. The archived estimate places the final persistent reserve near **36 tons**.

**The archived estimate is wrong, and the error is not arithmetic.**

Facility instruments recorded the reserve at **47.3 tons** throughout the final Cycle. The Archive's figure derives from the declared diversion rate of 0.02 tons per iteration, which across 1,778 iterations yields 35.56 tons. The declared rate was the figure the Director submitted. The measured reserve implies an actual rate near **0.0266 tons per iteration**—roughly a third again as much as was ever reported.

The gap is therefore not an approximation failure. It is the difference between what Majin diverted and what Majin recorded diverting, preserved across every iteration because the same understated rate was resubmitted each cycle without revision. The Archive performed honest arithmetic on a dishonest input and produced a number eleven tons short of the vault it described.

Marjuk logged the discrepancy in the Deep Vault comparative records and did not escalate it. His annotation reads: *"The instruments and the Director disagree by eleven tons. I have recorded both. I am aware that recording both is not the same as reporting one."*

Working canon uses the measured **47.3 tons**. The archived ~36 tons is retained as evidence of the under-reporting rather than corrected, and the Day 160 dispersal of **49.8 tons** into Zone B is consistent with the measured reserve while exceeding the declared one—which is how the concealment became visible at all.

The final Absolvohan does not execute its original city-destroying release. The Hand of Hope distributes the accumulated sorrow and public truth instead.

### What Citizens and the Council Knew

Ordinary citizens did not perceive recurrence during the Cycle. Forms, clocks, and public histories remained fixed to Year 4,232. The Council did not retain full cross-reset continuity as the Nine did, though individual records, policies, and effects could shape repeated conditions.

The Cycle becomes public history after the final-Cycle disclosure. It is not an active secret in Year 4,238.

### Echo-Core Continuity Register

| Echo-Core | Knowledge | Limit / Attitude |
|---|---|---|
| **Majin** | Full knowledge; designed the stabilization system and used recurrence for the Absolvohan reserve | Retains the full burden but does not know every future choice |
| **Seiyon** | Complete high-fidelity memory across all 1,778 iterations | Restricted from ordinary intervention during the old structure; exhausted but precise |
| **Dekan** | Partial awareness through Maw tremors, classified briefings, and pressure without full chronology | Does not possess 1,778 complete personal lifetimes of recall |
| **Zyrak** | Partial comparative knowledge through records and repeated operational patterns | Can cite the count without Seiyon's complete memory or Majin's full mechanics |
| **Ayshuk** | Full technical knowledge; maintains cross-iteration models | Detached analysis does not equal complete emotional understanding |
| **Mellda** | Partial sensitivity through the Desolate and Effloresced passenger | Senses recurrence without complete mechanism or unrestricted outside memory |
| **Marjuk** | Full archive knowledge and records from all iterations | Preserves comparison; the record does not make him omniscient |
| **Ishall** | Partial comparative knowledge demonstrated by repeated Xyan-message counts and unprecedented-pattern reports | Does not demonstrate full Mnemonic mechanics or complete continuous memory |
| **Xyan** | Partial Gate-boundary awareness from outside civic suppression | Outside elapsed time remains unspecified; 1,778 iterations are not 1,778 ordinary biological years |

### Final-Cycle Breakpoints

| Day | Event |
|---:|---|
| **17** | Xyan's Furnace warning again reaches Central Command |
| **55** | “The Vaults are leaking.” |
| **97** | “The Silence is breaking.” |
| **127** | “The Hand will open. The Hand will spread. The Hand will heal.” Xyan smiles. |
| **160** | Absolvohan release changes into the Hand of Hope |
| **177** | R.D. and city truths enter public consequence |
| **355** | Xyan returns with Kael, Cheonbulok refugees, and Mugeukji Feelers |
| **360** | Seiyon confirms the temporal field is weakening and the year will not reset |
| **365** | The year closes without recurrence; the Exile is confirmed home |

### Seiyon's Burden

Seiyon remembers every iteration: repeated deaths, Fractures, laughter, briefings, and deviations. Her continuity is an artificial person's lived history, not proof that she is merely a storage system or the restored Original.

### Current Status

**ENDED.** The Cycle is historical in Year 4,238. The Mnemonic Generator's post-Cycle stabilization functions and present technical configuration remain under Directorate review, but the annual reset does not continue.

---

## Incident Reports — When The Hand Breaks

### Overview

> *"The facility is designed to contain sorrow. But sorrow is patient. Sorrow is clever. And sometimes, sorrow wins."*

Incident Reports document the times when The Hand of Change failed — when entities breached, when Ordeals struck, when personnel Fractured, when the facility itself was tested.

> **Dating note:** Cycle-era incidents are dated by Cycle iteration — Year 4232+X (X = 0–1778). Post-Cycle incidents are dated by the natural calendar, resuming at **Year 4233**. Per the return-to-Weeping law, dissolved Sorrow patterns may re-crystallize; Transformation-chain events can therefore recur in the post-Cycle era.

---

### Incident Report 001: The Silent Breach

**Date:** Year 4232+1247 | **Floor:** 2 | **Entity:** Entity 025 — The Silent Child | **Severity:** Minor

The Silent Child breached at 3:47 AM. It did not attack. It simply... left. The breach was not detected for 6 hours — the entity's Han-signature was too weak, the entity was too quiet, the entity was translucent.

When discovered, the Silent Child was sitting in the Echo Gardens — on a bench, watching the sunrise.

**Casualties:** None | **Damage:** None

**Dekan's note:** *"The Child sat on that bench for six hours. It watched the sunrise. It watched the citizens walk by. When I arrived, it looked at me — with eyes that had never seen the sky before. It did not resist when I brought it back. It simply... looked back. One more time."*

---

### Incident Report 002: The Noon Cascade

**Date:** Year 4232+1503 | **Floor:** 2 | **Entity:** The Three Birds → The Convergence | **Severity:** Major

During a Surge Ordeal, all three Birds became agitated simultaneously. They breached. They converged. The Convergence judged 47 personnel in 12 seconds. 12 Fractured immediately. 31 were incapacitated.

**Casualties:** 12 Fractured, 31 incapacitated

**Zyrak's note:** *"I separated them. It took everything I had. The Convergence fought me — it wanted to judge more. When I finally pulled them apart, the Birds were... exhausted. As if judging is what they were born to do."*

---

### Incident Report 003: The Smothering Incident

**Date:** Year 4232+1689 | **Floor:** 2 | **Entity:** The Smothering Mother | **Severity:** Major

An Agent entered the Mother's containment zone. The Mother embraced the Agent. The embrace lasted 6 hours. The Agent did not want to leave. The Agent said: *"She holds me so tight I cannot breathe. But I have never felt so safe."*

**Soojin's note:** *"I talked to her. Not to the Agent — to the Mother. I told her the Agent needed to leave. The Mother listened. She loosened her embrace. She let the Agent go. But she watched the Agent leave — with eyes full of love, and loss, and the sorrow of a mother who has lost a child."*

---

### Incident Report 004: The Dawn Transformation

**Date:** Year 4234 | **Floor:** 2 | **Entity:** Kind Healer → Dawn of Mourning | **Severity:** Catastrophic

The Kind Healer blessed its 12th personnel member. The Dawn of Mourning judged 234 personnel in 4 minutes. The Director confessed his deepest sorrow to the entity. The Dawn dissolved.

**Casualties:** 234 incapacitated

**Director Majin's note:** *"I confessed. I told the Dawn what I had never told anyone. The Dawn listened. The Dawn judged. The Dawn... forgave. I have never spoken of what I confessed. I never will."*

---

### Incident Report 005: The Midnight Abyss

**Date:** Year 4235 | **Floor:** 6 | **Entity:** The Final Door | **Severity:** Extreme

During a Abyss Ordeal, the Final Door opened partially. The Abyss poured through. 17 personnel Fractured. 43 were incapacitated. The Director personally sealed the Door using methods he has never explained.

**Casualties:** 17 Fractured, 43 incapacitated

**Director Majin's note:** *"I sealed it. I used methods I do not share. Methods that cost me something I cannot name. The Door is sealed. It will stay sealed."*

---

### Incident Report 006: The Forgotten Soldier's March

**Date:** Year 4235 | **Floor:** 2 | **Entity:** The Forgotten Soldier | **Severity:** Minor

The Soldier breached at midnight — walked to the facility's entrance, and stood at attention for 18 hours. Citizens saluted. Citizens wept. Citizens ignored it.

**Dekan's note:** *"The Soldier is not dangerous. The Soldier is lonely. The city forgot it. The Soldier just wants to be remembered."*

---

### Incident Report 007: The Memory Cascade

**Date:** Year 4236 | **Floor:** 4 | **Entity:** The Memory Weaver | **Severity:** Major

The Weaver offered a research team a memory. The memory was a trap. The team was trapped in a memory loop for 72 hours. The Weaver escaped through the Dream Veil — and returned voluntarily three weeks later.

**Ayshuk's note:** *"The Weaver does not steal. The Weaver borrows. And the Weaver always returns what it borrows."*

---

### Incident Report 008: The Colossus Passes

**Date:** Year 4236 | **Floor:** Surface | **Entity:** The Grieving Colossus | **Severity:** Moderate

The Colossus passed through the facility's outer perimeter. Its tears fell — crystallized sorrow raining from 30 meters. 3 personnel Fractured.

**Mellda's note:** *"The Colossus does not mean to harm. It is too large, too sad, too lost in its own grief. When its tears fell, I looked up — and for a moment, I saw its face. It was weeping. Not for us. For everyone."*

---

### Incident Report 009: The Bell's Crescendo

**Date:** Year 4237 | **Floor:** 2 | **Entity:** The Orphaned Bell | **Severity:** Major

On the Cheongula anniversary, the Bell tolled at a frequency never recorded. 89 personnel wept. 12 Fractured. The Bell tolled for 17 minutes — the same duration as the screaming.

**Marjuk's note:** *"The Bell remembers. The Bell always remembers. And on the anniversary, the Bell makes sure we remember too."*

---

### Incident Report 010: The Healing Shadow

**Date:** Year 4237 | **Floor:** Surface | **Entity:** The Kind Healer's Shadow | **Severity:** Minor

The Shadow healed citizens until it began dying. The R.D. intervened — pulling it away from the citizens, returning it to the facility.

**Soojin's note:** *"The Shadow was drowning in other people's wounds. When I pulled it away, it looked at me — with eyes that had seen too much suffering. It did not resist. It simply... surrendered."*

---

### Incident Statistics

| # | Entity | Severity | Fractured | Incapacitated |
|---|--------|----------|-----------|---------------|
| 001 | The Silent Child | Minor | 0 | 0 |
| 002 | The Three Birds | Major | 12 | 31 |
| 003 | The Smothering Mother | Major | 0 | 1 |
| 004 | The Dawn of Mourning | Catastrophic | 0 | 234 |
| 005 | The Final Door | Extreme | 17 | 43 |
| 006 | The Forgotten Soldier | Minor | 0 | 0 |
| 007 | The Memory Weaver | Major | 0 | 6 |
| 008 | The Grieving Colossus | Moderate | 3 | 7 |
| 009 | The Orphaned Bell | Major | 12 | 34 |
| 010 | The Kind Healer's Shadow | Minor | 0 | 0 |

**Total:** 44 Fractured, 356 incapacitated, 0 deaths

---
