# The Hand of Change & Somnarak City Map Layout Assets
This package contains exclusively the architectural blueprints, maps, and corresponding departmental/district icons for **The Hand of Change (The Reverie Directorate)** and **Somnarak City Layout**.

## 📁 Package Structure
- `01_The_Hand_of_Change/`
  - `blueprints/`: Subterranean facility cutaway maps (clean & styled dossier versions, SVG + high-res PNG).
  - `department_icons/`: Complete icons and badges for Floors 1 to 8 (Neutral, Maw's Keep, Extraction, Forge, Border, Vault, Shadow, Gate).
- `02_Somnarak_City_Map_Layout/`
  - `blueprints/`: Metropolitan city cartography maps (clean & styled dossier versions, SVG + high-res PNG).
  - `district_icons/`: District icons for Zones A, B, C, D, E, Alpha Tree, and city crest badges.
