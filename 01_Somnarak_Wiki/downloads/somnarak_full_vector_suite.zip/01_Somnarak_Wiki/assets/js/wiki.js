/**
 * SOMNARAK OFFICIAL WIKI — INTERACTIVE SCRIPT & NAVIGATION ENGINE
 * 
 * Features:
 * 1. wiki.gg / MediaWiki Authentic Jump Navigation & Smooth Scroll
 * 2. In-Article Table of Contents (#toc) with [hide]/[show] state persistence
 * 3. Dynamic Floating Quick-TOC with IntersectionObserver Active Section Tracking
 * 4. Section Heading Anchor Permalinks & Click-to-Copy
 * 5. Target Jump Pulse Highlight Animation
 * 6. Floating Back-to-Top Button
 * 7. Real-Time Asynchronous Search Engine
 * 8. Pan/Zoom Vector Canvas Map Viewer
 * 9. Mobile Responsive Navigation Rail Drawer
 */

(() => {
  'use strict';

  const q = (sel, el = document) => el.querySelector(sel);
  const qa = (sel, el = document) => [...el.querySelectorAll(sel)];

  // Helper: Escape HTML entities
  function esc(str) {
    return String(str).replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  // =========================================================================
  // 1. MOBILE LEFT RAIL NAVIGATION DRAWER
  // =========================================================================
  const navBtn = q('.nav-open');
  const leftRail = q('.left-rail');
  if (navBtn && leftRail) {
    navBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      leftRail.classList.toggle('open');
      navBtn.setAttribute('aria-expanded', String(leftRail.classList.contains('open')));
    });

    // Close on click outside
    document.addEventListener('click', (e) => {
      if (leftRail.classList.contains('open') && !leftRail.contains(e.target) && !navBtn.contains(e.target)) {
        leftRail.classList.remove('open');
        navBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // =========================================================================
  // 2. SMOOTH OFFSET ANCHOR JUMPING & TARGET PULSE HIGHLIGHT
  // =========================================================================
  const HEADER_OFFSET = 90; // Pixels beneath sticky utility navbar

  function scrollToAnchor(targetId, updateHistory = true) {
    if (!targetId) return;
    const cleanId = targetId.replace(/^#/, '');
    const el = document.getElementById(cleanId) || document.getElementById(decodeURIComponent(cleanId));
    if (!el) return;

    const elRect = el.getBoundingClientRect();
    const targetScrollY = window.pageYOffset + elRect.top - HEADER_OFFSET;

    window.scrollTo({
      top: Math.max(0, targetScrollY),
      behavior: 'smooth'
    });

    if (updateHistory) {
      history.pushState(null, '', '#' + cleanId);
    }

    // Trigger pulse highlight
    el.classList.remove('target-jump-highlight');
    void el.offsetWidth; // Trigger reflow
    el.classList.add('target-jump-highlight');

    setTimeout(() => {
      el.classList.remove('target-jump-highlight');
    }, 2200);
  }

  // Global handler for all anchor links (#...)
  document.addEventListener('click', (e) => {
    const anchor = e.target.closest('a[href^="#"]');
    if (!anchor) return;

    const href = anchor.getAttribute('href');
    if (href === '#' || href === '#top') {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (href.startsWith('#')) {
      const targetEl = document.getElementById(href.slice(1)) || document.getElementById(decodeURIComponent(href.slice(1)));
      if (targetEl) {
        e.preventDefault();
        scrollToAnchor(href.slice(1));
        
        // Close floating TOC if open on mobile
        const floatToc = q('.float-toc');
        if (floatToc && floatToc.classList.contains('open')) {
          floatToc.classList.remove('open');
        }
      }
    }
  });

  // Handle direct URL hash jumps on initial page load
  window.addEventListener('DOMContentLoaded', () => {
    if (window.location.hash) {
      setTimeout(() => {
        scrollToAnchor(window.location.hash.slice(1), false);
      }, 150);
    }
  });

  // =========================================================================
  // 3. IN-ARTICLE TABLE OF CONTENTS (#toc) COLLAPSE/EXPAND TOGGLE
  // =========================================================================
  qa('.toc, #toc').forEach(toc => {
    const title = q('.toctitle, .toc-title', toc);
    if (!title) return;

    let toggleBtn = q('.toc-toggle-btn', title);
    if (!toggleBtn) {
      toggleBtn = document.createElement('button');
      toggleBtn.type = 'button';
      toggleBtn.className = 'toc-toggle-btn';
      toggleBtn.setAttribute('aria-expanded', 'true');
      toggleBtn.innerHTML = '[<span class="toggle-label">hide</span>]';
      title.appendChild(toggleBtn);
    }

    const list = q('ul', toc);
    if (!list) return;

    // Check saved state
    const savedState = localStorage.getItem('somnarak_wiki_toc_collapsed');
    if (savedState === 'true') {
      list.style.display = 'none';
      toggleBtn.setAttribute('aria-expanded', 'false');
      const lbl = q('.toggle-label', toggleBtn);
      if (lbl) lbl.textContent = 'show';
    }

    toggleBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isHidden = list.style.display === 'none';
      list.style.display = isHidden ? 'block' : 'none';
      toggleBtn.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
      const lbl = q('.toggle-label', toggleBtn);
      if (lbl) lbl.textContent = isHidden ? 'hide' : 'show';
      localStorage.setItem('somnarak_wiki_toc_collapsed', isHidden ? 'false' : 'true');
    });
  });

  // =========================================================================
  // 4. FLOATING QUICK-TOC & INTERSECTION OBSERVER ACTIVE TRACKING
  // =========================================================================
  const contentArea = q('#content') || q('.wiki-content') || q('main');
  const headings = qa('h2[id], h3[id]', contentArea);

  if (headings.length >= 2) {
    // Check if floating TOC already exists or create one
    let floatToc = q('.float-toc');
    if (!floatToc) {
      floatToc = document.createElement('nav');
      floatToc.className = 'float-toc';
      floatToc.setAttribute('aria-label', 'Quick section navigation');
      floatToc.innerHTML = `
        <button type="button" class="float-toc-trigger" aria-expanded="false" title="Table of Contents">
          <span class="toc-icon">☰</span> <span class="toc-text">CONTENTS</span>
        </button>
        <div class="float-toc-panel">
          <div class="float-toc-header">
            <b>PAGE CONTENTS</b>
            <span class="float-toc-count">${headings.length} SECTIONS</span>
          </div>
          <ul class="float-toc-list"></ul>
        </div>
      `;
      document.body.appendChild(floatToc);
    }

    const floatList = q('.float-toc-list', floatToc);
    if (floatList && floatList.children.length === 0) {
      headings.forEach((h, idx) => {
        const li = document.createElement('li');
        li.className = h.tagName.toLowerCase() === 'h3' ? 'float-toc-sub' : 'float-toc-main';
        const a = document.createElement('a');
        a.href = '#' + h.id;
        a.dataset.targetId = h.id;
        // Clean text from bullet markers
        const cleanTitle = h.textContent.replace(/^[■›•\s\d\.\/]+/, '').trim();
        a.innerHTML = `<span class="toc-num">${idx + 1}.</span> <span class="toc-label">${esc(cleanTitle)}</span>`;
        li.appendChild(a);
        floatList.appendChild(li);
      });
    }

    // Toggle floating TOC panel
    const trigger = q('.float-toc-trigger', floatToc);
    if (trigger) {
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = floatToc.classList.toggle('open');
        trigger.setAttribute('aria-expanded', String(isOpen));
      });

      document.addEventListener('click', (e) => {
        if (floatToc.classList.contains('open') && !floatToc.contains(e.target)) {
          floatToc.classList.remove('open');
          trigger.setAttribute('aria-expanded', 'false');
        }
      });
    }

    // Active heading tracking via IntersectionObserver
    const observerCallback = (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.id;
          qa('.float-toc-list a, #toc a').forEach(link => {
            if (link.getAttribute('href') === '#' + id || link.dataset.targetId === id) {
              link.classList.add('active-toc-item');
            } else {
              link.classList.remove('active-toc-item');
            }
          });
        }
      });
    };

    const headingObserver = new IntersectionObserver(observerCallback, {
      rootMargin: '-80px 0px -60% 0px',
      threshold: 0
    });

    headings.forEach(h => headingObserver.observe(h));
  }

  // =========================================================================
  // 5. SECTION HEADING ANCHOR PERMALINKS (Click-to-Copy & Jump)
  // =========================================================================
  qa('h2[id], h3[id]', contentArea).forEach(heading => {
    if (q('.heading-permalink', heading)) return;

    const permalink = document.createElement('a');
    permalink.className = 'heading-permalink';
    permalink.href = '#' + heading.id;
    permalink.setAttribute('aria-label', 'Permalink to ' + heading.textContent);
    permalink.innerHTML = '<span class="permalink-icon">#</span><span class="permalink-tooltip">Copy link</span>';

    permalink.addEventListener('click', (e) => {
      e.preventDefault();
      scrollToAnchor(heading.id);
      
      const fullUrl = window.location.origin + window.location.pathname + '#' + heading.id;
      navigator.clipboard.writeText(fullUrl).then(() => {
        const tooltip = q('.permalink-tooltip', permalink);
        if (tooltip) {
          tooltip.textContent = 'Copied!';
          setTimeout(() => { tooltip.textContent = 'Copy link'; }, 1800);
        }
      }).catch(() => {});
    });

    heading.appendChild(permalink);
  });

  // =========================================================================
  // 6. FLOATING BACK-TO-TOP BUTTON
  // =========================================================================
  let backToTop = q('#back-to-top-btn');
  if (!backToTop) {
    backToTop = document.createElement('button');
    backToTop.id = 'back-to-top-btn';
    backToTop.className = 'back-to-top-btn';
    backToTop.type = 'button';
    backToTop.setAttribute('aria-label', 'Return to top of page');
    backToTop.innerHTML = '▲ <span class="btn-text">TOP</span>';
    document.body.appendChild(backToTop);
  }

  window.addEventListener('scroll', () => {
    if (window.pageYOffset > 320) {
      backToTop.classList.add('visible');
    } else {
      backToTop.classList.remove('visible');
    }
  }, { passive: true });

  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // =========================================================================
  // 7. REAL-TIME ASYNCHRONOUS SEARCH DATABASE
  // =========================================================================
  const searchInput = q('#search') || q('#search-input');
  const searchResults = q('#results');
  let searchDatabase = null;

  if (searchInput && searchResults) {
    searchInput.addEventListener('input', async () => {
      const term = searchInput.value.trim().toLowerCase();
      if (term.length < 2) {
        searchResults.classList.remove('open');
        searchResults.innerHTML = '';
        return;
      }

      if (!searchDatabase) {
        try {
          const indexPath = searchInput.dataset.index || '../data/search.json';
          searchDatabase = await fetch(indexPath).then(res => res.json());
        } catch (err) {
          console.error('Failed to load search index:', err);
          return;
        }
      }

      const indexPath = searchInput.dataset.index || '../data/search.json';
      const basePrefix = indexPath.replace(/data\/search\.json$/, '');

      const matches = searchDatabase.filter(item => {
        const haystack = `${item.title} ${item.subtitle || ''} ${item.terms || ''}`.toLowerCase();
        return haystack.includes(term);
      }).slice(0, 10);

      if (matches.length === 0) {
        searchResults.innerHTML = '<div class="search-no-result">No matching archives found</div>';
      } else {
        searchResults.innerHTML = matches.map(item => `
          <a href="${basePrefix}${item.url}">
            <b>${esc(item.title)}</b>
            <small>${esc(item.subtitle || 'Article Archive')}</small>
          </a>
        `).join('');
      }

      searchResults.classList.add('open');
    });

    document.addEventListener('click', (e) => {
      if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
        searchResults.classList.remove('open');
      }
    });
  }

  // =========================================================================
  // 8. VECTOR MAP CANVAS VIEWER (Pan, Zoom, Sector Controls)
  // =========================================================================
  qa('.map-viewer').forEach(viewer => {
    const stage = q('.map-canvas', viewer);
    const img = q('img', stage);
    const output = q('output', viewer);
    const baseWidth = Number(viewer.dataset.mapWidth) || 1800;
    if (!stage || !img) return;

    let scale = 1;
    const renderScale = () => {
      img.style.width = (baseWidth * scale) + 'px';
      if (output) output.textContent = Math.round(scale * 100) + '%';
    };

    const zoomIn = q('[data-map-action="in"]', viewer);
    const zoomOut = q('[data-map-action="out"]', viewer);
    const zoomReset = q('[data-map-action="native"]', viewer);
    const zoomFit = q('[data-map-action="fit"]', viewer);

    if (zoomIn) zoomIn.addEventListener('click', () => { scale = Math.min(2.5, scale + 0.25); renderScale(); });
    if (zoomOut) zoomOut.addEventListener('click', () => { scale = Math.max(0.2, scale - 0.25); renderScale(); });
    if (zoomReset) zoomReset.addEventListener('click', () => { scale = 1; renderScale(); });
    if (zoomFit) zoomFit.addEventListener('click', () => {
      scale = Math.max(0.2, Math.min(1, (stage.clientWidth - 20) / baseWidth));
      renderScale();
    });

    // Drag-to-pan
    let isDragging = false, startX = 0, startY = 0, scrollLeft = 0, scrollTop = 0;
    stage.addEventListener('pointerdown', (e) => {
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      scrollLeft = stage.scrollLeft;
      scrollTop = stage.scrollTop;
      stage.setPointerCapture(e.pointerId);
    });

    stage.addEventListener('pointermove', (e) => {
      if (!isDragging) return;
      stage.scrollLeft = scrollLeft - (e.clientX - startX);
      stage.scrollTop = scrollTop - (e.clientY - startY);
    });

    stage.addEventListener('pointerup', () => { isDragging = false; });
    img.addEventListener('dragstart', (e) => e.preventDefault());
    renderScale();
  });

})();
