# M.A.W. WEAPON — The Liquefying Hand-Cannon

> *“It finds the point where a self is dissolving. It may not decide which shape the self should keep.”*

---

**Document ID:** `SE-126-B`  
**Linked Entity:** `SE-126` — Anonym  
**Item Registry Code:** `MAW-W-126-01`  
**Author:** Extraction Lead Zyrak  
**Date:** Year 4,238 — Dawn Initiative  
**Classification:** Classified  
**Codex Set Completion:** `4/4`

## ITEM IDENTITY

| Field | Record |
|---|---|
| Official name | The Melting Lens |
| Set | Held Shape |
| Type / grade / element | Weapon / α — Minor / Void — Pale White |
| Status | Active; chosen-name witness required |
| Maximum amount | 5 — Standard |
| Current bearer | Agent Nari Kwon |
| Resting form | A thin pale Lens whose edge softens and reforms when seen from different angles. |
| Active form | A light line surrounds a fragmenting self-image without closing it into a fixed outline. |
| Recognition rule | The Lens responds only after the bearer states their current chosen name, not a name imposed by the mission. |

## EXTRACTION & BINDING

| Field | Record |
|---|---|
| Current-registry extraction | Year 4,238, Border region; Anonym held a coherent outline after a worker named a present choice without rejecting the past self |
| Extraction authority | Zyrak, with Ishall serving as chosen-name witness |
| Entity state | Calm; shard settled by choice rather than forced certainty |
| Result | Five α-grade Lenses formed from pale boundary echoes |

**Binding requirement:** The bearer names a chosen-name witness and agrees to stop use if that witness cannot recognize their current response.

**Rejection rule:** A bearer who uses the Lens to make someone conform to one identity finds the edge melt around the grip and loses the ability to state their own present choice.

## Appearance

Appearance : A heavy cast-iron hand-cannon with a ten-inch smoothbore barrel, whose exterior surfaces constantly exude a thin film of molten, cooling candle wax and congealed tallow.

The weapon fires solid balls of compressed, burning tallow that splatter across targets upon impact, adhering tenaciously and burning with stubborn white flame that resists water extinguishing.

## CORE STATISTICS

| Field | Record |
|---|---|
| Damage | Void 3–6 direct |
| Speed / range | 2 — Normal / 2 — Short |
| Pattern / coverage | Single / one designated target |
| Falloff | None; 100% to the selected target only |
| Echo cost | 15 Sorrow Echoes to register and bind |
| Operational cost | A small, nameless memory leaves the bearer after each use. |
| Binding cost | The bearer accepts that their witness may end the tool’s use. |
| Recovery | Chosen-name confirmation before reissue |

## COMBAT FILE

### Basic attack — *Hold the Edge*

The Lens applies a small Void strike to early identity erosion, giving a target a brief interval to name a current self-choice before the pressure spreads.

### Signature ability — *Not One Shape*

**Trigger:** The bearer and witness state that more than one self-history may be true.  
**Effect:** The Lens interrupts a minor erosion flare and holds the target’s identity boundary without forcing a return to a prior form.  
**Limit:** It cannot settle complex identity change, choose a name for anyone, or repair a life shaped by structural denial.  
**Failure state:** A conformity-driven use makes the Lens reflect the bearer as an unfamiliar fragment until a witness restores the chosen name.

## HISTORY OF USE

Kwon used *Not One Shape* during a Border intake where an exhausted returnee could not answer a name demand without panicking. The Lens gave enough space for the returnee to state a current name and decline a former designation. Kwon afterward forgot the code name of an old routine, but the outcome was not recorded as the Lens having “fixed” the person—it had only stopped an immediate erosion event.

## CORROSION, MAINTENANCE & SHUTDOWN

| Sign | Meaning | Required action |
|---|---|---|
| Edge melts at rest. | The bearer is avoiding their own present identity check. | Suspend tool. |
| Lens reflects only a past name. | Witness anchor is failing. | Ishall or witness takes custody. |
| Grip has no fixed shape. | The Lens is being used to force conformity. | Seal and welfare-review bearer. |

**Maintenance:** Bearer and witness state a current name, current choice, and one change they accept. The Lens is dried with a clean cloth; no engraving or fixed label is added to its surface.

**Emergency shutdown:** The witness covers the Lens with the flexible case sleeve, calls the bearer by chosen name, and removes it from hand. Breaking the glass creates multiple false self-outlines around the bearer.

## SET RELATIONSHIP

The Lens is the early-warning edge of *Named by Choice*. Melting Veil protects the bearer’s self and Melting Reflection exposes erosion; the Lens makes a pause without claiming authority over who a person becomes.

> *“Holding a shape is not the same as being held in place.”* — Extraction Lead Zyrak

---

**Document ID:** `SE-126-B`  
**Linked Entity:** `SE-126`  
**Item Registry Code:** `MAW-W-126-01`  
**Author:** Extraction Lead Zyrak  
**Date:** Year 4,238 — Dawn Initiative  
**Classification:** Classified

---
