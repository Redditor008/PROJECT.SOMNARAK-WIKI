# M.A.W. WEAPON — The Watcher's Unblinking Eye

> *“The eye embeds into the flesh; what it witnesses can never be unseen, and what it watches cannot preserve its Han.”*

---

**Document ID:** `SE-031-B`
**Linked Entity:** `SE-031` — The Observing Bird
**Item Registry Code:** `MAW-W-031-01`
**Author:** Extraction Lead Zyrak
**Date:** Year 4,238 — Dawn Initiative
**Classification:** Classified
**Codex Set Completion:** `4/4`

## COMBAT RECORD

| Field | Record |
|---|---|
| Category | PRIMAL (Bio-Ocular Implement / Replaced Eye Focus) |
| Damage | Lament 7–12 (continuous tick damage) |
| Speed / Range | 3 — Normal / 5 — Room (Line of Sight) |
| Attack Pattern | Channeled Gaze / Room-Wide Han Drain |
| Target Coverage | Up to 3 targets linked by one observed act or concealment chain |
| Falloff | 100% → 70% → 50% |
| Maximum Amount | 3 — Standard |
| Echo Cost | 40 Sorrow Echoes |

### Appearance

The Witness Requiem is a long, narrow blade of pale-blue Han crystal that carries no ornament and little curve, its edge running straight from a small round guard to a stubby point. Along the flat, a faint seam of light runs from hilt to tip, brightening only when the bearer names an act they have witnessed directly or through verified record. The grip is long and wrapped in dark blue cord over a ridged core, and the guard is a simple disc of grey metal, wide enough for two hands. In ordinary light the blade appears cold and still; once a witnessed fact is named, the seam glows and the whole blade takes on a low, blue sheen. The weapon forces the actor and any linked accomplices to remember the observed moment without allowing the bearer to embellish it, and it fails silently if the bearer lies about what they saw.

### Ability— Recorded Moment

**Trigger:** The bearer witnesses a harmful act directly or through verified record, then names the observed fact before striking.

**Effect:** The Requiem carries Lament through the actor and any linked accomplices in the line. The strike forces them to remember the witnessed moment without allowing the bearer to embellish it.

**Limit:** The weapon fails if the bearer lies about what was seen. It does not punish suspicion, rumor, or invented certainty.

**Cost:** The bearer relives the observed act in sleep until an independent witness confirms the record or contradicts it with evidence.

### History Record

A Witness Requiem was used to stop a covert execution order during a floor transfer. The bearer had seen the order but lacked authority. The weapon forced the commander and two aides to remember the recorded order long enough for the Archive to receive it.

**Document ID:** `SE-031-B`
**Linked Entity:** `SE-031`
**Item Registry Code:** `MAW-W-031-01`
**Author:** Extraction Lead Zyrak
**Date:** Year 4,238 — Dawn Initiative
**Classification:** Classified

---
